import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { app, serverPromise } from '../server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
let testOrderId: string;
let testInvoiceNumber: string;

beforeAll(async () => {
  await serverPromise;
  // Create a test order
  const order = await prisma.order.create({
    data: {
      invoiceNumber: 'ROK/TEST-0001',
      subtotal: 100,
      vatAmount: 21,
      totalAmount: 121,
      status: 'NEW',
      deliveryAddress: 'Test Address',
      customerInfo: JSON.stringify({ email: 'test@example.com', name: 'Test User' })
    }
  });
  testOrderId = order.id;
  testInvoiceNumber = order.invoiceNumber!;
});

afterAll(async () => {
  // Cleanup
  await prisma.orderWithdrawal.deleteMany({ where: { orderId: testOrderId } });
  await prisma.order.delete({ where: { id: testOrderId } });
  await prisma.$disconnect();
});

describe('POST /api/orders/withdraw - EU 2-Step Withdrawal', () => {
  it('should reject request with missing orderId or email', async () => {
    const res = await request(app)
      .post('/api/orders/withdraw')
      .send({ orderId: testOrderId }); // missing email

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Order ID and Email are required/i);
  });

  it('should reject request with mismatched email', async () => {
    const res = await request(app)
      .post('/api/orders/withdraw')
      .send({ orderId: testOrderId, email: 'wrong@example.com' });

    expect(res.status).toBe(404);
    expect(res.body.error).toMatch(/Order not found or email mismatch/i);
  });

  it('should reject request with invalid order ID', async () => {
    const res = await request(app)
      .post('/api/orders/withdraw')
      .send({ orderId: 'invalid-id', email: 'test@example.com' });

    expect(res.status).toBe(404);
    expect(res.body.error).toMatch(/Order not found or email mismatch/i);
  });

  it('should process withdrawal successfully with correct order ID and email', async () => {
    const res = await request(app)
      .post('/api/orders/withdraw')
      .send({ orderId: testOrderId, email: 'test@example.com' });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.message).toMatch(/Withdrawal confirmed/i);

    // Verify order status is updated
    const updatedOrder = await prisma.order.findUnique({ where: { id: testOrderId } });
    expect(updatedOrder?.status).toBe('CANCELLED');

    // Verify withdrawal record is created
    const withdrawal = await prisma.orderWithdrawal.findFirst({ where: { orderId: testOrderId } });
    expect(withdrawal).toBeDefined();
    expect(withdrawal?.status).toBe('CONFIRMED');
  });

  it('should process withdrawal successfully using invoiceNumber instead of ID', async () => {
    // Reset order status and delete previous withdrawal for this test
    await prisma.orderWithdrawal.deleteMany({ where: { orderId: testOrderId } });
    await prisma.order.update({ where: { id: testOrderId }, data: { status: 'NEW' } });

    const res = await request(app)
      .post('/api/orders/withdraw')
      .send({ orderId: testInvoiceNumber, email: 'test@example.com' });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    
    // Verify order status is updated
    const updatedOrder = await prisma.order.findUnique({ where: { id: testOrderId } });
    expect(updatedOrder?.status).toBe('CANCELLED');
  });
});