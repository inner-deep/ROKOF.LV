
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, MapPin, Check, ChevronDown, Loader2 } from 'lucide-react';

interface Location {
  id: string;
  name: string;
  address?: string;
  city?: string;
}

interface ShippingSelectorProps {
  locations: Location[];
  selectedId: string;
  onSelect: (id: string, fullName: string) => void;
  placeholder: string;
  isLoading?: boolean;
  translations?: {
    prompt: string;
    loading: string;
    nothingFound: string;
    selectedPointLabel: string;
  };
}

const ShippingSelector: React.FC<ShippingSelectorProps> = ({ 
  locations, 
  selectedId, 
  onSelect, 
  placeholder,
  isLoading,
  translations = {
    prompt: 'Sāciet rakstīt adresi vai pilsētu...',
    loading: 'Ielādē...',
    nothingFound: 'Nekas nav atrasts',
    selectedPointLabel: 'Izvēlētais punkts:'
  }
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filtered = useMemo(() => {
    const term = search.toLowerCase().trim();
    if (!term) return locations.slice(0, 50); // Show first 50 by default
    return locations.filter(loc => 
      loc.name.toLowerCase().includes(term) || 
      (loc.address || '').toLowerCase().includes(term) ||
      (loc.city || '').toLowerCase().includes(term)
    ).slice(0, 50);
  }, [locations, search]);

  const selectedLocation = useMemo(() => 
    locations.find(l => l.name === selectedId || l.id === selectedId), 
    [locations, selectedId]
  );

  return (
    <div className="relative w-full" ref={wrapperRef}>
      <div className="flex flex-col gap-2">
        <div 
          className={`relative flex items-center bg-white border-2 transition-all cursor-pointer ${isOpen ? 'border-black ring-4 ring-black/5' : 'border-zinc-300 hover:border-black'}`}
          onClick={() => setIsOpen(!isOpen)}
        >
          <div className="pl-6 text-zinc-400">
            <MapPin size={20} />
          </div>
          <div className="flex-grow px-4 py-5">
            {selectedLocation ? (
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-[#8DB835] uppercase tracking-widest leading-none mb-1">{translations.selectedPointLabel}</span>
                <span className="text-[12px] font-black uppercase text-black line-clamp-1">{selectedLocation.name}</span>
              </div>
            ) : (
              <span className="text-[12px] font-black text-zinc-300 uppercase tracking-widest">{placeholder}</span>
            )}
          </div>
          <div className="pr-6 text-zinc-300">
            <ChevronDown size={20} className={`transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
          </div>
        </div>

        {isOpen && (
          <div className="absolute top-[calc(100%+8px)] left-0 right-0 bg-white border-2 border-black z-[150] shadow-2xl flex flex-col max-h-[400px] animate-in slide-in-from-top-2 duration-200">
            <div className="p-4 border-b border-zinc-100 flex items-center gap-3 bg-white">
              <Search size={18} className="text-zinc-400" />
              <input 
                autoFocus
                type="text"
                placeholder={translations.prompt}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-transparent border-none text-[12px] font-black uppercase focus:outline-none"
                onClick={(e) => e.stopPropagation()}
              />
            </div>
            
            <div className="flex-grow overflow-y-auto no-scrollbar">
              {isLoading ? (
                <div className="p-10 flex flex-col items-center justify-center gap-4">
                  <Loader2 className="animate-spin text-[#8DB835]" />
                  <span className="text-[10px] font-black uppercase text-zinc-300">{translations.loading}</span>
                </div>
              ) : filtered.length > 0 ? (
                filtered.map((loc) => (
                  <button
                    key={loc.id}
                    type="button"
                    onClick={() => {
                      onSelect(loc.id, loc.name);
                      setIsOpen(false);
                      setSearch('');
                    }}
                    className={`w-full text-left p-5 border-b border-zinc-50 last:border-none flex items-center justify-between transition-colors ${selectedId === loc.name ? 'bg-zinc-900 text-white' : 'hover:bg-[#F9F4E8]'}`}
                  >
                    <div className="flex flex-col gap-1">
                      <span className={`text-[11px] font-black uppercase ${selectedId === loc.name ? 'text-[#8DB835]' : 'text-black'}`}>{loc.name}</span>
                      {loc.address && <span className="text-[9px] font-bold text-zinc-400 uppercase">{loc.address}</span>}
                    </div>
                    {selectedId === loc.name && <Check size={16} className="text-[#8DB835]" />}
                  </button>
                ))
              ) : (
                <div className="p-10 text-center">
                  <span className="text-[10px] font-black uppercase text-zinc-300">{translations.nothingFound}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ShippingSelector;
