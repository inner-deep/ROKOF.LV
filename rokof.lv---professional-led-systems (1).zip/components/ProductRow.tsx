
import React, { useState } from 'react';
import { Product, Language, User } from '../types';
import { Minus, Plus, ShoppingCart, XCircle, CheckCircle2, Zap, Shield, Ruler, Lightbulb, Heart, Thermometer, Box, Maximize2 } from 'lucide-react';
import { TRANSLATIONS, VAT_RATE } from '../constants';
import { getPersonalizedPrice } from '../src/utils/calculations';

interface ProductRowProps {
  product: Product;
  onAddToCart: (p: Product, qty: number, variantId?: string) => void;
  onViewDetails: (p: Product) => void;
  user: User | null;
  language: Language;
  isWishlisted?: boolean;
  onToggleWishlist?: () => void;
}

const ProductRow: React.FC<ProductRowProps> = ({ product, onAddToCart, onViewDetails, user, language, isWishlisted, onToggleWishlist }) => {
  const [qty, setQty] = useState(5);
  const t = TRANSLATIONS[language];
  const isB2B = user?.type === 'BUSINESS';

  const netPrice = getPersonalizedPrice(product.price || 0, product.b2bPrice || 0, user);
  const grossPrice = netPrice * (1 + VAT_RATE);
  const isOutOfStock = product.stockQuantity <= 0;
  const specifications = product.specifications || {};

  // Helper to extract CCT from title if missing
  const getColorTemp = () => {
    if (specifications.colorTemperature) return specifications.colorTemperature;
    const title = product.title?.[language] || '';
    const match = title.match(/\b(\d{4}K)\b/) || title.match(/\b(RGBW?)\b/);
    return match ? match[1] : '-';
  };

  const colorTemp = getColorTemp();

  return (
    <div className={`flex items-center border-b border-zinc-100 py-6 hover:bg-zinc-50/50 transition-all bg-white relative ${isOutOfStock ? 'bg-zinc-50/50' : ''}`}>
      {/* PHOTO SECTION */}
      <div className="w-[6%] flex justify-center px-1 shrink-0">
        <div className="w-16 h-12 md:w-20 md:h-16 border border-zinc-100 flex items-center justify-center overflow-hidden bg-[#FBFBFB]">
          <img 
            src={product.images?.[0] || 'https://picsum.photos/seed/rokof/800/600'} 
            className={`w-full h-full object-cover cursor-pointer transition-all duration-500 hover:scale-110 ${isOutOfStock ? 'grayscale opacity-30' : ''}`} 
            onClick={() => onViewDetails(product)}
            alt={product.sku}
          />
        </div>
      </div>

      {/* SYMBOL / TIPS SECTION */}
      <div className="w-[44%] flex flex-col px-4 md:px-6 text-left overflow-hidden grow">
        <div className="flex items-center gap-2 mb-1">
          <span 
            onClick={() => onViewDetails(product)}
            className="text-[12px] font-black text-[#8DB835] uppercase tracking-wider cursor-pointer hover:underline whitespace-nowrap"
          >
            {product.sku}
          </span>
          <button 
            onClick={(e) => { e.stopPropagation(); onToggleWishlist?.(); }}
            className={`p-0.5 transition-all ${isWishlisted ? 'text-[#8DB835]' : 'text-[#8DB835] hover:text-black'}`}
          >
            <Heart size={16} fill={isWishlisted ? '#8DB835' : 'none'} color="#8DB835" />
          </button>
        </div>
        
        <h4 
          onClick={() => onViewDetails(product)}
          className="text-[11px] xl:text-[12px] font-bold text-black uppercase tracking-tight truncate mb-3 cursor-pointer hover:text-[#8DB835] transition-colors leading-tight"
          title={product.title?.[language] || ''}
        >
          {product.title?.[language] || ''}
        </h4>
        
        {/* ENHANCED TECH SPECS BOX - Now includes CCT, Flux, CRI, and Width */}
        <div className="flex flex-wrap items-center gap-1.5">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 p-1.5 px-3 border border-[#94AEE5] bg-[#F1F4FF] rounded-none">
            <div className="flex items-center gap-1.5 text-[#3C64C0]">
              <Zap size={10} className="stroke-[2.5px]" />
              <span className="text-[9px] font-black uppercase whitespace-nowrap">{specifications.voltage || '-'}</span>
            </div>
            <div className="w-px h-2.5 bg-[#CAD2E7]"></div>
            <div className="flex items-center gap-1.5 text-[#3C64C0]">
              <Ruler size={10} className="stroke-[2.5px]" />
              <span className="text-[9px] font-black uppercase whitespace-nowrap">{specifications.powerPerMeter}W</span>
            </div>
            <div className="w-px h-2.5 bg-[#CAD2E7]"></div>
            <div className="flex items-center gap-1.5 text-[#3C64C0]">
              <Shield size={10} className="stroke-[2.5px]" />
              <span className="text-[9px] font-black uppercase whitespace-nowrap">{specifications.ipRating || '-'}</span>
            </div>
            
            {/* Added Technical Details as per request */}
            <div className="w-px h-2.5 bg-[#CAD2E7]"></div>
            <div className="flex items-center gap-1.5 text-[#3C64C0]">
              <Thermometer size={10} className="stroke-[2.5px]" />
              <span className="text-[9px] font-black uppercase whitespace-nowrap">{colorTemp}</span>
            </div>
            <div className="w-px h-2.5 bg-[#CAD2E7]"></div>
            <div className="flex items-center gap-1.5 text-[#3C64C0]">
              <Lightbulb size={10} className="stroke-[2.5px]" />
              <span className="text-[9px] font-black uppercase whitespace-nowrap">{specifications.luminousFlux || '-'}</span>
            </div>
            <div className="w-px h-2.5 bg-[#CAD2E7]"></div>
            <div className="flex items-center gap-1.5 text-[#3C64C0]">
              <Maximize2 size={10} className="stroke-[2.5px]" />
              <span className="text-[9px] font-black uppercase whitespace-nowrap">{specifications.width || '-'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* AVAILABILITY SECTION */}
      <div className="w-[16%] flex items-center justify-center shrink-0 px-2">
        <div className={`flex items-center gap-2 ${isOutOfStock ? 'text-rose-500' : 'text-[#8DB835]'}`}>
          {isOutOfStock ? <XCircle size={14} /> : <CheckCircle2 size={14} className="stroke-[2.5px]" />}
          <div className="flex flex-col leading-none text-left">
            <span className="text-[9px] font-black uppercase tracking-wider">{isOutOfStock ? t.stockStatus.out : t.stockStatus.in}</span>
            {!isOutOfStock && <span className="text-[9px] font-bold text-[#8DB835] mt-0.5">{product.stockQuantity} {product.unit.toUpperCase()}</span>}
          </div>
        </div>
      </div>

      {/* PRICING SECTION */}
      <div className="w-[14%] flex flex-col items-end pr-6 md:pr-10 shrink-0">
        <div className="text-[7px] font-black text-zinc-400 uppercase tracking-widest mb-1 leading-none text-right">
          {isB2B ? t.partnerPrice : t.retailPrice}
        </div>
        <div className="flex items-baseline gap-1">
          <span className={`text-[18px] xl:text-[20px] font-black tracking-tighter ${isB2B ? 'text-[#8DB835]' : 'text-black'}`}>
            €{netPrice.toFixed(2)}
          </span>
          <span className="text-[8px] font-black text-zinc-400 uppercase tracking-widest">{t.priceNet}</span>
        </div>
        <div className="text-[10px] text-rose-600 font-bold leading-none mt-0.5">
          €{grossPrice.toFixed(2)} {t.priceGross}
        </div>
      </div>

      {/* ORDERING ACTION */}
      <div className="w-[20%] flex flex-col items-end pr-4 md:pr-6 shrink-0 min-w-[160px]">
        <div className={`flex items-center justify-end w-full ${isOutOfStock ? 'opacity-40' : ''}`}>
          <div className="flex items-center bg-[#F8F9FA] h-9 xl:h-10 border border-zinc-200 rounded-none overflow-hidden shrink-0">
            <button 
              disabled={isOutOfStock}
              onClick={() => setQty(Math.max(5, qty - 5))}
              className="w-8 xl:w-9 h-full flex items-center justify-center hover:bg-zinc-100 text-zinc-400 transition-colors border-r border-zinc-200"
            >
              <Minus size={10} strokeWidth={3} />
            </button>
            <div className="w-8 xl:w-10 h-full flex items-center justify-center font-black text-black text-[12px]">
              {qty}
            </div>
            <button 
              disabled={isOutOfStock}
              onClick={() => setQty(qty + 5)}
              className="w-8 xl:w-9 h-full flex items-center justify-center hover:bg-zinc-100 text-zinc-400 transition-colors border-l border-zinc-200"
            >
              <Plus size={10} strokeWidth={3} />
            </button>
          </div>

          <button 
            onClick={() => onAddToCart(product, qty)}
            disabled={isOutOfStock}
            className={`ml-2 w-11 h-9 xl:h-10 bg-black text-white rounded-none hover:bg-zinc-800 transition-all flex items-center justify-center active:scale-95 ${isOutOfStock ? 'bg-zinc-100 text-zinc-300 cursor-not-allowed shadow-none' : 'shadow-sm'}`}
          >
            <ShoppingCart size={16} className="shrink-0 stroke-[2.5px]" />
          </button>
        </div>
        <div className="text-[9px] font-bold text-zinc-400 uppercase tracking-tight text-right w-full mt-1.5 pr-2">{t.minStep}</div>
      </div>
    </div>
  );
};

export default ProductRow;
