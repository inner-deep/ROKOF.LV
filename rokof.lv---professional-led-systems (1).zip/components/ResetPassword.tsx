import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Loader2, CheckCircle2, Eye, EyeOff } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface ResetPasswordProps {
  language: Language;
}

const ResetPassword: React.FC<ResetPasswordProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const email = searchParams.get('email');
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (!token || !email) {
      setError(t.invalidLink);
    }
  }, [token, email, language]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || !confirmPassword || !token || !email) return;

    if (password !== confirmPassword) {
      setError(t.passwordsDoNotMatch);
      return;
    }

    if (password.length < 6) {
      setError(t.passwordMinLength);
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, token, newPassword: password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to reset password');
      }

      setIsSuccess(true);
      setTimeout(() => {
        navigate('/');
      }, 3000);
    } catch (err: any) {
      setError(err.message || t.errorGeneric);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-4 pt-32">
      <div className="w-full max-w-md bg-white p-8 md:p-12 shadow-xl rounded-2xl border border-zinc-100 relative overflow-hidden">
        {isSubmitting && (
          <div className="absolute inset-0 z-10 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center">
            <Loader2 className="w-8 h-8 text-black animate-spin mb-4" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-black">
              {t.processing}
            </span>
          </div>
        )}

        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 hover:text-black transition-colors mb-12"
        >
          <ArrowLeft size={14} />
          {t.home}
        </button>

        <h1 className="text-2xl font-black uppercase tracking-tight mb-2">
          {t.newPasswordTitle}
        </h1>
        
        <p className="text-sm text-zinc-500 mb-8">
          {t.newPasswordDesc}
        </p>

        {isSuccess ? (
          <div className="bg-emerald-50 text-emerald-800 p-6 rounded-xl flex flex-col items-center text-center animate-in fade-in slide-in-from-bottom-4">
            <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4 text-emerald-600">
              <CheckCircle2 size={24} />
            </div>
            <h3 className="font-bold text-lg mb-2">
              {t.passwordChanged}
            </h3>
            <p className="text-sm opacity-80">
              {t.passwordChangedDesc}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2 relative">
              <label className="text-[10px] font-bold uppercase tracking-[0.1em] text-zinc-400">
                {t.newPasswordTitle}
              </label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-transparent border-b-2 border-zinc-200 focus:border-black px-0 py-3 text-sm font-medium focus:outline-none transition-colors pr-10"
                  placeholder="••••••••"
                />
                <button 
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black"
                >
                  {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="space-y-2 relative">
              <label className="text-[10px] font-bold uppercase tracking-[0.1em] text-zinc-400">
                {t.repeatPassword}
              </label>
              <div className="relative">
                <input
                  type={showConfirm ? "text" : "password"}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-transparent border-b-2 border-zinc-200 focus:border-black px-0 py-3 text-sm font-medium focus:outline-none transition-colors pr-10"
                  placeholder="••••••••"
                />
                <button 
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black"
                >
                  {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-xs font-bold text-rose-500 uppercase tracking-wide">{error}</p>
            )}

            <button
              type="submit"
              disabled={!password || !confirmPassword || !token || !email || isSubmitting}
              className="w-full py-4 bg-black text-white text-[11px] font-black uppercase tracking-[0.2em] hover:bg-zinc-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed mt-8"
            >
              {t.savePassword}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ResetPassword;
