import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, Mail } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface ForgotPasswordProps {
  language: Language;
}

const ForgotPassword: React.FC<ForgotPasswordProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error('Failed to process request');
      }

      setIsSuccess(true);
    } catch (err: any) {
      setError(t.errorGeneric);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-4 pt-32">
      <div className="w-full max-w-md bg-white p-8 md:p-12 shadow-xl rounded-2xl border border-zinc-100 relative overflow-hidden">
        {isSubmitting && (
          <div className="absolute inset-0 z-10 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center">
            <Loader2 className="w-8 h-8 text-black animate-spin mb-4" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-black">
              {t.processing}
            </span>
          </div>
        )}

        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 hover:text-black transition-colors mb-12"
        >
          <ArrowLeft size={14} />
          {t.back}
        </button>

        <h1 className="text-2xl font-black uppercase tracking-tight mb-2">
          {t.forgotPasswordLink}
        </h1>
        
        <p className="text-sm text-zinc-500 mb-8">
          {t.forgotPasswordDesc}
        </p>

        {isSuccess ? (
          <div className="bg-emerald-50 text-emerald-800 p-6 rounded-xl flex flex-col items-center text-center animate-in fade-in slide-in-from-bottom-4">
            <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4 text-emerald-600">
              <Mail size={24} />
            </div>
            <h3 className="font-bold text-lg mb-2">
              {t.checkEmail}
            </h3>
            <p className="text-sm opacity-80">
              {t.checkEmailDesc}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-[0.1em] text-zinc-400">
                {t.email}
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-transparent border-b-2 border-zinc-200 focus:border-black px-0 py-3 text-sm font-medium focus:outline-none transition-colors"
                placeholder="vards@epasts.lv"
              />
            </div>

            {error && (
              <p className="text-xs font-bold text-rose-500 uppercase tracking-wide">{error}</p>
            )}

            <button
              type="submit"
              disabled={!email || isSubmitting}
              className="w-full py-4 bg-black text-white text-[11px] font-black uppercase tracking-[0.2em] hover:bg-zinc-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed mt-8"
            >
              {t.sendLink}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPassword;
