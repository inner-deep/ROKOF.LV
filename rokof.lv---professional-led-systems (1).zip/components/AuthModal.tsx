
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { X, Loader2, Search, LogIn, UserPlus, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { TRANSLATIONS } from '../constants';
import { Language, User as UserType } from '../types';
import { registerUser, loginUser } from '../services/authService';
import { sendRegistrationNotification, sendCustomerWelcomeEmail } from '../services/mailService';
import { sendWelcomeEmail } from '../services/emailService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onLoginSuccess: (user: UserType) => void;
  initialMode?: 'login' | 'signup';
  initialType?: 'INDIVIDUAL' | 'BUSINESS';
}

const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, onClose, language, onLoginSuccess, initialMode = 'login', initialType = 'INDIVIDUAL' 
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [userType, setUserType] = useState<'INDIVIDUAL' | 'BUSINESS'>(initialType);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [agreements, setAgreements] = useState({
    age: false,
    terms: false,
    policy: false,
    marketing: false
  });
  
  const { t: translate } = useTranslation();
  const navigate = useNavigate();

  useEffect(() => { 
    if (isOpen) { 
      setMode(initialMode); 
      setUserType(initialType); 
    } 
  }, [isOpen, initialMode, initialType]);

  const [formData, setFormData] = useState({ 
    email: '', 
    password: '', 
    confirmPassword: '',
    firstName: '', 
    lastName: '', 
    phone: '+371 ', 
    companyName: '', 
    regNumber: '', 
    vatNumber: '', // Store only numeric part
    street: '',      // Iela un mājas numurs
    building: '',    // Korpuss
    apartment: '',   // Dzīvoklis
    city: '',        // Pilsēta
    district: '',    // Novads
    zip: 'LV-',      // Префикс для индекса
    country: 'Latvija',
    legalAddress: '', 
    physicalAddress: '', 
    billingEmail: '', 
    agreedTerms: false, 
    agreedPrivacy: false,
    agreedAge: false,
    agreedNews: false
  });
  
  const t = TRANSLATIONS[language];

  if (!isOpen) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    let finalValue = value;
    if (name === 'phone') {
      // Remove all non-digits except +
      const clean = value.replace(/[^\d+]/g, '');
      // Ensure it always starts with +371
      if (!clean.startsWith('+371')) {
        finalValue = '+371 ' + clean.replace(/^\+?371?/, '').replace(/^\+/, '');
      } else {
        // Just add the space for formatting if missing
        finalValue = clean.replace('+371', '+371 ');
      }
    }
    if (name === 'vatNumber') {
      finalValue = value.toUpperCase().replace(/^LV/, '').replace(/\D/g, '').slice(0, 11);
    }
    if (name === 'regNumber') finalValue = value.replace(/\D/g, '').slice(0, 11);
    if (name === 'zip') {
      finalValue = value.toUpperCase();
      if (!finalValue.startsWith('LV-')) {
        finalValue = 'LV-' + finalValue.replace(/^LV-?/, '');
      }
    }

    if (name === 'password' || name === 'confirmPassword') {
      const otherField = name === 'password' ? 'confirmPassword' : 'password';
      const otherValue = formData[otherField as keyof typeof formData] as string;
      const currentValue = finalValue as string;
      
      if (name === 'confirmPassword' && currentValue !== formData.password) {
        setPasswordError(language === 'LV' ? 'Paroles nesakrīt' : language === 'RU' ? 'Пароли не совпадают' : 'Passwords do not match');
      } else if (name === 'password' && formData.confirmPassword && currentValue !== formData.confirmPassword) {
        setPasswordError(language === 'LV' ? 'Paroles nesakrīt' : language === 'RU' ? 'Пароли не совпадают' : 'Passwords do not match');
      } else {
        setPasswordError('');
      }
    }

    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : finalValue }));
  };

  const validateB2B = (data: typeof formData) => {
    if (userType === 'BUSINESS') {
      // Проверка регистрационного номера (11 цифр)
      const regNrRegex = /^[0-9]{11}$/;
      if (!regNrRegex.test(data.regNumber)) {
        return "Kļūda: Reģistrācijas numuram jāsastāv no 11 cipariem.";
      }

      // Проверка PVN номера (LV + 11 цифр)
      const vatNrRegex = /^(LV)?[0-9]{11}$/;
      if (!vatNrRegex.test(data.vatNumber)) {
        return "Kļūda: PVN numuram jābūt formātā LV12345678901.";
      }

      if (!data.companyName || data.companyName.trim().length < 2) {
        return "Kļūda: Lūdzu, norādiet uzņēmuma nosaukumu.";
      }
    }
    return null;
  };

  const formatAddress = (data: any) => {
    const parts = [
      data.street,
      data.building ? `korp. ${data.building}` : '',
      data.apartment ? `dz. ${data.apartment}` : '',
      data.city,
      data.district,
      data.zip,
      data.country
    ];
    return parts.filter(part => part && part.trim() !== "").join(", ");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'signup') {
      if (!agreements.terms || !agreements.policy) return;
      
      if (userType === 'INDIVIDUAL') {
        if (!formData.firstName || !formData.lastName) {
           alert(language === 'LV' ? 'Lūdzu, ievadiet vārdu un uzvārdu.' : language === 'RU' ? 'Пожалуйста, введите имя и фамилию.' : 'Please enter your first and last name.');
           return;
        }
      }

      // СТАЛО (блокирует только частных лиц):
      if (userType === 'INDIVIDUAL' && !agreements.age) {
        const errorMsg = "Reģistrācija nav atļauta personām jaunākām par 13 gadiem.";
        console.error("Auth error:", errorMsg);
        alert(errorMsg);
        return;
      }

      if (formData.password !== formData.confirmPassword) {
        alert(language === 'LV' ? 'Paroles nesakrīt!' : language === 'RU' ? 'Пароли не совпадают!' : 'Passwords do not match!');
        return;
      }

      const b2bError = validateB2B(formData);
      if (b2bError) {
        alert(b2bError);
        return;
      }
    }
    
    setIsProcessing(true);
    try {
      if (mode === 'signup') {
        const profileData: Partial<UserType> = {
          firstName: formData.firstName,
          lastName: formData.lastName,
          phone: formData.phone,
        };

        if (userType === 'BUSINESS') {
          profileData.companyName = formData.companyName;
          profileData.regNo = formData.regNumber;
          profileData.vatNo = `LV${formData.vatNumber.replace(/^LV/, '')}`;
          profileData.legalAddress = formatAddress(formData);
        }

        const newUser = await registerUser(
          formData.email, 
          formData.password, 
          agreements.marketing, 
          userType, 
          agreements.age, 
          '127.0.0.1', 
          profileData,
          language
        );

        await sendRegistrationNotification(newUser, language);
        await sendCustomerWelcomeEmail(formData.email, formData.password, newUser.companyName || newUser.email, language);
        await sendWelcomeEmail(formData.email, userType === 'BUSINESS' ? 'BUSINESS' : 'INDIVIDUAL');
        
        alert(t.registrationSuccessful.replace('{email}', formData.email));
        onLoginSuccess(newUser);
        localStorage.setItem('freshRegistration', 'true');

        onClose();
      } else { // This is the login block
        try {
          const user = await loginUser(formData.email, formData.password);
          onLoginSuccess(user);
          onClose();
        } catch (loginErr: any) {
          alert(loginErr.message || 'Login failed');
          setIsProcessing(false);
          return;
        }
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      alert(err.message || 'An error occurred');
    } finally { 
      setIsProcessing(false); 
    }
  };

  const renderTermsLabel = () => {
    const linkClass = "text-black underline font-black hover:text-[#8DB835] transition-colors";
    return (
      <span className="text-xs font-bold text-zinc-400 uppercase tracking-tight leading-tight">
        {t.agreeTo}
        <a href="/terms" target="_blank" className={linkClass}>
          {t.termsAndConditions}
        </a>
      </span>
    );
  };

  const renderPrivacyLabel = () => {
    const linkClass = "text-black underline font-black hover:text-[#8DB835] transition-colors";
    return (
      <span className="text-xs font-bold text-zinc-400 uppercase tracking-tight leading-tight">
        {t.agreeTo}
        <a href="/privacy" target="_blank" className={linkClass}>
          {t.privacyPolicy}
        </a>
      </span>
    );
  };

  const inputClass = "w-full bg-transparent border-b border-zinc-200 focus:border-black px-0 py-4 text-[13px] font-black uppercase tracking-[0.1em] focus:outline-none transition-all placeholder:text-zinc-200 placeholder:text-[11px] placeholder:font-bold";
  const groupHeaderClass = "text-black text-[12px] font-black uppercase tracking-[0.05em] mb-8 mt-12 first:mt-0";
  
  const isFormValid = () => {
    if (mode === 'login') {
      return formData.email.includes('@') && formData.password.length > 0;
    }

    // 1. Общие обязательные поля для всех
    const hasEmail = formData.email.includes('@');
    const hasPassword = formData.password.length >= 6 && formData.password === formData.confirmPassword;
    const hasAgreedTerms = agreements.terms && agreements.policy;

    // 2. Валидация адреса (теперь по частям)
    const hasAddress = 
      (formData.street?.length || 0) > 3 && 
      (formData.city?.length || 0) > 1 && 
      (formData.zip?.length || 0) >= 6; // Минимум "LV-XXX"

    // 3. Специфическая валидация для B2B (Uzņēmums)
    if (userType === 'BUSINESS') {
      const hasCompanyInfo = 
        (formData.companyName?.length || 0) > 1 && 
        (formData.regNumber?.length || 0) === 11 && 
        (formData.vatNumber?.length || 0) >= 11;

      return hasEmail && hasPassword && hasAgreedTerms && hasAddress && hasCompanyInfo;
    }

    // 4. Специфическая валидация для B2C (Privātpersona)
    const hasName = formData.firstName.trim().length > 0 && formData.lastName.trim().length > 0;
    const hasPhone = formData.phone.trim().length > 4;
    return hasEmail && hasPassword && hasAgreedTerms && agreements.age && hasName && hasPhone;
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-white overflow-hidden max-h-[95vh] flex flex-col shadow-2xl rounded-none border border-zinc-100">
        {isProcessing && (
          <div className="absolute inset-0 z-[110] bg-white/90 flex flex-col items-center justify-center">
            <Loader2 className="w-12 h-12 text-black animate-spin mb-6" />
            <span className="text-[11px] font-black uppercase tracking-[0.5em] text-black">{t.processing}</span>
          </div>
        )}
        
        <div className="absolute top-6 right-6 z-20">
          <button onClick={onClose} className="p-2 text-black hover:scale-110 transition-all">
            <X size={32} strokeWidth={1.5} />
          </button>
        </div>

        <div className="overflow-y-auto px-8 pt-16 pb-12 md:px-24 md:pb-20 bg-white no-scrollbar">
          {/* Top Tabs matching screenshot */}
          <div className="flex mb-16 relative">
            <div className="absolute bottom-0 left-0 w-full h-[1px] bg-zinc-100"></div>
            <button 
              type="button" 
              onClick={() => setMode('login')} 
              className={`flex-1 pb-6 flex items-center justify-center gap-3 text-[13px] font-black uppercase tracking-[0.2em] transition-all relative ${mode === 'login' ? 'text-black' : 'text-zinc-200 hover:text-zinc-400'}`}
            >
              <LogIn size={18} className={mode === 'login' ? 'text-zinc-400' : 'text-zinc-200'} /> {t.login}
              {mode === 'login' && <div className="absolute bottom-0 left-0 w-full h-[2px] bg-black"></div>}
            </button>
            <button 
              type="button" 
              onClick={() => setMode('signup')} 
              className={`flex-1 pb-6 flex items-center justify-center gap-3 text-[13px] font-black uppercase tracking-[0.2em] transition-all relative ${mode === 'signup' ? 'text-black' : 'text-zinc-200 hover:text-zinc-400'}`}
            >
              <UserPlus size={18} className={mode === 'signup' ? 'text-zinc-400' : 'text-zinc-200'} /> {t.signup}
              {mode === 'signup' && <div className="absolute bottom-0 left-0 w-full h-[2px] bg-black"></div>}
            </button>
          </div>

          {mode === 'signup' && (
            <div className="flex mb-16 justify-center">
              <div className="bg-[#F8F9FA] p-1.5 rounded-none flex w-full max-w-lg border border-zinc-100">
                <button 
                  type="button" 
                  onClick={() => setUserType('INDIVIDUAL')} 
                  className={`flex-1 py-4 text-[11px] font-black uppercase tracking-[0.2em] transition-all ${userType === 'INDIVIDUAL' ? 'bg-black text-white shadow-lg' : 'text-zinc-400 hover:text-black'}`}
                >
                  {t.privateLabel}
                </button>
                <button 
                  type="button" 
                  onClick={() => setUserType('BUSINESS')} 
                  className={`flex-1 py-4 text-[11px] font-black uppercase tracking-[0.2em] transition-all ${userType === 'BUSINESS' ? 'bg-black text-white shadow-lg' : 'text-zinc-400 hover:text-black'}`}
                >
                  {t.businessLabel}
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {mode === 'signup' && userType === 'BUSINESS' && (
              <div className="space-y-4 text-left animate-in fade-in slide-in-from-bottom-2 duration-500">
                <h3 className="font-bold uppercase text-sm border-b pb-2">{t.companyData}</h3>
                
                <div className="flex flex-col gap-3">
                  {/* Название компании */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase text-gray-400">{t.companyName} *</label>
                    <input 
                      type="text"
                      className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                      required 
                      value={formData.companyName}
                      onChange={(e) => setFormData({...formData, companyName: e.target.value})}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Регистрационный номер - Триггер для PVN */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.regNoHint} *</label>
                      <input 
                        type="text"
                        maxLength={11}
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                        required 
                        value={formData.regNumber}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, ''); // Только цифры
                          setFormData({
                            ...formData, 
                            regNumber: val,
                            // Автоматически формируем PVN при вводе рег. номера
                            vatNumber: val.length > 0 ? `LV${val}` : "" 
                          });
                        }}
                      />
                    </div>

                    {/* PVN номер - Теперь принимает текст (LV) */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.vatNoHint} *</label>
                      <input 
                        type="text"
                        value={formData.vatNumber} // Управляемое поле для авто-подстановки
                        maxLength={13}
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition bg-gray-50"
                        required 
                        onChange={(e) => setFormData({...formData, vatNumber: e.target.value.toUpperCase()})}
                      />
                    </div>
                  </div>
                </div>

                {/* Granular Address Block */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                  <h3 className="font-bold uppercase text-xs tracking-widest text-gray-500">{t.addressLegal}</h3>
                  
                  {/* Улица и дом */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.street} *</label>
                    <input 
                      type="text"
                      className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                      required
                      value={formData.street}
                      onChange={(e) => setFormData({...formData, street: e.target.value})}
                    />
                  </div>

                  {/* Кorpuss и Dzīvoklis */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.korpuss}</label>
                      <input 
                        type="text"
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                        value={formData.building}
                        onChange={(e) => setFormData({...formData, building: e.target.value})}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.apartment}</label>
                      <input 
                        type="text"
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                        value={formData.apartment}
                        onChange={(e) => setFormData({...formData, apartment: e.target.value})}
                      />
                    </div>
                  </div>

                  {/* Pilsēta и Novads */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.city} *</label>
                      <input 
                        type="text"
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                        required
                        value={formData.city}
                        onChange={(e) => setFormData({...formData, city: e.target.value})}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.novads}</label>
                      <input 
                        type="text"
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                        value={formData.district}
                        onChange={(e) => setFormData({...formData, district: e.target.value})}
                      />
                    </div>
                  </div>

                  {/* Индекс и Страна */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.postalCode} *</label>
                      <input 
                        type="text"
                        maxLength={7}
                        className="w-full p-3 border border-gray-300 focus:border-black outline-none transition"
                        required
                        value={formData.zip}
                        onChange={(e) => {
                          let val = e.target.value.toUpperCase();
                          if (!val.startsWith('LV-') && val.length > 0) val = 'LV-' + val.replace('LV', '').replace('-', '');
                          setFormData({...formData, zip: val});
                        }}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400">{t.addressFields.country}</label>
                      <input 
                        type="text"
                        value="Latvija"
                        disabled
                        className="w-full p-3 border border-gray-200 bg-gray-50 text-gray-500 cursor-not-allowed outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
              {mode === 'signup' && userType === 'BUSINESS' && <h4 className={groupHeaderClass}>{t.contactPerson}</h4>}
              {mode === 'signup' && userType === 'INDIVIDUAL' && <h4 className={groupHeaderClass}>{t.personalData}</h4>}
              
              <div className="space-y-6">
                {mode === 'signup' && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-xs font-bold uppercase tracking-wider text-gray-500">{t.firstName} *</label>
                        <input 
                          type="text" 
                          name="firstName" 
                          value={formData.firstName} 
                          onChange={handleInputChange} 
                          className={inputClass} 
                          required 
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold uppercase tracking-wider text-gray-500">{t.lastName} *</label>
                        <input 
                          type="text" 
                          name="lastName" 
                          value={formData.lastName} 
                          onChange={handleInputChange} 
                          className={inputClass} 
                          required 
                        />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold uppercase tracking-wider text-gray-500">{t.phone} *</label>
                      <input 
                        type="tel" 
                        name="phone" 
                        value={formData.phone} 
                        onChange={handleInputChange} 
                        className={inputClass} 
                        required 
                      />
                    </div>
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-500">{t.email} *</label>
                  <input 
                    placeholder={t.email} 
                    type="email" 
                    name="email" 
                    value={formData.email} 
                    onChange={handleInputChange} 
                    className={inputClass} 
                    required 
                  />
                  {mode === 'signup' && (
                    <p className="text-[11px] text-gray-400 italic">
                      {t.emailAsLogin}
                    </p>
                  )}
                </div>

                <div className="space-y-1 relative">
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-500">{t.password} *</label>
                  <div className="relative">
                    <input 
                      placeholder={t.password} 
                      type={showPass ? "text" : "password"} 
                      name="password" 
                      value={formData.password} 
                      onChange={handleInputChange} 
                      className={`${inputClass} pr-10`} 
                      required 
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPass(!showPass)}
                      className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black"
                    >
                      {showPass ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                  {mode === 'signup' && formData.password.length > 0 && formData.password.length < 6 && (
                    <p className="text-[10px] text-rose-500 font-bold uppercase mt-1">
                      {t.passwordMinLength}
                    </p>
                  )}
                </div>

                {mode === 'signup' && (
                  <div className="space-y-1 relative">
                    <label className="text-xs font-bold uppercase tracking-wider text-gray-500">
                      {t.confirmPasswordLabel} *
                    </label>
                    <div className="relative">
                      <input 
                        placeholder={t.confirmPasswordLabel} 
                        type={showConfirm ? "text" : "password"} 
                        name="confirmPassword" 
                        value={formData.confirmPassword} 
                        onChange={handleInputChange} 
                        className={`${inputClass} pr-10 ${passwordError ? 'border-rose-500 text-rose-500' : ''}`} 
                        required 
                      />
                      <button 
                        type="button"
                        onClick={() => setShowConfirm(!showConfirm)}
                        className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black"
                      >
                        {showConfirm ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                    {passwordError && <p className="text-[10px] text-rose-500 font-bold uppercase mt-1 animate-in fade-in slide-in-from-top-1">{passwordError}</p>}
                  </div>
                )}
              </div>
            </div>

            {mode === 'login' && (
              <div className="flex justify-end mt-2 animate-in fade-in slide-in-from-bottom-2 duration-500">
                <a href="/forgot-password" onClick={(e) => { e.preventDefault(); onClose(); navigate('/forgot-password'); }} className="text-[11px] font-bold uppercase tracking-wider text-gray-500 hover:text-black transition-colors">
                  {t.forgotPasswordLink}
                </a>
              </div>
            )}

            {mode === 'signup' && (
              <div className="space-y-4 py-4 border-t mt-16">
                {/* 1. Возраст 13+ (Only for B2C) */}
                {userType === 'INDIVIDUAL' && (
                  <label className="flex items-start gap-3 cursor-pointer group mb-4">
                    <input 
                      type="checkbox" 
                      className="mt-1 w-5 h-5 accent-black border-2 border-black cursor-pointer"
                      checked={agreements.age}
                      onChange={(e) => setAgreements({...agreements, age: e.target.checked})}
                    />
                    <span className="text-sm text-gray-600">
                      {t.ageConfirm} <br/>
                      <span className="text-[10px] text-gray-400">
                        {t.ageConfirmLegal}
                      </span>
                    </span>
                  </label>
                )}

                {/* 2. Lietošanas noteikumi */}
                <label className="flex items-center gap-3 cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="w-5 h-5 accent-black border-2 border-black cursor-pointer"
                    checked={agreements.terms}
                    onChange={(e) => setAgreements({...agreements, terms: e.target.checked})}
                  />
                  <span className="text-sm font-bold uppercase underline">{t.agreeTo}{t.termsAndConditions}</span>
                </label>

                {/* 3. Privātuma politika */}
                <label className="flex items-center gap-3 cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="w-5 h-5 accent-black border-2 border-black cursor-pointer"
                    checked={agreements.policy}
                    onChange={(e) => setAgreements({...agreements, policy: e.target.checked})}
                  />
                  <span className="text-sm font-bold uppercase underline">{t.agreeTo}{t.privacyPolicy}</span>
                </label>

                {/* 4. Marketing (Optional) */}
                <label className="flex items-center gap-3 cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="w-5 h-5 accent-black border-2 border-black cursor-pointer"
                    checked={agreements.marketing}
                    onChange={(e) => setAgreements({...agreements, marketing: e.target.checked})}
                  />
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-tight leading-tight">
                    {t.marketingConsent}
                  </span>
                </label>

                {/* Новая юридическая приписка только для B2B */}
                {userType === 'BUSINESS' && (
                  <p className="text-[11px] text-gray-500 italic leading-tight mt-2">
                    {t.b2bConfirm}
                  </p>
                )}
              </div>
            )}

            <button 
              type="submit" 
              disabled={!isFormValid()}
              className={`w-full py-8 mt-4 text-[14px] font-black uppercase tracking-[0.4em] flex items-center justify-center transition-all active:scale-[0.98] ${!isFormValid() ? 'bg-gray-100 text-gray-300 cursor-not-allowed' : 'bg-black text-white hover:bg-zinc-900 shadow-2xl cursor-pointer'}`}
            >
              {mode === 'login' ? t.login : t.signup}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
