
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCart, Menu, Search, Zap, Globe, X, User as UserIcon, Briefcase, ChevronDown } from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { Language, Page, User as UserType } from '../types';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  language: Language;
  setLanguage: (l: Language) => void;
  isB2B: boolean;
  setIsB2B: (b: boolean) => void;
  onSearch: (q: string) => void;
  user: UserType | null;
  onOpenAuth: (mode?: 'login' | 'signup', type?: 'INDIVIDUAL' | 'BUSINESS') => void;
  onLogout: () => void;
  onAdminOpen?: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  cartCount, 
  onOpenCart, 
  language, 
  setLanguage, 
  onSearch,
  user,
  onOpenAuth,
  onLogout,
  onAdminOpen
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isCartPinging, setIsCartPinging] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);
  const t = TRANSLATIONS[language];

  // Trigger ping animation when cartCount changes
  useEffect(() => {
    if (cartCount > 0) {
      setIsCartPinging(true);
      const timer = setTimeout(() => setIsCartPinging(false), 300);
      return () => clearTimeout(timer);
    }
  }, [cartCount]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(event.target as Node)) {
        setIsLangOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const NavLink = ({ page, label, mobile = false }: { page: Page, label: string, mobile?: boolean }) => {
    const isActive = location.pathname === (page === 'catalog' ? '/' : `/${page}`);
    return (
      <button 
        type="button"
        onClick={() => {
          if (page === 'catalog') navigate('/');
          else navigate(`/${page}`);
          setIsMobileMenuOpen(false);
        }}
        aria-label={label}
        className={`${mobile ? 'text-lg py-5 w-full text-left' : 'text-[11px] xl:text-[12px] py-2'} font-black uppercase tracking-[0.15em] transition-all relative flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-black focus:ring-inset ${
          isActive ? 'text-black' : 'text-zinc-400 hover:text-black'
        }`}
      >
        {label}
        {!mobile && isActive && <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-black"></span>}
      </button>
    );
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-[60] bg-white border-b border-zinc-100 h-20 md:h-24">
        <div className="container mx-auto px-4 xl:px-8 h-full flex items-center justify-between gap-4">

          {/* Logo */}
          <div className="flex items-center gap-3 xl:gap-4 shrink-0 group">
            {user?.role?.toUpperCase() === 'ADMIN' && (
              <button 
                type="button"
                onClick={onAdminOpen}
                aria-label="Open Admin Panel"
                className="w-10 h-10 bg-black rounded-none flex items-center justify-center transition-transform group-hover:rotate-3 shadow-lg cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#8DB835]"
              >
                <Zap className="text-white w-5 h-5 fill-white" />
              </button>
            )}
            <button 
              type="button"
              onClick={() => navigate('/')}
              aria-label="Go to Home"
              className="text-lg xl:text-2xl font-black tracking-tighter text-black uppercase hidden sm:block cursor-pointer whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-black p-1"
            >
              ROKOF<span className="text-[#8DB835]">.LV</span>
            </button>
          </div>
          <nav className="hidden md:flex items-center gap-4 lg:gap-6 xl:gap-8 2xl:gap-12 ml-4">
            <NavLink page="catalog" label={t.catalog} />
            <NavLink page="partners" label={t.b2bZone} />
            <NavLink page="contacts" label={t.contact} />
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex items-center relative flex-grow max-w-sm xl:max-w-md mx-4 xl:mx-8">
            <input 
              type="text" 
              placeholder={t.search}
              aria-label={t.search}
              onChange={(e) => onSearch(e.target.value)}
              className="w-full bg-[#F8F9FA] border border-zinc-100 px-6 py-3.5 text-[10px] xl:text-[11px] font-bold uppercase tracking-widest focus:outline-none focus:bg-white focus:border-black focus:ring-2 focus:ring-black transition-all rounded-none"
            />
            <Search className="absolute right-6 w-4 h-4 text-zinc-300" />
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3 xl:gap-4">
            {!user && (
              <button 
                type="button"
                onClick={() => onOpenAuth('signup', 'BUSINESS')}
                aria-label={t.b2bRegistration}
                className="hidden xl:flex items-center gap-3 px-5 py-4 border-2 border-[#8DB835] text-[#8DB835] text-[11px] xl:text-[12px] font-black uppercase tracking-widest hover:bg-[#8DB835] hover:text-white transition-all shadow-sm shrink-0 whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-[#8DB835]"
              >
                <Briefcase size={16} /> {t.b2bRegistration}
              </button>
            )}

            <div className="flex items-center border border-zinc-200 divide-x divide-zinc-200 rounded-none h-12 md:h-14 bg-white shadow-sm overflow-visible">
              {/* Language Switcher */}
              <div ref={langRef} className="relative h-full">
                <button
                  type="button"
                  onClick={() => setIsLangOpen(!isLangOpen)}
                  aria-label="Select Language"
                  aria-expanded={isLangOpen}
                  aria-haspopup="listbox"
                  className={`px-4 xl:px-6 flex items-center gap-2 xl:gap-3 cursor-pointer transition-colors h-full focus:outline-none focus:bg-zinc-100 ${isLangOpen ? 'bg-zinc-50' : 'hover:bg-zinc-50'}`}
                >
                  <Globe size={18} className="text-zinc-800" />
                  <span className="text-[11px] xl:text-[12px] font-black uppercase tracking-widest">{language}</span>
                  <ChevronDown size={14} className={`text-zinc-300 transition-transform hidden sm:block ${isLangOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isLangOpen && (
                  <div 
                    role="listbox"
                    className="absolute top-[calc(100%+1px)] right-0 bg-white border border-zinc-200 shadow-2xl py-2 min-w-[120px] z-[100] animate-in fade-in slide-in-from-top-1 duration-200"
                  >
                    {(['LV', 'RU', 'EN'] as Language[]).map(l => (
                      <button 
                        key={l} 
                        type="button"
                        role="option"
                        aria-selected={language === l}
                        onClick={(e) => {
                          e.stopPropagation();
                          setLanguage(l);
                          setIsLangOpen(false);
                        }} 
                        className={`block w-full text-left px-5 py-3.5 text-[12px] font-black tracking-widest transition-colors focus:outline-none focus:bg-zinc-100 ${
                          language === l ? 'bg-[#8DB835] text-white' : 'text-black hover:bg-zinc-50'
                        }`}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Login / User Status */}
              {user ? (
                <button 
                  type="button"
                  onClick={() => navigate('/profile/settings')}
                  aria-label="User Profile"
                  className="px-4 xl:px-8 flex items-center gap-3 xl:gap-4 hover:bg-zinc-50 transition-colors h-full focus:outline-none focus:bg-zinc-100"
                >
                  {user.type === 'BUSINESS' ? <Briefcase size={18} className="text-[#8DB835]" /> : <UserIcon size={18} className="text-zinc-800" />}
                  <span className="text-[11px] xl:text-[12px] font-black uppercase tracking-widest hidden sm:block">
                    {user.type === 'BUSINESS' ? (user.companyName?.substring(0, 12) || user.firstName) : user.firstName}
                  </span>
                </button>
              ) : (
                <button 
                  type="button"
                  onClick={() => onOpenAuth('login')}
                  aria-label={t.login}
                  className="px-5 xl:px-10 flex items-center gap-3 xl:gap-4 hover:bg-zinc-50 transition-colors h-full focus:outline-none focus:bg-zinc-100"
                >
                  <UserIcon size={18} className="text-zinc-800" />
                  <span className="text-[11px] xl:text-[12px] font-black uppercase tracking-widest hidden sm:block whitespace-nowrap">{t.login}</span>
                </button>
              )}

              {/* Shopping Cart */}
              <button 
                type="button"
                onClick={onOpenCart}
                aria-label={`Shopping Cart, ${cartCount} items`}
                className="px-5 xl:px-8 flex items-center justify-center hover:bg-zinc-50 transition-colors relative h-full focus:outline-none focus:bg-zinc-100"
              >
                <ShoppingCart size={22} className="text-black" />
                {cartCount > 0 && (
                  <span className={`absolute top-2.5 right-2.5 bg-black text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-sm transition-transform ${isCartPinging ? 'scale-125 bg-[#8DB835]' : 'scale-100'}`}>
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
            
            <button 
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
              aria-label="Toggle Mobile Menu"
              aria-expanded={isMobileMenuOpen}
              className="md:hidden p-2 text-black hover:bg-zinc-50 transition-colors focus:outline-none focus:ring-2 focus:ring-black"
            >
              {isMobileMenuOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[55] bg-white pt-24 px-6 flex flex-col animate-in fade-in slide-in-from-top duration-300">
           <div className="flex flex-col gap-2 pt-6 overflow-y-auto no-scrollbar">
              <div className="flex items-center relative mb-6">
                <input 
                  type="text" 
                  placeholder={t.search}
                  onChange={(e) => onSearch(e.target.value)}
                  className="w-full bg-[#F8F9FA] border border-zinc-100 px-6 py-4 text-[12px] font-bold uppercase tracking-widest focus:outline-none focus:bg-white focus:border-black transition-all rounded-none"
                />
                <Search className="absolute right-6 w-5 h-5 text-zinc-300" />
              </div>

              <NavLink page="catalog" label={t.catalog} mobile />
              <NavLink page="partners" label={t.b2bZone} mobile />
              <NavLink page="contacts" label={t.contact} mobile />
              
              <div className="mt-8 pb-12 border-t border-zinc-100 pt-10 flex flex-col gap-8">
                 <div className="flex flex-col gap-4">
                    <span className="text-[10px] font-black text-zinc-300 uppercase tracking-widest">Select Language</span>
                    <div className="flex gap-2">
                       {(['LV', 'RU', 'EN'] as Language[]).map(l => (
                          <button 
                            key={l}
                            onClick={() => { setLanguage(l); setIsMobileMenuOpen(false); }}
                            className={`flex-1 py-5 border text-[12px] font-black uppercase tracking-widest transition-all ${language === l ? 'bg-black text-white border-black shadow-lg' : 'text-zinc-400 border-zinc-100'}`}
                          >
                             {l}
                          </button>
                       ))}
                    </div>
                 </div>
                 
                 {!user && (
                    <button 
                      type="button"
                      onClick={() => { onOpenAuth('signup', 'BUSINESS'); setIsMobileMenuOpen(false); }} 
                      className="w-full py-6 bg-[#8DB835] text-white text-[14px] font-black uppercase tracking-widest shadow-xl flex items-center justify-center gap-4"
                    >
                      <Briefcase size={20} /> {t.b2bRegistration}
                    </button>
                 )}

                 {user ? (
                   <button 
                    type="button"
                    onClick={() => { onLogout(); setIsMobileMenuOpen(false); }} 
                    className="w-full py-6 text-rose-500 font-black uppercase text-[14px] tracking-widest border border-rose-100 bg-rose-50/50 shadow-sm"
                   >
                     LOGOUT
                   </button>
                 ) : (
                    <button 
                      type="button"
                      onClick={() => { onOpenAuth('login'); setIsMobileMenuOpen(false); }} 
                      className="w-full py-6 bg-black text-white text-[14px] font-black uppercase tracking-widest shadow-xl"
                    >
                      {t.login}
                    </button>
                 )}
              </div>
           </div>
        </div>
      )}
    </>
  );
};

export default Header;
