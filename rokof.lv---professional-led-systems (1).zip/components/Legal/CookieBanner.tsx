import React, { useState, useEffect } from 'react';

interface CookieBannerProps {
  onOpenPrivacy: () => void;
}

export const activateAnalytics = () => {
  // Находим все скрипты с категорией analytics
  const scripts = document.querySelectorAll('script[data-cookie-category="analytics"]');
  
  scripts.forEach((oldScript: any) => {
    if (oldScript.type === 'text/javascript') return;

    const newScript = document.createElement('script');
    // Копируем все атрибуты (src, async и т.д.)
    Array.from(oldScript.attributes).forEach((attr: any) => {
      newScript.setAttribute(attr.name, attr.value);
    });
    // Меняем тип обратно на javascript, чтобы он выполнился
    newScript.type = 'text/javascript';
    newScript.innerHTML = oldScript.innerHTML;
    
    if (oldScript.parentNode) {
      oldScript.parentNode.replaceChild(newScript, oldScript);
    }
  });
  
  console.log("Analytics activated for ROKOF.LV");
};

export const CookieBanner: React.FC<CookieBannerProps> = ({ onOpenPrivacy }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('rokof_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    } else if (consent === 'all') {
      activateAnalytics();
    }
  }, []);

  const handleConsent = (type: 'all' | 'necessary') => {
    localStorage.setItem('rokof_cookie_consent', type);
    
    if (type === 'all') {
      activateAnalytics();
    }
    
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t-4 border-black p-6 shadow-2xl z-[200]">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm text-gray-700">
          <p className="font-bold mb-1">Mēs cienām jūsu privātumu</p>
          <p>
            Mēs izmantojam sīkdatnes, lai uzlabotu vietnes darbību. Lasiet vairāk mūsu 
            <button onClick={onOpenPrivacy} className="underline ml-1 font-medium hover:text-black">Privātuma politikā</button>.
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => handleConsent('necessary')}
            className="px-4 py-2 border border-black text-sm font-bold hover:bg-gray-100 transition"
          >
            TIKAI NEPIECIEŠAMĀS
          </button>
          <button 
            onClick={() => handleConsent('all')}
            className="px-4 py-2 bg-black text-white text-sm font-bold hover:bg-gray-800 transition"
          >
            PIEŅEMT VISAS
          </button>
        </div>
      </div>
    </div>
  );
};
