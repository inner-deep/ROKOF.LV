import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="max-w-4xl mx-auto p-6 md:p-10 text-gray-800 font-sans leading-relaxed">
      <h1 className="text-3xl font-extrabold uppercase border-b-4 border-black pb-4 mb-6">
        PRIVĀTUMA POLITIKA
      </h1>
      <p className="text-sm text-gray-500 mb-8">Pēdējās izmaiņas: 26.02.2026.</p>
      
      <p className="mb-8">
        Šī Privātuma politika apraksta, kā <strong>ROKOF SIA</strong> (turpmāk — "Mēs") iegūst, apstrādā un uzglabā jūsu personas datus, kad jūs izmantojat interneta veikalu <strong>ROKOF.LV</strong>.
      </p>

      {/* 1. PĀRZINIS */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">1. PĀRZINIS</h2>
        <div className="bg-gray-50 p-4 rounded-sm border border-gray-200">
          <p><strong>Uzņēmums:</strong> ROKOF SIA</p>
          <p><strong>Reģ. nr.:</strong> 40203306649</p>
          <p><strong>Juridiskā adrese:</strong> Pūces iela 11/1-7, Rīga, LV-1082</p>
          <p><strong>E-pasts saziņai:</strong> <a href="mailto:pavels@pzka.lv" className="underline">pavels@pzka.lv</a></p>
        </div>
      </section>

      {/* 2. DATI */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">2. KĀDUS DATUS MĒS APSTRĀDĀJAM?</h2>
        <p className="mb-3">Mēs apstrādājam datus saskaņā ar minimizēšanas principu:</p>
        <ul className="list-disc ml-6 space-y-2">
          <li><strong>Reģistrācija:</strong> E-pasts, parole un apstiprinājums par vecumu (13+ gadi).</li>
          <li><strong>Pasūtījuma noformēšana:</strong> Vārds, uzvārds (vai uzņēmuma nosaukums un reģ. nr.), tālruņa numurs, piegādes adrese (piemēram, Omniva pakomāts).</li>
          <li><strong>Maksājumi:</strong> Bankas rekvizīti rēķinu sagatavošanai un QR kodu ģenerēšanai.</li>
        </ul>
      </section>

      {/* 3. PAMATS */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">3. DATU APSTRĀDES TIESISKAIS PAMATS</h2>
        <ul className="list-disc ml-6 space-y-2 mb-6">
          <li><strong>Līguma izpilde:</strong> Lai apstrādātu jūsu pasūtījumu un piegādātu preci.</li>
          <li><strong>Juridiskais pienākums:</strong> Lai sagatavotu grāmatvedības dokumentus (rēķinus) saskaņā ar Latvijas likumdošanu.</li>
          <li><strong>Piekrišana:</strong> Ja jūs piesakāties jaunumu saņemšanai.</li>
        </ul>
        
        <div className="bg-blue-50 p-5 border-l-4 border-blue-600 italic shadow-sm">
          <h3 className="font-bold not-italic mb-2 text-blue-900">Bērnu datu aizsardzība:</h3>
          <p className="text-sm">
            Saskaņā ar Fizisko personu datu apstrādes likumu, Latvijā pakalpojumus var saņemt personas no 13 gadu vecuma. 
            ROKOF SIA mērķtiecīgi neievāc informāciju no personām, kas ir jaunākas par 13 gadiem. 
            Reģistrējoties lietotājs apliecina savu vecumu. Ja mums kļūst zināms par nejaušu datu ieguvi no personas, 
            kas jaunāka par 13 gadiem, šādi dati tiek nekavējoties dzēsti.
          </p>
        </div>
      </section>

      {/* 4. SAŅĒMĒJI */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">4. DATU SAŅĒMĒJI</h2>
        <p className="mb-3">Jūsu dati var tikt nodoti uzticamiem sadarbības partneriem:</p>
        <ul className="list-disc ml-6 space-y-2">
          <li><strong>Piegādes dienestiem:</strong> Omniva, DPD vai citiem kurjerpastiem piegādes nodrošināšanai.</li>
          <li><strong>Maksājumu iestādēm:</strong> Bankām un maksājumu platformām (piemēram, Montonio) darījumu apstrādei.</li>
        </ul>
      </section>

      {/* 5. TERMIŅI */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">5. GLABĀŠANAS TERMIŅI</h2>
        <ul className="list-disc ml-6 space-y-2">
          <li><strong>Grāmatvedības dokumenti (rēķini):</strong> Tiek glabāti 10 gadus saskaņā ar likumu "Par grāmatvedību".</li>
          <li><strong>Profila dati:</strong> Tiek glabāti, kamēr lietotājs nav pieprasījis to dzēšanu vai 2 gadus pēc pēdējās aktivitātes.</li>
        </ul>
      </section>

      {/* 6. TIESĪBAS */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">6. JŪSU TIESĪBAS</h2>
        <ul className="list-disc ml-6 space-y-2 mb-4">
          <li>Piekļūt saviem datiem un saņemt to kopiju (eksportēt JSON/CSV formātā).</li>
          <li>Labot nepareizus datus savā profilā.</li>
          <li>Pieprasīt datu dzēšanu ("tiesības tikt aizmirstam"), ja tas nav pretrunā ar likumu par grāmatvedības glabāšanu.</li>
          <li>Atsaukt piekrišanu mārketinga ziņojumu saņemšanai jebkurā laikā.</li>
        </ul>
        <p>Saziņai par datu aizsardzību rakstiet uz: <strong>pavels@pzka.lv</strong></p>
      </section>

      {/* 7. COOKIES */}
      <section className="mb-10">
        <h2 className="text-xl font-bold uppercase mb-4 text-black">7. SĪKDATNES (COOKIES)</h2>
        <p>
          Mēs izmantojam nepieciešamās sīkdatnes vietnes darbībai un analītiskās sīkdatnes, lai uzlabotu lietotāju pieredzi. 
          Jums ir tiesības izvēlēties, kuras sīkdatnes atļaut mūsu sīkdatņu banerī.
        </p>
      </section>

      <footer className="mt-12 pt-6 border-t border-gray-200 text-center text-gray-500 text-xs">
        &copy; {new Date().getFullYear()} ROKOF SIA. Visas tiesības aizsargātas.
      </footer>
    </div>
  );
};

export default PrivacyPolicy;
