import React from 'react';

export const PrivacyAgeSection = () => {
  return (
    <section className="legal-section my-6 p-4 border-l-4 border-black bg-gray-50">
      <h3 className="text-lg font-bold mb-3 uppercase tracking-wider">
        Bērnu datu aizsardzība
      </h3>
      <p className="text-sm leading-relaxed text-gray-800">
        Saskaņā ar <strong>Fizisko personu datu apstrādes likumu</strong>, 
        Latvijā pakalpojumus var saņemt personas no 13 gadu vecuma. 
        <strong> ROKOF SIA</strong> mērķtiecīgi neievāc informāciju no personām, 
        kas ir jaunākas par 13 gadiem. Reģistrējoties lietotājs apliecina savu vecumu. 
        Ja mums kļūst zināms par nejaušu datu ieguvi no personas, kas jaunāka par 13 gadiem, 
        šādi dati tiek nekavējoties dzēsti.
      </p>
      <p className="text-xs mt-2 text-gray-500 italic">
        (Tiesiskais pamats: Fizisko personu datu apstrādes likuma 33. pants un GDPR 8. pants)
      </p>
    </section>
  );
};
