import React from 'react';
import { TRANSLATIONS } from '../../constants';
import { Language } from '../../types';

interface FAQPageProps {
  language: Language;
}

const FAQPage: React.FC<FAQPageProps> = ({ language }) => {
  const t = TRANSLATIONS[language].legalPages.faq;

  return (
    <div className="bg-zinc-900 text-white min-h-screen">
      <div className="container mx-auto px-4 py-20">
        <h1 className="text-4xl font-black tracking-tighter uppercase mb-8">{t.title}</h1>
        <div className="prose prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: t.content.replace(/\n/g, '<br />') }} />
      </div>
    </div>
  );
};

export default FAQPage;
