
import React, { useState } from 'react';
import { Product, Language, User } from '../types';
import { ShoppingCart, Minus, Plus, Zap, Shield, Info, Heart, Lightbulb, Ruler, Tag, Truck } from 'lucide-react';
import { TRANSLATIONS, VAT_RATE } from '../constants';
import { getPersonalizedPrice } from '../src/utils/calculations';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product, qty: number) => void;
  onViewDetails: (p: Product) => void;
  isInCart?: boolean;
  user: User | null;
  language: Language;
  isWishlisted?: boolean;
  onToggleWishlist?: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, onAddToCart, onViewDetails, isInCart, user, language, isWishlisted, onToggleWishlist
}) => {
  const [qty, setQty] = useState(5);
  const t = TRANSLATIONS[language];
  const isB2B = user?.type === 'BUSINESS';

  const netPrice = getPersonalizedPrice(product.price, product.b2bPrice, user);
  const grossPrice = netPrice * (1 + VAT_RATE);
  const isOutOfStock = product.stockQuantity <= 0;
  const isDiscounted = netPrice < product.price;

  return (
    <article className="group bg-white border border-zinc-100 flex flex-col h-full hover:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.1)] transition-all duration-500 relative rounded-none">
      <div 
        className="relative aspect-[4/3] overflow-hidden border-b border-zinc-50 bg-[#FBFBFB]"
      >
        <img 
          src={product.images?.[0] || 'https://picsum.photos/seed/rokof/800/600'} 
          alt={product.title?.[language] || product.sku}
          onClick={() => onViewDetails(product)}
          className={`absolute inset-0 w-full h-full object-cover cursor-pointer transition-all duration-700 group-hover:scale-105 ${isOutOfStock ? 'grayscale opacity-40' : 'grayscale-0'}`}
        />
        
        {/* Wishlist Button */}
        <button 
          onClick={(e) => { e.stopPropagation(); onToggleWishlist?.(); }}
          className={`absolute top-4 left-4 p-2 transition-all shadow-sm ${isWishlisted ? 'bg-black text-[#8DB835]' : 'bg-white text-zinc-300 hover:text-black'}`}
        >
          <Heart size={16} fill={isWishlisted ? '#8DB835' : 'none'} />
        </button>

        {isOutOfStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/40 pointer-events-none">
            <span className="bg-white px-5 py-2 text-[10px] font-black uppercase border border-zinc-200 shadow-md tracking-widest">{t.stockStatus.out}</span>
          </div>
        )}
        {isDiscounted && (
          <div className="absolute top-4 right-4 bg-[#8DB835] text-white px-3 py-1 text-[9px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg">
            <Tag size={12} /> -{user.discountLevel || 20}%
          </div>
        )}
      </div>
      
      <div className="p-7 flex flex-col flex-grow">
        <div className="mb-5 cursor-pointer" onClick={() => onViewDetails(product)}>
          <span className="text-[10px] font-black text-[#8DB835] uppercase tracking-[0.2em] mb-1.5 block">{product.sku}</span>
          <h3 className="font-black text-[13px] md:text-[14px] text-black uppercase tracking-tight line-clamp-2 hover:text-[#8DB835] transition-colors leading-tight min-h-[2.2em]">
            {product.title?.[language] || ''}
          </h3>
        </div>

        <div className="grid grid-cols-2 gap-y-5 gap-x-3 mb-4 py-5 border-y border-zinc-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-zinc-50 flex items-center justify-center text-zinc-400 group-hover:text-black transition-colors">
              <Zap size={15} />
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-zinc-300 uppercase tracking-widest mb-0.5">{t.voltage}</span>
              <span className="text-[11px] font-black uppercase text-black">{product.specifications.voltage}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-zinc-50 flex items-center justify-center text-zinc-400 group-hover:text-black transition-colors">
              <Shield size={15} />
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-zinc-300 uppercase tracking-widest mb-0.5">{t.ipRating}</span>
              <span className="text-[11px] font-black uppercase text-black">{product.specifications.ipRating}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-zinc-50 flex items-center justify-center text-zinc-400 group-hover:text-black transition-colors">
              <Ruler size={15} />
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-zinc-300 uppercase tracking-widest mb-0.5">POW</span>
              <span className="text-[11px] font-black uppercase text-black">{product.specifications.powerPerMeter}W/{product.unit}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-zinc-50 flex items-center justify-center text-zinc-400 group-hover:text-black transition-colors">
              <Lightbulb size={15} />
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-zinc-300 uppercase tracking-widest mb-0.5">FLUX</span>
              <span className="text-[11px] font-black uppercase text-black">{product.specifications.luminousFlux}</span>
            </div>
          </div>
        </div>

        <div className="mt-auto space-y-4">
          <div className="flex items-end justify-between">
            <div className="flex flex-col">
              <div className="text-[8px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">
                {isB2B ? t.partnerPrice : t.retailPrice}
              </div>
              <div className="flex items-baseline gap-2">
                <span className={`text-[22px] md:text-[24px] font-black leading-none tracking-tighter ${isB2B ? 'text-[#8DB835]' : 'text-black'}`}>
                  €{netPrice.toFixed(2)}
                </span>
                <span className="text-[9px] text-zinc-400 font-black uppercase tracking-widest">/ 1{product.unit.toUpperCase()} {t.priceNet}</span>
              </div>
              <span className="text-[11px] text-rose-600 font-bold mt-1.5">€{grossPrice.toFixed(2)} {t.priceGross}</span>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <div className={`flex items-center h-11 ${isOutOfStock ? 'opacity-40' : ''}`}>
              <div className="flex items-center bg-white h-full border border-zinc-200 rounded-md overflow-hidden shrink-0">
                <button 
                  disabled={isOutOfStock}
                  onClick={() => setQty(Math.max(5, qty - 5))} 
                  className="w-10 h-full flex items-center justify-center bg-zinc-50 hover:bg-zinc-100 text-zinc-400 transition-colors border-r border-zinc-200"
                >
                  <Minus size={12} strokeWidth={3} />
                </button>
                <div className="w-10 h-full flex items-center justify-center font-black text-black text-[13px] bg-white">
                  {qty}
                </div>
                <button 
                  disabled={isOutOfStock}
                  onClick={() => setQty(qty + 5)} 
                  className="w-10 h-full flex items-center justify-center bg-zinc-50 hover:bg-zinc-100 text-zinc-400 transition-colors border-l border-zinc-200"
                >
                  <Plus size={12} strokeWidth={3} />
                </button>
              </div>
              
              <button 
                disabled={isOutOfStock}
                onClick={() => onAddToCart(product, qty)}
                className={`ml-2 flex-grow h-full bg-black text-white text-[11px] font-bold uppercase tracking-wider rounded-md transition-all flex items-center justify-center gap-2 active:scale-95 ${isOutOfStock ? 'bg-zinc-100 text-zinc-300 cursor-not-allowed shadow-none' : 'shadow-sm hover:bg-zinc-800'}`}
              >
                <ShoppingCart size={15} className="shrink-0 stroke-[2.5px]" />
                {t.add}
              </button>
            </div>
            <div className="text-center">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-tight">{t.minStep}</span>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
};

export default ProductCard;
