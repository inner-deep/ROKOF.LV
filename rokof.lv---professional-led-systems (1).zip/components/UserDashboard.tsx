
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, Package, Heart, History, Settings, ShieldCheck, Zap, 
  FileText, Layout, ArrowRight, Download, ExternalLink, Trash2, 
  CheckCircle2, Clock, Truck, ChevronRight, LogOut, AlertTriangle, MapPin, 
  Lock, Loader2, Save, ShoppingBag, X, Phone, Mail, Hash, Eye, CreditCard, Building2,
  ChevronDown, Ban, Weight, Percent, Printer
} from 'lucide-react';
import { TRANSLATIONS, VAT_RATE } from '../constants';
// Added missing CartItem import
import { Language, User as UserType, Order, Invoice, Product, CartItem } from '../types';
import { storeService } from '../services/storeService';
import { generateROKOFInvoice } from '../services/invoiceService';
import { exportUserData, deleteAccountRequest } from '../services/userDataService';
import ProductCard from './ProductCard';
import Toast from './Toast';

interface OrderDetailsModalProps { 
  order: Order; 
  onClose: () => void; 
  language: Language; 
  onCancel?: (order: Order) => void; 
  user: UserType;
  onGenerateInvoice: (order: Order) => void;
}

const OrderDetailsModal: React.FC<OrderDetailsModalProps> = ({ order, onClose, language, onCancel, user, onGenerateInvoice }) => {
  const t = TRANSLATIONS[language];
  const od = t.orderDetail;
  
  // Use values directly from order object to ensure consistency with DB and PDF
  const totalGross = order?.totalAmount || order?.total || 0;
  const deliveryNet = order?.deliveryCost || 0;
  const subtotalNet = order?.subtotal || ((totalGross / 1.21) - deliveryNet) || 0;
  const vatAmount = order?.vatAmount || (totalGross - (totalGross / 1.21)) || 0;

  const totalWeight = order?.items?.reduce((acc, item) => acc + (Number(item.weightPerMeter || 0) * Number(item.quantity || 0)), 0) || 0;
  const isCancellable = order?.status === 'NEW';

  // Address logic
  const getCustomerAddress = () => {
    const ci = order?.customerInfo;
    if (ci) {
      const parts = [ci.street, ci.building, ci.apartment, ci.city, ci.zipCode].filter(Boolean);
      if (parts.length > 0) return parts.join(', ');
      if (ci.address) return ci.address;
    }
    
    // Fallback to user profile address if order snapshot is missing or incomplete
    const u = user;
    const userParts = [u.street, u.building, u.apartment, u.city, u.zipCode].filter(Boolean);
    if (userParts.length > 0) return userParts.join(', ');
    if (u.physicalAddress) return u.physicalAddress;
    
    return order?.deliveryAddress || order?.shippingAddress || 'N/A';
  };

  const customerBaseAddress = getCustomerAddress();
  const displayAddress = order?.stationId ? `${customerBaseAddress} (Pakomāts: ${order.stationId})` : customerBaseAddress;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-white shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-300 max-h-[90vh] rounded-none border-2 border-black">
        <div className="p-8 bg-black text-white flex items-center justify-between shrink-0">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-[#8DB835] uppercase tracking-[0.4em] mb-1">
              {od.header}
            </span>
            <h2 className="text-2xl font-black uppercase tracking-tight">{order?.invoiceNumber || order?.id}</h2>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-zinc-800 transition-all border border-zinc-700">
            <X size={28} />
          </button>
        </div>

        <div className="flex-grow overflow-y-auto p-10 space-y-12 no-scrollbar bg-[#FBFBFB]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-3">{od.customerData}</h4>
              <div className="space-y-4">
                <div className="flex items-center gap-4 text-[11px] font-black text-black uppercase">
                  <div className="w-8 h-8 rounded-none bg-zinc-100 flex items-center justify-center text-[#8DB835]">
                    <User size={16} />
                  </div>
                  {order?.customerInfo?.name || `${user?.firstName || ''} ${user?.lastName || ''}`}
                </div>
                <div className="flex items-center gap-4 text-[11px] font-bold text-zinc-500 uppercase">
                   <div className="w-8 h-8 rounded-none bg-zinc-100 flex items-center justify-center">
                    <Mail size={16} />
                  </div>
                  {order?.customerInfo?.email || user?.email || 'N/A'}
                </div>
                <div className="flex items-center gap-4 text-[11px] font-bold text-zinc-500 uppercase">
                   <div className="w-8 h-8 rounded-none bg-zinc-100 flex items-center justify-center">
                    <Phone size={16} />
                  </div>
                  {order?.customerInfo?.phone || user?.phone || 'N/A'}
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-3">{od.delivery}</h4>
              <div className="space-y-4">
                <div className="flex items-start gap-4 text-[11px] font-bold text-black uppercase leading-relaxed">
                  <div className="w-8 h-8 rounded-none bg-zinc-100 flex items-center justify-center text-[#8DB835] shrink-0">
                    <Truck size={16} />
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-zinc-400 font-black uppercase">{od.type}</span>
                    {order?.deliveryMethod || 'N/A'}
                  </div>
                </div>
                <div className="flex items-start gap-4 text-[11px] font-bold text-zinc-500 leading-relaxed uppercase">
                   <div className="w-8 h-8 rounded-none bg-zinc-100 flex items-center justify-center text-[#8DB835] shrink-0">
                    <MapPin size={16} />
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-zinc-400 font-black uppercase">{od.address}</span>
                    {displayAddress}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-3">{od.items}</h4>
            <div className="border-2 border-zinc-100 divide-y-2 divide-zinc-100 bg-white">
              {order?.items?.map((item, idx) => {
                const price = Number(item.priceAtPurchase || item.price || 0);
                const qty = Number(item.quantity || 0);
                const total = price * qty;
                return (
                  <div key={item.id || `item-${idx}`} className="flex items-center p-6 gap-6 hover:bg-zinc-50 transition-colors">
                    <div className="w-16 h-16 bg-zinc-100 border border-zinc-200 flex items-center justify-center shrink-0 overflow-hidden">
                      {item.image ? (
                        <img src={item.image} alt={item.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <Hash size={20} className="text-zinc-400" />
                      )}
                    </div>
                    <div className="flex-grow overflow-hidden">
                      <div className="text-[10px] font-black text-[#8DB835] uppercase mb-1">{item.sku}</div>
                      <div className="text-[12px] font-black text-black uppercase leading-tight line-clamp-1">{item.title}</div>
                      {item.warrantyUntil && (
                        <div className={`text-[9px] font-bold mt-1 uppercase tracking-widest flex items-center gap-1 ${new Date(item.warrantyUntil) < new Date() ? 'text-zinc-400' : 'text-emerald-600'}`}>
                          <ShieldCheck size={10} />
                          {new Date(item.warrantyUntil) < new Date() 
                            ? 'Garantija beigusies' 
                            : `Garantija aktīva līdz: ${new Date(item.warrantyUntil).toLocaleDateString('lv-LV')}`}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-end shrink-0 ml-4">
                      <div className="text-[10px] font-bold text-zinc-400 uppercase">{qty}m x €{price.toFixed(2)}</div>
                      <div className="text-[14px] font-black text-black">€{total.toFixed(2)}</div>
                      {item.weightPerMeter && (
                        <div className="text-[9px] font-bold text-zinc-300 uppercase">{(Number(item.weightPerMeter || 0) * qty).toFixed(2)} kg</div>
                      )}
                    </div>
                  </div>
                );
              })}
              {Number(order?.deliveryCost || 0) > 0 && (
                <div className="flex items-center p-6 gap-6 hover:bg-zinc-50 transition-colors">
                  <div className="w-14 h-14 bg-zinc-100 border-2 border-zinc-200 flex items-center justify-center shrink-0">
                    <Truck size={20} className="text-zinc-400" />
                  </div>
                  <div className="flex-grow overflow-hidden">
                    <div className="text-[10px] font-black text-[#8DB835] uppercase mb-1">DELIVERY</div>
                    <div className="text-[12px] font-black text-black uppercase leading-tight line-clamp-1">{order?.deliveryMethod || 'Piegāde'}</div>
                  </div>
                  <div className="flex flex-col items-end shrink-0 ml-4">
                    <div className="text-[10px] font-bold text-zinc-400 uppercase">1 x €{Number(order?.deliveryCost || 0).toFixed(2)}</div>
                    <div className="text-[14px] font-black text-black">€{Number(order?.deliveryCost || 0).toFixed(2)}</div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {order?.comment && (
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-3">{od.comment}</h4>
              <div className="p-6 bg-zinc-100 border border-zinc-200 text-xs font-bold text-zinc-600 italic">
                "{order.comment}"
              </div>
            </div>
          )}

          {/* Documents Section */}
          <div className="space-y-6">
            <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-3">Dokumenti</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Prepayment Invoice */}
              <div className="p-4 border-2 border-zinc-100 bg-white flex flex-col gap-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                    <FileText size={14} className="text-[#8DB835]" />
                    Priekšapmaksas Rēķins
                  </div>
                  <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${['PAID', 'PROCESSING', 'IN_DELIVERY', 'SHIPPED', 'COMPLETED'].includes(order?.status || '') ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                    {['PAID', 'PROCESSING', 'IN_DELIVERY', 'SHIPPED', 'COMPLETED'].includes(order?.status || '') ? 'Apmaksāts' : 'Neapmaksāts'}
                  </span>
                </div>
                <div className="text-[12px] font-bold text-black">{order?.invoiceNumber || order?.id}</div>
                {order?.prepaymentInvoiceUrl ? (
                  <a 
                    href={order.prepaymentInvoiceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-auto px-4 py-3 bg-black text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all flex items-center justify-center gap-2"
                  >
                    <Download size={14} /> Lejupielādēt
                  </a>
                ) : (
                  <div className="mt-auto px-4 py-3 bg-zinc-100 text-zinc-400 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-not-allowed">
                    <Download size={14} /> Nav pieejams
                  </div>
                )}
                <button 
                  onClick={() => onGenerateInvoice(order)}
                  className="mt-2 px-4 py-3 bg-[#8DB835] text-white text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-2"
                >
                  <FileText size={14} /> Ģenerēt Rēķinu
                </button>
              </div>

              {/* Invoice */}
              <div className="p-4 border-2 border-zinc-100 bg-white flex flex-col gap-3">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                  <FileText size={14} className="text-[#8DB835]" />
                  Pavadzīme
                </div>
                <div className="text-[12px] font-bold text-black">{order?.rkfInvoiceNumber || 'Tiks ģenerēts pēc apmaksas'}</div>
                {order?.invoiceUrl ? (
                  <a 
                    href={order.invoiceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-auto px-4 py-3 bg-black text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all flex items-center justify-center gap-2"
                  >
                    <Download size={14} /> Lejupielādēt
                  </a>
                ) : (
                  <div className="mt-auto px-4 py-3 bg-zinc-100 text-zinc-400 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-not-allowed">
                    <Download size={14} /> Nav pieejams
                  </div>
                )}
              </div>

              {/* Delivery Document */}
              <div className="p-4 border-2 border-zinc-100 bg-white flex flex-col gap-3">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                  <Truck size={14} className="text-[#8DB835]" />
                  Piegādes Dokuments
                </div>
                <div className="text-[12px] font-bold text-zinc-500 italic">Kurjera apstiprinājums</div>
                {order?.deliveryDocumentUrl ? (
                  <a 
                    href={order.deliveryDocumentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-auto px-4 py-3 bg-zinc-100 text-black text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all flex items-center justify-center gap-2 border border-zinc-200"
                  >
                    <FileText size={14} /> Skatīt
                  </a>
                ) : (
                  <div className="mt-auto px-4 py-3 bg-zinc-50 text-zinc-400 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 border border-zinc-100 cursor-not-allowed">
                    <FileText size={14} /> Nav pieejams
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="p-10 bg-white border-t-2 border-black shrink-0">
          <div className="flex flex-col md:flex-row items-end md:items-center justify-between gap-6">
            <div className="flex flex-col gap-4">
               {isCancellable && onCancel && (
                 <button 
                  onClick={() => onCancel(order)}
                  className="px-6 py-4 border-2 border-rose-100 text-rose-500 text-[10px] font-black uppercase hover:bg-rose-500 hover:text-white transition-all flex items-center gap-2"
                 >
                   <Ban size={14} /> {od.cancel}
                 </button>
               )}
               <div className="flex items-center gap-2 text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                 <Weight size={14} /> {od.weight}: <span className="text-black">{Number(totalWeight || 0).toFixed(2)} kg</span>
               </div>
            </div>
            <div className="max-w-xs w-full space-y-4">
              <div className="flex justify-between text-[11px] font-black text-zinc-400 uppercase tracking-widest">
                <span>{od.subtotal}</span>
                <span className="text-black">€{subtotalNet.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between text-[11px] font-black text-[#8DB835] uppercase tracking-widest">
                <span>{od.deliveryLabel}</span>
                <span>€{deliveryNet.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[11px] font-black text-zinc-400 uppercase tracking-widest">
                <span>{od.vat}</span>
                <span className="text-black">€{vatAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center pt-6 border-t-2 border-black">
                <span className="text-[12px] font-black uppercase tracking-widest">{od.total}</span>
                <span className="text-4xl font-black tracking-tighter text-black">€{totalGross.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface UserDashboardProps {
  user: UserType;
  language: Language;
  cart: CartItem[];
  onLogout: () => void;
  onUpdateUser: (u: UserType) => void;
  onAddToCart: (p: Product, qty: number) => void;
  onToggleWishlist: (productId: string) => void;
  onViewDetails: (p: Product) => void;
}

const UserDashboard: React.FC<UserDashboardProps> = ({ user, language, cart, onLogout, onUpdateUser, onAddToCart, onToggleWishlist, onViewDetails }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'panel' | 'orders' | 'wishlist' | 'invoices' | 'settings'>('panel');
  const [isUpdating, setIsUpdating] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [wishlistProducts, setWishlistProducts] = useState<Product[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [toasts, setToasts] = useState<{id: string, message: string}[]>([]);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const addToast = (msg: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message: msg }]);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const t = TRANSLATIONS[language];

  useEffect(() => {
    if (localStorage.getItem('freshRegistration') === 'true') {
      addToast(t.welcomeMessage);
      if (user.type === 'BUSINESS') {
        addToast(t.b2bOnboardingTooltip);
      }
      localStorage.removeItem('freshRegistration');
    }
  }, [user, language, t, addToast]);

  const [securityForm, setSecurityForm] = useState({
    email: user.email,
    phone: user.phone || '',
    firstName: user.firstName || '',
    lastName: user.lastName || '',
    physicalAddress: user.physicalAddress || '',
    street: user.street || '',
    building: user.building || '',
    apartment: user.apartment || '',
    city: user.city || '',
    district: user.district || '',
    zipCode: user.zipCode || '',
    companyName: user.companyName || '',
    regNo: user.regNo || '',
    vatNo: user.vatNo?.replace(/^LV/, '') || '',
    legalAddress: user.legalAddress || '',
    country: user.country || 'Latvija',
    bankName: user.bankName || '',
    swift: user.swift || '',
    bankAccount: user.bankAccount || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const loadData = async () => {
    const fetchedOrders = await storeService.getOrders(user.id);
    setOrders(fetchedOrders);
    const wishlistIds = await storeService.getWishlist(user.id);
    const result = await storeService.getProducts();
    const allProducts = Array.isArray(result) ? result : result.products;
    setWishlistProducts(allProducts.filter(p => wishlistIds.includes(p.id)));
  };

  useEffect(() => {
    loadData();
    window.addEventListener('rokof_orders_updated', loadData);
    window.addEventListener('rokof_wishlist_updated', loadData);
    return () => {
      window.removeEventListener('rokof_orders_updated', loadData);
      window.removeEventListener('rokof_wishlist_updated', loadData);
    };
  }, [user.id]);

  const formatAddress = (data: any) => {
    const parts = [
      data.street,
      data.building ? `korp. ${data.building}` : '',
      data.apartment ? `dz. ${data.apartment}` : '',
      data.city,
      data.district,
      data.zipCode || data.zip,
      data.country
    ];
    const formatted = parts.filter(part => part && part.trim() !== "").join(", ");
    return formatted || data.physicalAddress || data.legalAddress || "";
  };

  const handleSecuritySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);
    
    const updatedUser: UserType = {
      ...user,
      email: securityForm.email,
      firstName: securityForm.firstName,
      lastName: securityForm.lastName,
      phone: securityForm.phone,
      physicalAddress: securityForm.physicalAddress,
      street: securityForm.street,
      building: securityForm.building,
      apartment: securityForm.apartment,
      companyName: securityForm.companyName,
      regNo: securityForm.regNo,
      vatNo: securityForm.vatNo ? (securityForm.vatNo.startsWith('LV') ? securityForm.vatNo : `LV${securityForm.vatNo}`) : '',
      legalAddress: formatAddress(securityForm),
      city: securityForm.city,
      district: securityForm.district,
      zipCode: securityForm.zipCode,
      country: securityForm.country,
      bankName: securityForm.bankName,
      swift: securityForm.swift,
      bankAccount: securityForm.bankAccount
    };

    setTimeout(() => {
      onUpdateUser(updatedUser);
      setIsUpdating(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1500);
  };

  const handleCancelOrder = async (order: Order) => {
    const confirmMsg = language === 'LV' 
      ? 'Vai tiešām vēlaties atcelt šo pasūtījumu? Preces tiks atgrieztas noliktavā.' 
      : language === 'RU' 
      ? 'Вы действительно хотите отменить этот заказ? Товары будут возвращены на склад.'
      : 'Are you sure you want to cancel this order? Items will be returned to stock.';

    if (confirm(confirmMsg)) {
      setIsUpdating(true);
      try {
        for (const item of order.items) {
          storeService.updateProductStock(item.id, item.quantity);
        }
        await new Promise(resolve => setTimeout(resolve, 600));
        storeService.updateOrderStatus(order.id, 'CANCELLED');
        loadData();
        setSelectedOrder(null);
        addToast(t.orderCancelled);
      } catch (err) {
        console.error("Cancellation failed:", err);
        alert("Action failed. Please try again.");
      } finally {
        setIsUpdating(false);
      }
    }
  };

  const handleGenerateInvoice = async (order: Order) => {
    if (user.role !== 'ADMIN') {
      alert('Only admins can generate invoices.');
      return;
    }

    try {
      const storedUser = storeService.getStoredUser();
      const token = storedUser?.token;
      
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/invoices/generate-from-order/${order.id}`, {
        method: 'POST',
        headers
      });
      if (res.ok) {
        const invoice = await res.json();
        setSelectedOrder(null);
        navigate(`/admin/invoices/${invoice.uuid}`);
      } else {
        const err = await res.json();
        alert(`Kļūda ģenerējot rēķinu: ${err.error || 'Nezināma kļūda'}`);
      }
    } catch (error) {
      console.error('Failed to generate invoice:', error);
      alert('Neizdevās sazināties ar serveri.');
    }
  };

  const handleExportData = async () => {
    try {
      await exportUserData(user);
      addToast('Dati veiksmīgi eksportēti');
    } catch (e) {
      addToast('Kļūda eksportējot datus');
    }
  };

  const handleDeleteAccount = () => {
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteAccount = async () => {
    try {
      await deleteAccountRequest(user.id);
      onLogout();
      setIsDeleteModalOpen(false);
    } catch (e: any) {
      alert(e.message || 'Cannot delete account');
      setIsDeleteModalOpen(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    let finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    
    if (name === 'vatNo') {
      finalValue = value.toUpperCase().replace(/^LV/, '').replace(/\D/g, '').slice(0, 11);
    }
    if (name === 'regNo') {
      finalValue = value.replace(/\D/g, '').slice(0, 11);
    }

    setSecurityForm(prev => ({ ...prev, [name]: finalValue }));
  };

  const StatBox = ({ icon: Icon, label, value, colorClass = "text-black", subtext }: { icon: any, label: string, value: string | number, colorClass?: string, subtext?: string }) => (
    <div className="bg-white border border-zinc-100 p-8 flex flex-col gap-4 shadow-sm group hover:border-black transition-all">
      <div className="w-10 h-10 flex items-center justify-center bg-zinc-50 text-zinc-300 group-hover:bg-black group-hover:text-white transition-all">
        <Icon size={18} />
      </div>
      <div>
        <p className="text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1">{label}</p>
        <p className={`text-2xl font-black ${colorClass}`}>{value}</p>
        {subtext && <p className="text-[8px] font-black text-zinc-300 uppercase mt-1 tracking-[0.1em]">{subtext}</p>}
      </div>
    </div>
  );

  const StatusBadge = ({ status }: { status: Order['status'] }) => {
    const config: any = {
      NEW: { icon: Clock, class: 'bg-zinc-50 text-zinc-500 border-zinc-100', text: t.statusNew },
      PAID: { icon: CheckCircle2, class: 'bg-emerald-50 text-emerald-600 border-emerald-100', text: t.statusPaid },
      PROCESSING: { icon: Clock, class: 'bg-amber-50 text-amber-600 border-amber-100', text: t.statusProcessing },
      IN_DELIVERY: { icon: Truck, class: 'bg-blue-50 text-blue-600 border-blue-100', text: t.statusInDelivery },
      SHIPPED: { icon: Package, class: 'bg-indigo-50 text-indigo-600 border-indigo-100', text: t.statusShipped },
      COMPLETED: { icon: CheckCircle2, class: 'bg-emerald-500 text-white border-emerald-600', text: t.statusCompleted },
      CANCELLED: { icon: Trash2, class: 'bg-rose-50 text-rose-600 border-rose-100', text: t.statusCancelled }
    };
    const active = config[status] || config.NEW;
    const { icon: Icon, class: className, text } = active;
    return (
      <span className={`px-4 py-1.5 border text-[9px] font-black uppercase tracking-widest flex items-center gap-2 w-fit ${className}`}>
        <Icon size={12} /> {text}
      </span>
    );
  };

  // Logic for real calculation of savings based on user's current discount level
  const totalNetSpent = useMemo(() => orders.filter(o => o.status !== 'CANCELLED' && o.status !== 'NEW').reduce((sum, o) => sum + o.total, 0), [orders]);
  const currentDiscount = user.discountLevel || 0;
  const calculatedSavings = useMemo(() => {
    if (currentDiscount <= 0) return 0;
    // Calculation: (DiscountedTotal / (1 - discount%)) - DiscountedTotal
    const originalPrice = totalNetSpent / (1 - currentDiscount / 100);
    return originalPrice - totalNetSpent;
  }, [totalNetSpent, currentDiscount]);

  const renderContent = () => {
    switch (activeTab) {
      case 'panel':
        return (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-500">
            {user.type === 'BUSINESS' && (
              <div className="bg-[#8DB835] p-10 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
                <div className="relative z-10">
                  <h3 className="text-xl font-black uppercase tracking-tight mb-2">{t.partnerZoneTitle}</h3>
                  <p className="text-[11px] font-bold uppercase tracking-widest opacity-90 leading-relaxed max-w-xl">
                    {t.partnerZoneDesc} {t.freeDeliveryOver200}
                  </p>
                </div>
              </div>
            )}
            <div className={`grid grid-cols-1 ${user.type === 'BUSINESS' ? 'md:grid-cols-3' : 'md:grid-cols-1 max-w-sm'} gap-6`}>
              <StatBox icon={History} label={t.orders} value={orders.length} subtext={t.last30days} />
              
              {user.type === 'BUSINESS' && (
                <>
                  <StatBox 
                    icon={Zap} 
                    label={t.totalSavings} 
                    value={`€ ${calculatedSavings.toFixed(2)}`} 
                    colorClass="text-[#8DB835]" 
                  />
                  <StatBox icon={ShieldCheck} label={t.partnerTier} value={user.discountLevel > 0 ? `${user.discountLevel}%` : (user.type === 'BUSINESS' ? '20%' : '0%')} subtext="PRO TIER" />
                </>
              )}
            </div>
            
            <div className="bg-white border border-zinc-100 p-10 shadow-sm">
               <div className="flex items-center justify-between mb-8">
                 <h2 className="text-lg font-black uppercase tracking-tight flex items-center gap-3">
                   <Package size={20} className="text-[#8DB835]" /> {t.recentActivity}
                 </h2>
                 <button onClick={() => setActiveTab('orders')} className="text-[10px] font-black text-zinc-300 hover:text-black uppercase tracking-widest flex items-center gap-2">
                   {t.viewAll} <ChevronRight size={14}/>
                 </button>
               </div>
               <div className="space-y-4">
                 {orders.length === 0 ? (
                   <div className="py-20 text-center border border-dashed border-zinc-100 bg-white flex flex-col items-center">
                      <ShoppingBag size={32} className="text-zinc-200 mb-4" />
                      <p className="text-[10px] font-black text-zinc-300 uppercase tracking-widest mb-6">No recent orders</p>
                      <button 
                        onClick={() => navigate('/')}
                        className="px-8 py-3 bg-black text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all"
                      >
                        {t.goToCatalog}
                      </button>
                   </div>
                 ) : (
                   orders.slice(0, 3).map((order, idx) => (
                     <div 
                       key={order.id || `order-${idx}`} 
                       onClick={() => setSelectedOrder(order)}
                       className="flex flex-col md:flex-row md:items-center justify-between p-6 border border-zinc-50 hover:bg-zinc-50 transition-all gap-4 cursor-pointer hover:border-black group"
                     >
                        <div className="flex gap-8 items-center">
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-zinc-300 mb-1">{t.orderId}</p>
                            <p className="text-xs font-black group-hover:text-[#8DB835] transition-colors">{order.invoiceNumber || order.id}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-zinc-300 mb-1">{t.date}</p>
                            <p className="text-xs font-bold text-zinc-500">{order.date}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-widest text-zinc-300 mb-1">{t.total}</p>
                            <p className="text-xs font-black">€{order.total.toFixed(2)}</p>
                          </div>
                        </div>
                        <StatusBadge status={order.status} />
                     </div>
                   ))
                 )}
               </div>
            </div>
          </div>
        );
      
      case 'orders':
        return (
          <div className="bg-white border border-zinc-100 shadow-sm overflow-x-auto animate-in fade-in duration-500 no-scrollbar">
            <table className="w-full text-left min-w-[800px]">
              <thead className="bg-zinc-50 border-b border-zinc-200 text-[9px] font-black uppercase tracking-widest text-zinc-400">
                <tr>
                  <th className="px-8 py-5">{t.orderId}</th>
                  <th className="px-8 py-5">{t.date}</th>
                  <th className="px-8 py-5">{t.items}</th>
                  <th className="px-8 py-5 text-right">{t.total}</th>
                  <th className="px-8 py-5 text-center">Status</th>
                  <th className="px-8 py-5 text-right">{t.action}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {orders.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-32 text-center">
                      <div className="flex flex-col items-center">
                        <Package size={48} className="text-zinc-100 mb-6" strokeWidth={1} />
                        <p className="text-[10px] font-black text-zinc-300 uppercase tracking-widest mb-8">Jums vēl nav neviena pasūtījuma</p>
                        <button 
                          onClick={() => navigate('/')}
                          className="px-10 py-4 bg-black text-white text-[11px] font-black uppercase tracking-[0.2em] hover:bg-[#8DB835] transition-all"
                        >
                          {t.goToCatalog}
                        </button>
                      </div>
                    </td>
                  </tr>
                ) : (
                  orders.map((order, idx) => (
                    <tr 
                      key={order.id || `order-${idx}`} 
                      className="hover:bg-zinc-50 transition-colors group cursor-pointer"
                      onClick={() => setSelectedOrder(order)}
                    >
                      <td className="px-8 py-6 text-xs font-black group-hover:text-[#8DB835] transition-colors">{order.rkfInvoiceNumber || order.invoiceNumber || order.id}</td>
                      <td className="px-8 py-6 text-xs font-bold text-zinc-500">{order.date}</td>
                      <td className="px-8 py-6 text-xs font-bold text-zinc-500">{order.itemsCount}m</td>
                      <td className="px-8 py-6 text-right text-xs font-black">€{order.total.toFixed(2)}</td>
                      <td className="px-8 py-6 flex justify-center"><StatusBadge status={order.status} /></td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button className="p-2 text-zinc-300 group-hover:text-black transition-colors"><ExternalLink size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        );

      case 'wishlist':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-500">
             {wishlistProducts.length === 0 ? (
               <div className="col-span-full py-24 text-center border border-dashed border-zinc-100 bg-white">
                  <Heart size={48} className="mx-auto text-zinc-100 mb-6" strokeWidth={1} />
                  <p className="text-[10px] font-black text-zinc-300 uppercase tracking-widest">{t.wishlistEmpty}</p>
               </div>
             ) : (
               wishlistProducts.map((p, idx) => (
                 <ProductCard 
                    key={p.id || p.sku || `wishlist-${idx}`}
                    product={p}
                    onAddToCart={onAddToCart}
                    onViewDetails={onViewDetails}
                    user={user}
                    language={language}
                    isWishlisted={true}
                    onToggleWishlist={() => onToggleWishlist(p.id)}
                 />
               ))
             )}
          </div>
        );

      case 'invoices':
        return (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="bg-black p-10 text-white">
              <h3 className="text-xl font-black uppercase tracking-tight mb-2">RĒĶINI / PAVADZĪMES</h3>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{t.billingDesc}</p>
            </div>
            <div className="bg-white border border-zinc-100 shadow-sm overflow-hidden">
              {orders.filter(o => o.status !== 'CANCELLED' && (o.prepaymentInvoiceUrl || o.invoiceUrl || o.deliveryDocumentUrl)).length === 0 ? (
                <div className="py-24 text-center">
                  <FileText size={48} className="mx-auto text-zinc-100 mb-6" strokeWidth={1} />
                  <p className="text-[10px] font-black text-zinc-300 uppercase tracking-widest">
                    {language === 'LV' ? 'Nav pieejamu rēķinu' : 
                     language === 'RU' ? 'Нет доступных счетов' : 
                     'No invoices available'}
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-zinc-50">
                  {orders.filter(o => o.status !== 'CANCELLED' && (o.prepaymentInvoiceUrl || o.invoiceUrl || o.deliveryDocumentUrl)).map((order, idx) => (
                    <div key={order.id || `invoice-${idx}`} className="flex flex-col border-b border-zinc-100 last:border-0">
                      
                      {/* Prepayment Invoice */}
                      {order.prepaymentInvoiceUrl && (
                        <div className="p-8 flex items-center justify-between hover:bg-zinc-50 transition-all group">
                          <div className="flex items-center gap-8">
                            <div className="w-12 h-12 bg-zinc-100 flex items-center justify-center text-zinc-400 group-hover:bg-black group-hover:text-white transition-all">
                              <FileText size={20} />
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">
                                  {language === 'LV' ? `PRIEKŠAPMAKSAS RĒĶINS ${order.invoiceNumber || order.id}` : 
                                   language === 'RU' ? `СЧЕТ НА ПРЕДОПЛАТУ ${order.invoiceNumber || order.id}` : 
                                   `ADVANCE INVOICE ${order.invoiceNumber || order.id}`}
                                </p>
                                <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-sm ${order.status !== 'NEW' ? 'bg-[#8DB835]/10 text-[#8DB835]' : 'bg-zinc-100 text-zinc-400'}`}>
                                  {order.status !== 'NEW' ? (
                                    language === 'LV' ? '[Apmaksāts]' : language === 'RU' ? '[Оплачен]' : '[Paid]'
                                  ) : (
                                    language === 'LV' ? '[Neapmaksāts]' : language === 'RU' ? '[Не оплачен]' : '[Unpaid]'
                                  )}
                                </span>
                              </div>
                              <p className="text-xs font-black">{order.date}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <a 
                              href={order.prepaymentInvoiceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 px-6 py-3 bg-zinc-100 text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all"
                            >
                              <Download size={14} /> {t.downloadPdf}
                            </a>
                          </div>
                        </div>
                      )}

                      {/* Invoice (Pavadzīme) */}
                      {order.invoiceUrl && (
                        <div className="p-8 flex items-center justify-between bg-zinc-50/50 hover:bg-zinc-100 transition-all group border-t border-zinc-100">
                          <div className="flex items-center gap-8">
                            <div className="w-12 h-12 bg-[#8DB835]/10 flex items-center justify-center text-[#8DB835] group-hover:bg-[#8DB835] group-hover:text-white transition-all">
                              <FileText size={20} />
                            </div>
                            <div>
                              <p className="text-[10px] font-black uppercase tracking-widest text-[#8DB835] mb-1">
                                {language === 'LV' ? `PAVADZĪME ${order.rkfInvoiceNumber || order.invoiceNumber || order.id}` : 
                                 language === 'RU' ? `НАКЛАДНАЯ ${order.rkfInvoiceNumber || order.invoiceNumber || order.id}` : 
                                 `INVOICE ${order.rkfInvoiceNumber || order.invoiceNumber || order.id}`}
                              </p>
                              <p className="text-xs font-black">{order.date}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <a 
                              href={order.invoiceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 px-6 py-3 bg-white border border-zinc-200 text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white hover:border-black transition-all"
                            >
                              <Download size={14} /> {t.downloadPdf}
                            </a>
                          </div>
                        </div>
                      )}

                      {/* Delivery Note */}
                      {order.deliveryDocumentUrl && (
                        <div className="p-8 flex items-center justify-between bg-zinc-50/50 hover:bg-zinc-100 transition-all group border-t border-zinc-100">
                          <div className="flex items-center gap-8">
                            <div className="w-12 h-12 bg-blue-500/10 flex items-center justify-center text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all">
                              <Truck size={20} />
                            </div>
                            <div>
                              <p className="text-[10px] font-black uppercase tracking-widest text-blue-500 mb-1">
                                {language === 'LV' ? `PIEGĀDES DOKUMENTS` : 
                                 language === 'RU' ? `ДОКУМЕНТ О ДОСТАВКЕ` : 
                                 `DELIVERY DOCUMENT`}
                              </p>
                              <p className="text-xs font-black">{order.date}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <a 
                              href={order.deliveryDocumentUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 px-6 py-3 bg-white border border-zinc-200 text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white hover:border-black transition-all"
                            >
                              <Download size={14} /> {t.downloadPdf}
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        );
      
      case 'settings':
        return (
          <div className="space-y-12 animate-in fade-in duration-500 pb-20">
            <form onSubmit={handleSecuritySubmit} className="relative overflow-visible">
              {isUpdating && (
                <div className="fixed inset-0 z-[100] bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center">
                  <Loader2 className="w-10 h-10 text-[#8DB835] animate-spin mb-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">{t.processing}</span>
                </div>
              )}
              
              {showSuccess && (
                <div className="fixed inset-0 z-[100] bg-emerald-50/95 flex flex-col items-center justify-center animate-in fade-in duration-300">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 flex items-center justify-center rounded-full mb-4">
                    <CheckCircle2 size={32} />
                  </div>
                  <p className="text-[11px] font-black uppercase tracking-widest text-emerald-900">{t.securityUpdated}</p>
                </div>
              )}

              {user.type === 'BUSINESS' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-12 mb-12">
                  <div className="bg-white border border-zinc-100 p-8 shadow-sm flex flex-col gap-6">
                    <h3 className="text-base font-black uppercase tracking-tight border-b border-zinc-100 pb-4 flex items-center gap-3">
                      <Building2 size={18} className="text-[#8DB835]" /> {t.companyDetails}
                    </h3>
                    <div className="space-y-4">
                      <label className="text-[10px] font-bold uppercase text-black">Uzņēmuma nosaukums <span className="text-rose-500">*</span></label>
                      <input name="companyName" value={securityForm.companyName} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.companyName} />
                      <label className="text-[10px] font-bold uppercase text-black">Reģistrācijas numurs <span className="text-rose-500">*</span></label>
                      <input name="regNo" value={securityForm.regNo} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.regNoHint} />
                      <input name="vatNo" value={securityForm.vatNo} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.vatNoHint} />
                      <label className="text-[10px] font-bold uppercase text-black">PVN numurs <span className="text-rose-500">*</span></label>
                    </div>
                  </div>

                  <div className="bg-white border border-zinc-100 p-8 shadow-sm flex flex-col gap-6">
                    <h3 className="text-base font-black uppercase tracking-tight border-b border-zinc-100 pb-4 flex items-center gap-3">
                      <User size={18} className="text-[#8DB835]" /> {t.personalInfo}
                    </h3>
                    <div className="space-y-4">
                      <input name="firstName" value={`${securityForm.firstName} ${securityForm.lastName}`} onChange={(e) => {
                        const parts = e.target.value.split(' ');
                        setSecurityForm(prev => ({ ...prev, firstName: parts[0] || '', lastName: parts.slice(1).join(' ') || '' }));
                      }} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.firstName} />
                      <input name="email" value={securityForm.email} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.email} />
                      <input name="phone" value={securityForm.phone} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.phone} />
                    </div>
                  </div>

                  <div className="bg-white border border-zinc-100 p-8 shadow-sm flex flex-col gap-6">
                    <h3 className="text-base font-black uppercase tracking-tight border-b border-zinc-100 pb-4 flex items-center gap-3">
                      <MapPin size={18} className="text-[#8DB835]" /> <span className="text-black">{t.addressLegal}</span>
                    </h3>
                    <div className="space-y-4">
                      <label className="text-[10px] font-bold uppercase text-black">Iela un mājas numurs <span className="text-rose-500">*</span></label>
                      <input name="legalAddress" value={securityForm.legalAddress} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.street} />
                      <div className="grid grid-cols-2 gap-4">
                        <label className="text-[10px] font-bold uppercase text-black">Pilsēta <span className="text-rose-500">*</span></label>
                        <input name="city" value={securityForm.city} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.city} />
                        <label className="text-[10px] font-bold uppercase text-black">Pasta indekss <span className="text-rose-500">*</span></label>
                        <input name="zipCode" value={securityForm.zipCode} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.postalCode} />
                      </div>
                      <div className="relative">
                        <select name="country" value={securityForm.country || 'Latvija'} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black appearance-none">
                          <option value="Latvija">Latvija</option>
                          <option value="Lietuva">Lietuva</option>
                          <option value="Estonia">Estonia</option>
                        </select>
                        <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-300 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-zinc-100 p-8 shadow-sm flex flex-col gap-6">
                    <h3 className="text-base font-black uppercase tracking-tight border-b border-zinc-100 pb-4 flex items-center gap-3">
                      <Truck size={18} className="text-[#8DB835]" /> {t.shippingAddress}
                    </h3>
                    <div className="space-y-4">
                      <input name="street" value={securityForm.street} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.street} />
                      <div className="grid grid-cols-2 gap-4">
                        <input name="city" value={securityForm.city} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.city} disabled />
                        <input name="zipCode" value={securityForm.zipCode} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.postalCode} disabled />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-zinc-100 p-8 shadow-sm flex flex-col gap-6">
                    <h3 className="text-base font-black uppercase tracking-tight border-b border-zinc-100 pb-4 flex items-center gap-3">
                      <CreditCard size={18} className="text-[#8DB835]" /> {t.bankDetails}
                    </h3>
                    <div className="space-y-4">
                      <input name="bankName" value={securityForm.bankName} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.bank} />
                      <input name="swift" value={securityForm.swift} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.swift} />
                      <input name="bankAccount" value={securityForm.bankAccount} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.iban} />
                    </div>
                  </div>

                  <div className="bg-white border border-zinc-100 p-8 shadow-sm flex flex-col gap-6">
                    <h3 className="text-base font-black uppercase tracking-tight border-b border-zinc-100 pb-4 flex items-center gap-3">
                      <Lock size={18} className="text-[#8DB835]" /> {t.updateSecurity}
                    </h3>
                    <div className="space-y-4">
                      <input type="password" name="currentPassword" value={securityForm.currentPassword} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.currentPassword} />
                      <input type="password" name="newPassword" value={securityForm.newPassword} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.newPassword} />
                      <input type="password" name="confirmPassword" value={securityForm.confirmPassword} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.confirmPassword} />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-12">
                  <div className="space-y-8">
                    <div className="flex items-center gap-4 mb-4 border-b pb-4">
                      <User size={20} className="text-[#8DB835]" />
                      <h3 className="text-[12px] font-black uppercase tracking-[0.2em]">{t.personalInfo}</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <input name="firstName" value={securityForm.firstName} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.firstName} />
                      <input name="lastName" value={securityForm.lastName} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.lastName} />
                    </div>
                    <input name="email" value={securityForm.email} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.email} />
                    <input name="phone" value={securityForm.phone} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.phone} />
                    <input name="physicalAddress" value={securityForm.physicalAddress} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.addressFields.street} />
                  </div>
                  <div className="space-y-8">
                    <div className="flex items-center gap-4 mb-4 border-b pb-4">
                      <Lock size={20} className="text-[#8DB835]" />
                      <h3 className="text-[12px] font-black uppercase tracking-[0.2em]">{t.updateSecurity}</h3>
                    </div>
                    <input type="password" name="currentPassword" value={securityForm.currentPassword} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.currentPassword} />
                    <input type="password" name="newPassword" value={securityForm.newPassword} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.newPassword} />
                    <input type="password" name="confirmPassword" value={securityForm.confirmPassword} onChange={handleInputChange} className="w-full bg-white border-2 border-zinc-300 px-5 py-4 text-xs font-bold text-black focus:outline-none focus:border-black placeholder:text-zinc-400" placeholder={t.confirmPassword} />
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-6 mb-12">
                <button 
                  type="submit"
                  className="px-12 py-5 bg-black text-white text-[11px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-4 hover:bg-zinc-800 transition-all shadow-xl active:scale-95"
                >
                  <Save size={16} /> {t.saveChanges}
                </button>
              </div>
            </form>

            <div className="bg-rose-50 border border-rose-100 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
               <div className="flex items-start gap-4">
                  <AlertTriangle className="text-rose-500 shrink-0" size={24} />
                  <div>
                    <h4 className="text-[11px] font-black uppercase text-rose-900 mb-1">{t.dangerZone}</h4>
                    <p className="text-[10px] text-rose-700 uppercase font-medium max-w-md">{t.dangerZoneDesc}</p>
                  </div>
               </div>
               <div className="flex flex-col sm:flex-row gap-4">
                 <button onClick={handleExportData} className="px-8 py-4 border-2 border-zinc-200 text-zinc-600 text-[10px] font-black uppercase hover:bg-zinc-100 transition-all">
                   Eksportēt Datus (JSON)
                 </button>
                 <button onClick={handleDeleteAccount} className="px-8 py-4 border-2 border-rose-200 text-rose-500 text-[10px] font-black uppercase hover:bg-rose-500 hover:text-white transition-all">
                   {t.deleteAccount}
                 </button>
               </div>
            </div>
          </div>
        );
      
      default:
        return <div className="p-20 text-center bg-white border">Coming soon</div>;
    }
  };

  return (
    <section className="py-24 container mx-auto px-4 max-w-7xl animate-in fade-in duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-4 space-y-8">
          <div className="p-10 border-2 border-black bg-white flex flex-col gap-8 min-h-[220px] justify-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#8DB835]/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
            <div className="flex items-center gap-6 relative z-10">
              <div className="w-16 h-16 bg-black text-white flex items-center justify-center font-black text-2xl shrink-0">
                {user.type === 'BUSINESS' ? user.companyName?.charAt(0).toUpperCase() : user.firstName?.charAt(0).toUpperCase()}
              </div>
              <div className="flex flex-col gap-1">
                <h3 className="text-lg font-black uppercase tracking-tight leading-none">
                  {user.type === 'BUSINESS' ? (user.companyName || user.firstName) : `${user.firstName} ${user.lastName}`}
                </h3>
                <p className="text-[11px] text-zinc-400 font-bold">{user.email}</p>
              </div>
            </div>
            <div className="pt-2 border-t border-zinc-100 relative z-10">
              <span className="inline-block px-4 py-2 bg-black text-white text-[10px] font-black uppercase tracking-[0.2em]">
                {user.type === 'BUSINESS' ? t.b2bAccount : t.b2cAccount}
              </span>
            </div>
          </div>

          <nav className="flex flex-col border border-zinc-100 bg-white shadow-sm overflow-hidden">
            {[
              { id: 'panel', icon: Layout, label: t.panel },
              { id: 'orders', icon: Package, label: t.orders },
              { id: 'wishlist', icon: Heart, label: t.wishlist },
              { id: 'invoices', icon: FileText, label: 'RĒĶINI / PAVADZĪMES' },
              { id: 'settings', icon: Settings, label: t.settings }
            ].map((item) => (
              <button 
                key={item.id} 
                onClick={() => setActiveTab(item.id as any)}
                className={`flex items-center justify-between p-6 text-[11px] font-black uppercase tracking-[0.2em] transition-all border-b border-zinc-50 last:border-0 group ${activeTab === item.id ? 'text-black bg-zinc-50' : 'text-zinc-400 hover:text-black hover:bg-zinc-50'}`}
              >
                <div className="flex items-center gap-5">
                  <item.icon size={16} className={`${
                    (item.id === 'orders' && orders.length > 0) || 
                    (item.id === 'wishlist' && wishlistProducts.length > 0) || 
                    (item.id === 'invoices' && orders.length > 0) 
                      ? 'text-[#8DB835]' 
                      : activeTab === item.id ? 'text-black' : 'text-zinc-300 group-hover:text-black'
                  } transition-colors`} />
                  {item.label}
                </div>
              </button>
            ))}
            <button onClick={onLogout} className="p-6 text-[11px] font-black uppercase tracking-[0.2em] text-rose-500 hover:bg-rose-50 transition-all flex items-center gap-5">
              <LogOut size={16} /> {t.logout}
            </button>
          </nav>
        </div>

        <div className="lg:col-span-8">
          {renderContent()}
        </div>
      </div>

      {selectedOrder && (
        <OrderDetailsModal 
          order={selectedOrder} 
          onClose={() => setSelectedOrder(null)} 
          language={language} 
          onCancel={handleCancelOrder}
          user={user}
          onGenerateInvoice={handleGenerateInvoice}
        />
      )}

      <div className="fixed bottom-10 right-10 z-[250] flex flex-col gap-3 pointer-events-none">
        {toasts.map(toast => (
          <Toast key={toast.id} id={toast.id} message={toast.message} onClose={removeToast} />
        ))}
      </div>

      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsDeleteModalOpen(false)} />
          <div className="relative w-full max-w-md bg-white shadow-2xl border-2 border-black p-8 animate-in zoom-in-95 duration-300">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 bg-rose-100 text-rose-600 flex items-center justify-center rounded-full mb-2">
                <AlertTriangle size={32} />
              </div>
              <h3 className="text-xl font-black uppercase tracking-tight text-rose-600">{t.deleteAccount}</h3>
              <p className="text-sm font-medium text-zinc-600 mb-6">{t.deleteConfirm}</p>
              
              <div className="flex gap-4 w-full">
                <button 
                  onClick={() => setIsDeleteModalOpen(false)}
                  className="flex-1 py-4 border-2 border-zinc-200 text-zinc-600 font-black uppercase tracking-widest text-xs hover:bg-zinc-50 transition-colors"
                >
                  {t.cancel}
                </button>
                <button 
                  onClick={confirmDeleteAccount}
                  className="flex-1 py-4 bg-rose-600 text-white font-black uppercase tracking-widest text-xs hover:bg-rose-700 transition-colors"
                >
                  {t.deleteAccount}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-[400] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setIsDeleteModalOpen(false)} />
          <div className="relative w-full max-w-md bg-white border-2 border-black p-10 animate-in zoom-in-95 duration-300">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-rose-50 text-rose-500 flex items-center justify-center rounded-full mb-8">
                <AlertTriangle size={40} />
              </div>
              <h3 className="text-xl font-black uppercase tracking-tight mb-4">{t.dangerZone}</h3>
              <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest leading-relaxed mb-10">
                {t.deleteConfirm}
              </p>
              <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => setIsDeleteModalOpen(false)}
                  className="py-4 border-2 border-black text-[11px] font-black uppercase tracking-widest hover:bg-zinc-50 transition-all"
                >
                  {t.cancel}
                </button>
                <button 
                  onClick={confirmDeleteAccount}
                  className="py-4 bg-rose-500 text-white text-[11px] font-black uppercase tracking-widest hover:bg-rose-600 transition-all shadow-lg"
                >
                  {t.deleteAccount}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default UserDashboard;
