import React, { useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { X, Loader2, CheckCircle2, Package, Truck, ShoppingBag, Building2, Weight, Info, Clock, Percent, FileText } from 'lucide-react';
import { TRANSLATIONS, VAT_RATE } from '../constants';
import { Language, CartItem, User as UserType, Order, OmnivaLocation, DPDLocation } from '../types';
import { sendOrderNotification } from '../services/mailService';
import { storeService } from '../services/storeService';
import { deliveryService } from '../services/deliveryService';
import { generateROKOFInvoice } from '../services/invoiceService';
import { getPersonalizedPrice } from '../src/utils/calculations';
import ShippingSelector from './ShippingSelector';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  cart: CartItem[];
  onSuccess: () => void;
  user: UserType | null;
  onUpdateUser?: (u: UserType) => void;
}

const WAREHOUSE_ADDRESS = "Rīga, Puces iela 11/1-7 (ROKOF SIA noliktava)";
const FREE_DELIVERY_THRESHOLD = 200.00;

const CheckoutModal: React.FC<CheckoutModalProps> = ({ 
  isOpen, onClose, language, cart, onSuccess, user, onUpdateUser
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderCompleted, setOrderCompleted] = useState<Order | null>(null);
  const [selectedDeliveryId, setSelectedDeliveryId] = useState('omniva');
  const [selectedPickupPoint, setSelectedPickupPoint] = useState('');
  const [selectedStationId, setSelectedStationId] = useState('');
  const [courierAddress, setCourierAddress] = useState('');
  
  const [omnivaLocations, setOmnivaLocations] = useState<OmnivaLocation[]>([]);
  const [dpdLocations, setDPDLocations] = useState<DPDLocation[]>([]);
  const [isLoadingLocations, setIsLoadingLocations] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [comment, setComment] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'invoice' | 'montonio'>('invoice');

  const { t: translate } = useTranslation();
  const navigate = useNavigate();
  const t = TRANSLATIONS[language];
  const cm = t.checkoutModal;

  const deliveryMethods = [
    { id: 'omniva', name: 'Omniva Pakomāts', price: 3.50, icon: Package, time: '5-7 d.' },
    { id: 'dpd', name: 'DPD Pickup', price: 3.00, icon: Truck, time: '5-7 d.' },
    { id: 'courier', name: cm.courier, price: 7.00, icon: Truck, time: '5-7 d.' },
    { id: 'pickup_store', name: cm.pickupWarehouse, price: 0, icon: Building2, time: '5 d.' },
  ];

  const [formData, setFormData] = useState({ 
    email: '', 
    firstName: '', 
    lastName: '', 
    phone: '', 
    agreedTerms: false,
    street: '',
    building: '',
    apartment: '',
    city: '',
    district: '',
    zip: '',
    country: ''
  });

  // Volume Discount Logic
  const totalMeters = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);
  const volumeDiscountRate = useMemo(() => {
    if (user?.type === 'BUSINESS') return 0;
    if (totalMeters >= 100) return 10;
    if (totalMeters >= 50) return 5;
    return 0;
  }, [totalMeters, user]);

  const rawSubtotalItems = useMemo(() => {
    return cart.reduce((sum, item) => {
      const price = getPersonalizedPrice(item.price, item.b2bPrice, user);
      return sum + (price * item.quantity);
    }, 0);
  }, [cart, user, isOpen]);

  const volumeDiscountValueNet = rawSubtotalItems * (volumeDiscountRate / 100);
  const subtotalItems = rawSubtotalItems - volumeDiscountValueNet;

  const isFreeDelivery = user?.type === 'BUSINESS' && subtotalItems >= FREE_DELIVERY_THRESHOLD;

  useEffect(() => {
    if (isOpen) {
      setOrderCompleted(null);
      setIsProcessing(false);
      
      const load = async () => {
        setIsLoadingLocations(true);
        try {
          const [omniva, dpd] = await Promise.all([
            deliveryService.getOmnivaLocations(),
            deliveryService.getDPDLocations()
          ]);
          setOmnivaLocations(omniva);
          setDPDLocations(dpd);
          
          if (selectedDeliveryId === 'omniva' && omniva.length > 0 && !selectedPickupPoint) {
            setSelectedPickupPoint(`${omniva[0].NAME} - ${omniva[0].A5_NAME}`);
            setSelectedStationId(omniva[0].ZIP);
          } else if (selectedDeliveryId === 'dpd' && dpd.length > 0 && !selectedPickupPoint) {
            setSelectedPickupPoint(dpd[0].name);
            setSelectedStationId(dpd[0].id);
          }
        } finally {
          setIsLoadingLocations(false);
        }
      };
      load();

      if (user) {
        setFormData({
          email: user.email || '',
          firstName: user.firstName || '',
          lastName: user.lastName || '',
          phone: user.phone || '+371 ',
          agreedTerms: true,
          street: user.street || '',
          building: user.building || '',
          apartment: user.apartment || '',
          city: user.city || '',
          district: user.district || '',
          zip: user.zipCode || '',
          country: user.country || 'Latvija'
        });
        if (user.physicalAddress) setCourierAddress(user.physicalAddress);
      }
    }
  }, [isOpen]);

  useEffect(() => {
    if (selectedDeliveryId === 'pickup_store') {
      setSelectedPickupPoint(WAREHOUSE_ADDRESS);
    } else if (selectedDeliveryId === 'courier') {
      setSelectedPickupPoint(courierAddress || 'Kurjera piegāde');
    }
  }, [selectedDeliveryId, courierAddress]);

  if (!isOpen) return null;

  const currentMethod = deliveryMethods.find(m => m.id === selectedDeliveryId);
  const deliveryCost = isFreeDelivery ? 0 : (currentMethod?.price || 0);
  const totalNet = subtotalItems + deliveryCost;
  const vatAmount = totalNet * VAT_RATE;
  const totalGross = totalNet + vatAmount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalAddress = selectedDeliveryId === 'courier' ? courierAddress : selectedPickupPoint;

    // Profile Completion Validation
    if (user) {
      const isB2B = user.type === 'BUSINESS';
      const nameField = isB2B ? user.companyName : user.firstName;
      const addressField = isB2B ? user.legalAddress : user.physicalAddress;

      if (!nameField || nameField.trim() === '' || !addressField || addressField.trim() === '') {
        alert(t.profileCompletionPrompt);
        navigate('/profile/settings');
        onClose();
        return;
      }
    }
    
    if (cart.length === 0) {
      alert(translate('checkout_errors.empty_cart'));
      return;
    }

    if (!formData.email.includes('@') || !finalAddress) {
      alert(translate('checkout_errors.missing_fields'));
      return;
    }

    if (paymentMethod === 'montonio') {
      alert(
        "Montonio maksājumu sistēma šobrīd tiek konfigurēta.\n\n" +
        "Lūdzu, izmantojiet apmaksu ar rēķinu – mēs to tūlīt nosūtīsim uz Jūsu e-pastu."
      );
      setPaymentMethod('invoice');
      return;
    }
    
    setIsProcessing(true);
    try {
      const allOrders = await storeService.getOrders(user?.id);
      const nextOrderNumber = (allOrders.length + 1).toString().padStart(4, '0');
      const generatedOrderId = `ROK-${nextOrderNumber}`;

      // Send to API
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user?.id || 'guest',
          items: cart.map(item => ({
            id: item.id,
            sku: item.sku,
            title: item.title[language],
            image: item.images?.[0] || '',
            quantity: item.quantity,
            price: getPersonalizedPrice(item.price, item.b2bPrice, user),
            weightPerMeter: item.specifications?.weightPerMeter || 0
          })),
          total: totalNet,
          deliveryCost,
          deliveryMethod: `${currentMethod?.name} (${isFreeDelivery ? 'BEZMAKSAS' : deliveryCost.toFixed(2) + '€'})`,
          shippingAddress: finalAddress,
          stationId: (selectedDeliveryId === 'omniva' || selectedDeliveryId === 'dpd') ? selectedStationId : undefined,
          customerInfo: {
            name: `${formData.firstName} ${formData.lastName}`,
            email: formData.email,
            phone: formData.phone,
            address: finalAddress,
            street: selectedDeliveryId === 'courier' ? courierAddress : formData.street,
            building: formData.building,
            apartment: formData.apartment,
            city: formData.city,
            district: formData.district,
            zipCode: formData.zip,
            country: formData.country,
            ...(user && (user.type === 'BUSINESS' || !!user.regNo) ? {
              companyName: user.companyName,
              regNo: user.regNo,
              vatNo: user.vatNo,
              legalAddress: user.legalAddress,
              company: true,
              customerType: 'b2b'
            } : {
              customerType: 'b2c'
            })
          },
          comment,
          language // Add language here
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create order');
      }

      const createdOrder = await response.json();

      // Also save to local storage for redundancy if needed, but using the server response
      // storeService.saveOrder(createdOrder); 

      // Update stock locally (optimistic)
      cart.forEach(item => {
        storeService.updateProductStock(item.id, -item.quantity);
      });

      setOrderCompleted(createdOrder);
      localStorage.removeItem('rokof_guest_cart_v1');
      onSuccess();
    } catch (err) { 
      console.error(err);
      alert("Error processing order. Please try again.");
    } finally { 
      setIsProcessing(false); 
    }
  };

  const omnivaOptions = omnivaLocations.map(l => ({
    id: l.ZIP,
    name: `${l.NAME} - ${l.A5_NAME}`,
    address: l.A5_NAME,
    city: l.A2_NAME
  }));

  const dpdOptions = dpdLocations.map(l => ({
    id: l.id,
    name: l.name,
    address: l.address,
    city: l.city
  }));

  if (orderCompleted) {
    return (
      <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
        <div className="relative w-full max-w-lg bg-white p-16 text-center shadow-2xl border-2 border-black animate-in zoom-in-95 duration-300">
           <div className="w-24 h-24 bg-[#8DB835] text-white flex items-center justify-center mx-auto mb-10 shadow-lg">
              <CheckCircle2 size={48} />
           </div>
           <h2 className="text-2xl font-black uppercase tracking-tight mb-4 text-black">{cm.thanks}</h2>
           <p className="text-zinc-400 text-[11px] font-black uppercase tracking-[0.3em] mb-12">{cm.orderNo} {orderCompleted.id}</p>
           
           <div className="flex flex-col gap-4">
             <button 
               onClick={async () => {
                 setIsGeneratingPdf(true);
                 try {
                   await generateROKOFInvoice(
                     { ...orderCompleted, number: orderCompleted.id },
                     { ...orderCompleted.customerInfo, ...user },
                     language
                   );
                 } finally {
                   setIsGeneratingPdf(false);
                 }
               }}
               disabled={isGeneratingPdf}
               className="w-full py-6 border-2 border-black text-black text-[12px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all flex items-center justify-center gap-3 disabled:opacity-50"
             >
               {isGeneratingPdf ? (
                 <><Loader2 size={18} className="animate-spin" /> {cm.generatingInvoice}</>
               ) : (
                 <><FileText size={18} /> {t.downloadPdf}</>
               )}
             </button>
             <button onClick={onClose} className="w-full py-6 bg-black text-white text-[12px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all">{cm.close}</button>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-2 md:p-6 overflow-hidden">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-6xl bg-white flex flex-col shadow-2xl h-full max-h-[90vh] border-2 border-black animate-in slide-in-from-bottom-4 duration-500 overflow-hidden">
        
        <div className="p-6 md:p-8 border-b-2 border-black bg-black text-white flex items-center justify-between shrink-0">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-[#8DB835] uppercase tracking-[0.4em] mb-1">{cm.header}</span>
            <h2 className="text-xl md:text-2xl font-black uppercase tracking-tight">{cm.process}</h2>
          </div>
          <button 
            onClick={onClose} 
            aria-label="Close Checkout"
            className="p-3 hover:bg-zinc-800 transition-colors focus:outline-none focus:ring-2 focus:ring-white"
          ><X size={32} /></button>
        </div>

        <div className="flex-grow flex flex-col lg:flex-row overflow-hidden relative">
          {isProcessing && (
            <div className="absolute inset-0 z-[120] bg-white/90 flex flex-col items-center justify-center">
              <Loader2 className="w-16 h-16 text-[#8DB835] animate-spin mb-6" />
              <span className="text-[12px] font-black uppercase tracking-[0.5em] text-black">{cm.processing}</span>
            </div>
          )}

          {/* Left Column: Delivery and Contact Form */}
          <div className="flex-grow overflow-y-auto p-6 md:p-12 space-y-10 no-scrollbar">
            <div className="space-y-6">
              <div className="flex items-center gap-4 border-l-4 border-[#8DB835] pl-4">
                <h3 className="text-[14px] font-black uppercase tracking-widest text-black">{cm.chooseDelivery}</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
                {deliveryMethods.map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => setSelectedDeliveryId(method.id)}
                    aria-label={`Select delivery method: ${method.name}`}
                    aria-pressed={selectedDeliveryId === method.id}
                    className={`p-4 md:p-6 border-2 text-left flex flex-col gap-3 transition-all focus:outline-none focus:ring-2 focus:ring-black ${
                      selectedDeliveryId === method.id ? 'bg-[#F9F4E8] border-[#8DB835] shadow-lg' : 'bg-white border-zinc-100 hover:border-black'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className={`w-10 h-10 md:w-12 md:h-12 flex items-center justify-center border-2 ${selectedDeliveryId === method.id ? 'bg-black text-white border-black' : 'bg-zinc-50 text-zinc-300'}`}>
                        <method.icon size={20} />
                      </div>
                    </div>
                    <div>
                      <span className="text-[11px] md:text-[13px] font-black text-black uppercase block leading-tight">{method.name}</span>
                      <span className="text-[9px] md:text-[11px] font-black text-[#8DB835] block mt-1">
                        {isFreeDelivery ? cm.free : `€ ${method.price.toFixed(2)}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-auto pt-2 border-t border-zinc-100">
                      <Clock size={12} className="text-zinc-400" />
                      <span className="text-[8px] font-bold uppercase text-zinc-400">{method.time}</span>
                    </div>
                  </button>
                ))}
              </div>
              <div className="flex items-start gap-3 p-4 bg-zinc-50 border border-zinc-100 mt-2">
                <Info size={16} className="text-[#8DB835] shrink-0 mt-0.5" />
                <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 leading-relaxed">
                  {selectedDeliveryId === 'pickup_store' ? cm.estDeliveryTimeWarehouse : t.estDeliveryTime}
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-4 border-l-4 border-black pl-4">
                <h3 className="text-[14px] font-black uppercase tracking-widest text-black">
                  {selectedDeliveryId === 'courier' ? cm.enterAddress : cm.choosePoint}
                </h3>
              </div>
              
              <div className="min-h-[80px]">
                {selectedDeliveryId === 'courier' ? (
                  <input 
                    type="text" 
                    placeholder={cm.addressPlaceholder} 
                    value={courierAddress}
                    onChange={(e) => setCourierAddress(e.target.value)}
                    className="w-full bg-white border-2 border-zinc-300 px-8 py-6 text-xs font-black text-black focus:outline-none focus:border-black uppercase tracking-widest placeholder:text-zinc-400"
                  />
                ) : selectedDeliveryId === 'pickup_store' ? (
                  <div className="p-8 bg-zinc-50 border-2 border-black border-dashed flex items-center gap-6">
                    <Building2 className="text-[#8DB835]" size={32} />
                    <div>
                      <span className="text-[12px] font-black uppercase text-black block">{cm.warehouseLabel}</span>
                      <span className="text-[10px] font-bold text-zinc-400 uppercase">{cm.warehouseAddress}</span>
                    </div>
                  </div>
                ) : (
                  <ShippingSelector 
                    locations={selectedDeliveryId === 'omniva' ? omnivaOptions : dpdOptions}
                    selectedId={selectedPickupPoint}
                    onSelect={(id, fullName) => {
                      setSelectedPickupPoint(fullName);
                      setSelectedStationId(id);
                    }}
                    placeholder={selectedDeliveryId === 'omniva' ? cm.searchOmniva : cm.searchDPD}
                    isLoading={isLoadingLocations}
                    translations={{
                      prompt: cm.searchPrompt,
                      loading: cm.loading,
                      nothingFound: cm.nothingFound,
                      selectedPointLabel: cm.selectedPointLabel
                    }}
                  />
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-black tracking-widest pl-1 mb-1 block">{t.firstName}</label>
                <input type="text" placeholder={t.firstName} value={formData.firstName} onChange={(e) => setFormData({...formData, firstName: e.target.value})} className="w-full bg-white border-2 border-zinc-300 px-6 py-4 text-xs font-black !text-black focus:outline-none focus:border-black placeholder:text-zinc-400" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-black tracking-widest pl-1 mb-1 block">{t.lastName}</label>
                <input type="text" placeholder={t.lastName} value={formData.lastName} onChange={(e) => setFormData({...formData, lastName: e.target.value})} className="w-full bg-white border-2 border-zinc-300 px-6 py-4 text-xs font-black !text-black focus:outline-none focus:border-black placeholder:text-zinc-400" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-black tracking-widest pl-1 mb-1 block">{cm.emailLabel}</label>
                <input type="email" placeholder="example@mail.com" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full bg-white border-2 border-zinc-300 px-6 py-4 text-xs font-black !text-black focus:outline-none focus:border-black placeholder:text-zinc-400" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-black tracking-widest pl-1 mb-1 block">{cm.phoneLabel}</label>
                <input type="tel" placeholder="+371 ..." value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="w-full bg-white border-2 border-zinc-300 px-6 py-4 text-xs font-black !text-black focus:outline-none focus:border-black placeholder:text-zinc-400" />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-black tracking-widest pl-1 mb-1 block">{cm.commentLabel}</label>
              <textarea 
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-white border-2 border-zinc-300 px-6 py-4 text-xs font-black !text-black focus:outline-none focus:border-black min-h-[100px] resize-none placeholder:text-zinc-400"
                placeholder={cm.commentPlaceholder}
              />
            </div>

            <div className="space-y-4 pt-6 border-t border-zinc-100">
              <h3 className="text-[14px] font-black uppercase tracking-widest text-black">Maksājuma veids</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <label className={`cursor-pointer p-4 border-2 flex items-center gap-4 transition-all ${paymentMethod === 'invoice' ? 'border-[#8DB835] bg-[#F9F4E8]' : 'border-zinc-100 bg-white hover:border-zinc-300'}`}>
                  <input type="radio" name="payment" className="hidden" checked={paymentMethod === 'invoice'} onChange={() => setPaymentMethod('invoice')} />
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'invoice' ? 'border-[#8DB835]' : 'border-zinc-300'}`}>
                    {paymentMethod === 'invoice' && <div className="w-2.5 h-2.5 rounded-full bg-[#8DB835]" />}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-black uppercase">Ar rēķinu</span>
                    <span className="text-[10px] text-zinc-400 font-bold uppercase">Saņemt e-pastā</span>
                  </div>
                </label>
                
                <label className={`cursor-pointer p-4 border-2 flex items-center gap-4 transition-all ${paymentMethod === 'montonio' ? 'border-[#8DB835] bg-[#F9F4E8]' : 'border-zinc-100 bg-white hover:border-zinc-300'}`}>
                  <input type="radio" name="payment" className="hidden" checked={paymentMethod === 'montonio'} onChange={() => setPaymentMethod('montonio')} />
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${paymentMethod === 'montonio' ? 'border-[#8DB835]' : 'border-zinc-300'}`}>
                    {paymentMethod === 'montonio' && <div className="w-2.5 h-2.5 rounded-full bg-[#8DB835]" />}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-black uppercase">Montonio</span>
                    <span className="text-[10px] text-zinc-400 font-bold uppercase">Internetbanka</span>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Right Column: Order Summary */}
          <div className="w-full lg:w-[400px] bg-zinc-50 border-t-2 lg:border-t-0 lg:border-l-2 border-black flex flex-col shrink-0 relative overflow-hidden">
            <div className="flex-grow overflow-y-auto p-8 md:p-10 space-y-8 no-scrollbar">
              <div className="flex items-center gap-3 border-b border-zinc-200 pb-6">
                <ShoppingBag size={24} className="text-[#8DB835]" />
                <h3 className="text-[16px] font-black uppercase tracking-tight">{cm.orderSummary}</h3>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between text-[11px] font-black uppercase text-zinc-400">
                  <span>{cm.itemsSum}</span>
                  <span className="text-black">€ {rawSubtotalItems.toFixed(2)}</span>
                </div>

                {volumeDiscountRate > 0 && (
                  <div className="flex justify-between text-[11px] font-black uppercase text-[#8DB835]">
                    <span className="flex items-center gap-2"><Percent size={14} /> {t.volumeDiscountLabel.replace('{m}', totalMeters.toString())}</span>
                    <span>-€ {volumeDiscountValueNet.toFixed(2)} (-{volumeDiscountRate}%)</span>
                  </div>
                )}

                <div className="flex justify-between text-[11px] font-black uppercase text-[#8DB835]">
                  <span>{cm.deliveryLabel} ({currentMethod?.name})</span>
                  <span>{isFreeDelivery ? cm.free : `€ ${deliveryCost.toFixed(2)}`}</span>
                </div>
                
                {selectedPickupPoint && selectedDeliveryId !== 'courier' && (
                  <div className="text-[10px] font-bold text-zinc-500 bg-white p-3 border border-zinc-200 flex flex-col gap-1">
                    <span className="font-black text-black uppercase">{cm.selectedPoint}:</span>
                    <span className="uppercase">{selectedPickupPoint}</span>
                  </div>
                )}

                {user?.type === 'BUSINESS' ? (
                  isFreeDelivery ? (
                    <div className="p-3 bg-[#8DB835]/10 border border-[#8DB835] border-dashed text-[9px] font-black uppercase text-[#8DB835] flex items-center gap-2">
                      <CheckCircle2 size={12} /> {t.freeDelivery}
                    </div>
                  ) : (
                    <div className="p-3 bg-white border border-[#8DB835] border-dashed text-[9px] font-black uppercase text-zinc-500">
                      {t.freeDeliveryRemaining.replace('{amount}', `€${(FREE_DELIVERY_THRESHOLD - subtotalItems).toFixed(2)}`)}
                    </div>
                  )
                ) : null}
                <div className="h-px bg-zinc-200 my-4" />
                <div className="flex justify-between text-[11px] font-black uppercase text-zinc-400">
                  <span>{t.vatAmount}</span>
                  <span className="text-black">€ {vatAmount.toFixed(2)}</span>
                </div>
                
                <div className="pt-8 space-y-2">
                   <p className="text-[12px] font-black text-zinc-400 uppercase tracking-widest">{cm.totalPayment}:</p>
                   <p className="text-[42px] md:text-[48px] font-black text-black tracking-tighter leading-none">€ {totalGross.toFixed(2)}</p>
                </div>

                <div className="flex items-center gap-2 text-zinc-400 pt-6">
                   <Weight size={14} />
                   <span className="text-[9px] font-black uppercase">{t.totalWeight}: {(cart.reduce((acc, i) => acc + (Number(i.specifications?.weightPerMeter || 0) * Number(i.quantity || 0)), 0)).toFixed(2)} kg</span>
                </div>
              </div>
            </div>

            {/* Sticky Footer for Right Column */}
            <div className="p-8 md:p-10 bg-zinc-50 border-t-2 border-black sticky bottom-0 z-10">
              <button 
                onClick={handleSubmit}
                aria-label={t.placeOrder}
                className="w-full py-6 bg-black text-white text-[14px] font-black uppercase tracking-[0.2em] hover:bg-[#8DB835] transition-all shadow-xl active:scale-[0.98] focus:outline-none focus:ring-2 focus:ring-[#8DB835]"
              >
                {t.placeOrder}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;
