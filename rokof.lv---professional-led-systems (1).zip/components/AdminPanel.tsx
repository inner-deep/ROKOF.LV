
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  X, Plus, Pencil, Trash2, Save, Database, 
  Search, Package, Tag, Layers, Zap, Shield, Weight,
  ShoppingBag, Download, FileText, CheckCircle2, Clock, Loader2, Eye, Printer, Users, QrCode, Truck, Upload, Hash
} from 'lucide-react';
import { Product, Category, Language, Order } from '../types';
import { storeService } from '../services/storeService';
import { generateROKOFInvoice } from '../services/invoiceService';
import InvoiceList from '../src/components/admin/invoices/InvoiceList';
import { TRANSLATIONS } from '../constants';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose, language }) => {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [generatingPdfId, setGeneratingPdfId] = useState<string | null>(null);
  const [printingId, setPrintingId] = useState<string | null>(null);
  const [previewPdfUrl, setPreviewPdfUrl] = useState<string | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [searchParams] = useSearchParams();
  const initialTab = (searchParams.get('tab') as any) || 'products';
  const [activeTab, setActiveTab] = useState<'products' | 'inventory' | 'categories' | 'orders' | 'customers' | 'analytics' | 'invoices'>(initialTab);
  const [isUploading, setIsUploading] = useState(false);
  const [importResult, setImportResult] = useState<{createdCount: number, updatedCount: number, errorCount: number, errors: any[]} | null>(null);
  
  const [selectedOrderForModal, setSelectedOrderForModal] = useState<any | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [adminInternalNote, setAdminInternalNote] = useState('');
  const [adminTrackingNumber, setAdminTrackingNumber] = useState('');
  const [isSavingAdminFields, setIsSavingAdminFields] = useState(false);
  const [selectedDeliveryFile, setSelectedDeliveryFile] = useState<File | null>(null);
  const [isUploadingDelivery, setIsUploadingDelivery] = useState(false);
  const [selectedPrepaymentFile, setSelectedPrepaymentFile] = useState<File | null>(null);
  const [isUploadingPrepayment, setIsUploadingPrepayment] = useState(false);
  const [selectedInvoiceFile, setSelectedInvoiceFile] = useState<File | null>(null);
  const [isUploadingInvoice, setIsUploadingInvoice] = useState(false);
  const [editingWarranty, setEditingWarranty] = useState<{itemId: string, date: string} | null>(null);
  const [analyticsData, setAnalyticsData] = useState<any>(null);
  const [isLoadingAnalytics, setIsLoadingAnalytics] = useState(false);

  const fetchWithAuth = async (url: string, options: RequestInit = {}) => {
    let token = localStorage.getItem('token');
    if (token && token.startsWith('"') && token.endsWith('"')) {
      token = token.slice(1, -1);
    }
    const headers = {
      ...options.headers,
      'Authorization': `Bearer ${token}`
    } as Record<string, string>;

    if (options.body && !(options.body instanceof FormData)) {
      headers['Content-Type'] = headers['Content-Type'] || 'application/json';
    }

    const response = await fetch(url, { ...options, headers });

    if (response.status === 401 || response.status === 403) {
      const errorData = await response.json().catch(() => ({}));
      console.error('Auth error details:', errorData);
      
      if (response.status === 403) {
        const debugInfo = errorData.debug ? ` (Role: ${errorData.debug.receivedRole}, ID: ${errorData.debug.userId})` : '';
        return Promise.reject(new Error(`Forbidden access (403): ${errorData.error || 'Admin required'}${debugInfo}`));
      }
      
      localStorage.removeItem('token');
      window.location.href = '/';
      // Return a rejected promise to stop execution of the caller
      return Promise.reject(new Error('Unauthorized'));
    }
    return response;
  };

  const fetchAnalytics = async () => {
    setIsLoadingAnalytics(true);
    try {
      const res = await fetchWithAuth('/api/analytics/detailed');
      if (res.ok) {
        const data = await res.json();
        setAnalyticsData(data);
      }
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setIsLoadingAnalytics(false);
    }
  };

  const handleUpdateWarranty = async (itemId: string, date: string) => {
    try {
      const res = await fetchWithAuth(`/api/orders/items/${itemId}/warranty`, {
        method: 'PUT',
        body: JSON.stringify({ warrantyUntil: date })
      });
      
      if (res.ok) {
        const updatedItem = await res.json();
        if (selectedOrderForModal) {
          const updatedItems = selectedOrderForModal.items.map((item: any) => 
            item.id === itemId ? { ...item, warrantyUntil: updatedItem.warrantyUntil } : item
          );
          setSelectedOrderForModal({ ...selectedOrderForModal, items: updatedItems });
        }
        setEditingWarranty(null);
      } else {
        alert('Failed to update warranty');
      }
    } catch (error) {
      console.error('Failed to update warranty:', error);
      alert('Failed to update warranty');
    }
  };

  const handleDeliveryFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedDeliveryFile(e.target.files[0]);
    }
  };

  const handlePrepaymentFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedPrepaymentFile(e.target.files[0]);
    }
  };

  const handleInvoiceFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedInvoiceFile(e.target.files[0]);
    }
  };

  const handleUploadDeliveryDocument = async () => {
    if (!selectedOrderForModal || !selectedDeliveryFile) return;
    
    setIsUploadingDelivery(true);
    const formData = new FormData();
    formData.append('file', selectedDeliveryFile);
    
    try {
      const res = await fetchWithAuth(`/api/orders/${selectedOrderForModal.id}/delivery-document`, {
        method: 'POST',
        body: formData
      });
      
      if (res.ok) {
        const updatedOrder = await res.json();
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
        setSelectedOrderForModal(prev => ({ ...prev, ...updatedOrder }));
        setSelectedDeliveryFile(null);
        alert('Dokuments veiksmīgi pievienots!');
      } else {
        alert('Kļūda augšupielādējot dokumentu');
      }
    } catch (error) {
      console.error('Failed to upload delivery document:', error);
      alert('Kļūda augšupielādējot dokumentu');
    } finally {
      setIsUploadingDelivery(false);
    }
  };

  const handleUploadPrepaymentDocument = async () => {
    if (!selectedOrderForModal || !selectedPrepaymentFile) return;
    
    setIsUploadingPrepayment(true);
    const formData = new FormData();
    formData.append('file', selectedPrepaymentFile);
    
    try {
      const res = await fetchWithAuth(`/api/orders/${selectedOrderForModal.id}/prepayment-invoice`, {
        method: 'POST',
        body: formData
      });
      
      if (res.ok) {
        const updatedOrder = await res.json();
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
        setSelectedOrderForModal(prev => ({ ...prev, ...updatedOrder }));
        setSelectedPrepaymentFile(null);
        alert('Priekšapmaksas rēķins veiksmīgi pievienots un nosūtīts klientam!');
      } else {
        alert('Kļūda augšupielādējot priekšapmaksas rēķinu');
      }
    } catch (error) {
      console.error('Failed to upload prepayment invoice:', error);
      alert('Kļūda augšupielādējot priekšapmaksas rēķinu');
    } finally {
      setIsUploadingPrepayment(false);
    }
  };

  const handleUploadInvoiceDocument = async () => {
    if (!selectedOrderForModal || !selectedInvoiceFile) return;
    
    setIsUploadingInvoice(true);
    const formData = new FormData();
    formData.append('file', selectedInvoiceFile);
    
    try {
      const res = await fetchWithAuth(`/api/orders/${selectedOrderForModal.id}/invoice`, {
        method: 'POST',
        body: formData
      });
      
      if (res.ok) {
        const updatedOrder = await res.json();
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
        setSelectedOrderForModal(prev => ({ ...prev, ...updatedOrder }));
        setSelectedInvoiceFile(null);
        alert('Pavadzīme veiksmīgi pievienota un nosūtīta klientam!');
      } else {
        alert('Kļūda augšupielādējot pavadzīmi');
      }
    } catch (error) {
      console.error('Failed to upload invoice:', error);
      alert('Kļūda augšupielādējot pavadzīmi');
    } finally {
      setIsUploadingInvoice(false);
    }
  };
  
  const t = TRANSLATIONS[language];

  useEffect(() => {
    const loadData = async () => {
      if (isOpen) {
        const result = await storeService.getProducts();
        if (Array.isArray(result)) {
          setProducts(result);
        } else {
          setProducts(result.products);
        }
        setCategories(storeService.getCategories());
        // Orders are fetched separately
      }
    };
    loadData();
  }, [isOpen]);

  const fetchOrders = async () => {
    try {
      const res = await fetchWithAuth('/api/orders');
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await fetchWithAuth('/api/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (activeTab === 'orders') fetchOrders();
      if (activeTab === 'customers') fetchUsers();
      if (activeTab === 'analytics') fetchAnalytics();
    }
  }, [isOpen, activeTab]);

  const handleGenerateInvoice = async (order: Order) => {
    try {
      const res = await fetchWithAuth(`/api/invoices/generate-from-order/${order.id}`, {
        method: 'POST'
      });
      if (res.ok) {
        const invoice = await res.json();
        setSelectedOrderForModal(null);
        onClose();
        navigate(`/admin/invoices/${invoice.uuid}`);
      } else {
        const err = await res.json();
        alert(`Kļūda ģenerējot rēķinu: ${err.error || 'Nezināma kļūda'}`);
      }
    } catch (error) {
      console.error('Failed to generate invoice:', error);
      alert('Neizdevās sazināties ar serveri.');
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      const res = await fetchWithAuth(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status: newStatus })
      });
      
      if (res.ok) {
        const updatedOrder = await res.json();
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
        if (selectedOrderForModal && selectedOrderForModal.id === orderId) {
          setSelectedOrderForModal(prev => ({ ...prev, ...updatedOrder }));
        }
      }
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };



  const handleViewOrder = (order: any) => {
    setSelectedOrderForModal(order);
    setAdminInternalNote(order.internalNote || '');
    setAdminTrackingNumber(order.trackingNumber || '');
    setIsOrderModalOpen(true);
  };

  const handleSaveTracking = async () => {
    if (!selectedOrderForModal) return;
    setIsSavingAdminFields(true);
    try {
      const res = await fetchWithAuth(`/api/orders/${selectedOrderForModal.id}/tracking`, {
        method: 'PUT',
        body: JSON.stringify({
          trackingNumber: adminTrackingNumber
        })
      });
      if (res.ok) {
        const updatedOrder = await res.json();
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
        setSelectedOrderForModal(prev => ({ ...prev, ...updatedOrder }));
        alert('Tracking numbers are missing!');
      }
    } catch (error) {
      console.error('Failed to save tracking number:', error);
      alert('Kļūda saglabājot datus');
    } finally {
      setIsSavingAdminFields(false);
    }
  };

  const handleSaveInternalNote = async () => {
    if (!selectedOrderForModal) return;
    setIsSavingAdminFields(true);
    try {
      const res = await fetchWithAuth(`/api/orders/${selectedOrderForModal.id}/admin-update`, {
        method: 'PUT',
        body: JSON.stringify({
          internalNote: adminInternalNote,
          trackingNumber: adminTrackingNumber
        })
      });
      if (res.ok) {
        const updatedOrder = await res.json();
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? { ...o, ...updatedOrder } : o));
        setSelectedOrderForModal(prev => ({ ...prev, ...updatedOrder }));
        alert('Informācija saglabāta!');
      }
    } catch (error) {
      console.error('Failed to save admin fields:', error);
      alert('Kļūda saglabājot datus');
    } finally {
      setIsSavingAdminFields(false);
    }
  };

  const handleSendPreInvoice = async (orderId: string) => {
    try {
      const res = await fetchWithAuth(`/api/orders/${orderId}/send-pre-invoice`, {
        method: 'POST'
      });
      if (res.ok) {
        alert('Priekšapmaksas rēķins nosūtīts!');
        // Update status to NEW
        await fetchWithAuth(`/api/orders/${orderId}/status`, {
          method: 'PUT',
          body: JSON.stringify({ status: 'NEW' })
        });
        fetchOrders();
      }
    } catch (error) {
      console.error('Failed to send pre-invoice:', error);
      alert('Kļūda sūtot rēķinu');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!confirm('Are you sure you want to delete this order? This action cannot be undone.')) return;
    
    try {
      const res = await fetchWithAuth(`/api/orders/${orderId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchOrders();
        alert('Order deleted successfully');
      } else {
        alert('Failed to delete order');
      }
    } catch (error) {
      console.error('Failed to delete order:', error);
      alert('Error deleting order');
    }
  };

  const handleDeleteOldOrders = async () => {
    if (!confirm('Are you sure you want to delete all unpaid orders older than 7 days? This action cannot be undone.')) return;
    
    try {
      const res = await fetchWithAuth('/api/orders/cleanup', {
        method: 'DELETE'
      });
      if (res.ok) {
        const data = await res.json();
        fetchOrders();
        alert(`Successfully deleted ${data.count} old orders.`);
      } else {
        alert('Failed to delete old orders');
      }
    } catch (error) {
      console.error('Failed to delete old orders:', error);
      alert('Error deleting old orders');
    }
  };

  const handlePrintShippingLabel = async (orderId: string) => {
    try {
      const res = await fetchWithAuth(`/api/orders/${orderId}/shipping-label`, {
        method: 'POST'
      });
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
      }
    } catch (error) {
      console.error('Failed to print label:', error);
      alert('Kļūda drukājot uzlīmi');
    }
  };

  const handleUpdateUser = async (userId: string, data: { tier?: string, discountLevel?: number }) => {
    try {
      const res = await fetchWithAuth(`/api/users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify(data)
      });
      if (res.ok) {
        // If we just saved, we might want to show a success indicator or re-fetch
        // But since we are updating local state optimistically for the input, 
        // we should just ensure the fetchUsers is called to sync everything or show a toast.
        // For now, let's just alert or log success.
        console.log('User updated successfully');
        // fetchUsers(); // Optional: re-fetch to be sure
      }
    } catch (error) {
      console.error('Failed to update user:', error);
      alert('Failed to save changes');
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    
    try {
      const url = isAdding ? '/api/products' : `/api/products/${editingProduct.id}`;
      const method = isAdding ? 'POST' : 'PUT';
      
      const res = await fetchWithAuth(url, {
        method,
        body: JSON.stringify(editingProduct)
      });
      
      if (res.ok) {
        const savedProduct = await res.json();
        let updated = isAdding 
          ? [...products, savedProduct] 
          : products.map(p => p.id === savedProduct.id ? savedProduct : p);
        
        setProducts(updated);
        setEditingProduct(null);
        setIsAdding(false);
      } else {
        alert('Failed to save product');
      }
    } catch (error) {
      console.error('Failed to save product:', error);
      alert('Failed to save product');
    }
  };

  const handleDownloadInvoice = async (order: any) => {
    if (generatingPdfId) return;
    setGeneratingPdfId(order.id);
    try {
      await generateROKOFInvoice(
        { ...order, number: order.invoiceNumber || order.id },
        { ...order.user },
        language,
        'download'
      );
    } catch (error) {
      console.error('Failed to generate PDF:', error);
    } finally {
      setGeneratingPdfId(null);
    }
  };

  const handlePreviewInvoice = async (order: any) => {
    if (generatingPdfId) return;
    setGeneratingPdfId(order.id);
    try {
      const blob = await generateROKOFInvoice(
        { ...order, number: order.invoiceNumber || order.id },
        { ...order.user },
        language,
        'blob'
      );
      if (blob) {
        setPreviewPdfUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error('Failed to preview PDF:', error);
    } finally {
      setGeneratingPdfId(null);
    }
  };

  const handlePrintInvoice = async (order: any) => {
    if (printingId) return;
    setPrintingId(order.id);
    try {
      const blob = await generateROKOFInvoice(
        { ...order, number: order.invoiceNumber || order.id },
        { ...order.user },
        language,
        'blob'
      );
      if (blob) {
        const url = URL.createObjectURL(blob);
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = url;
        document.body.appendChild(iframe);
        
        iframe.onload = () => {
          setTimeout(() => {
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
            setTimeout(() => {
              document.body.removeChild(iframe);
              URL.revokeObjectURL(url);
            }, 1000);
          }, 500);
        };
      }
    } catch (error) {
      console.error('Failed to print PDF:', error);
    } finally {
      setPrintingId(null);
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      const updated = products.filter(p => p.id !== id);
      setProducts(updated);
    }
  };

  const updateSpec = (key: string, value: any) => {
    if (!editingProduct) return;
    setEditingProduct({
      ...editingProduct,
      specifications: {
        ...editingProduct.specifications,
        [key]: value
      }
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setImportResult(null);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetchWithAuth("/api/import-xlsm", {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: response.statusText }));
        alert(`Kļūda: ${errorData.error || 'Neizdevās augšupielādēt failu'}`);
        return;
      }

      const result = await response.json();
      
      if (result.success) {
        setImportResult(result);
        alert(`Importēšana pabeigta!\nJauni produkti: ${result.createdCount}\nAtjaunotas cenas: ${result.updatedCount}\nKļūdas: ${result.errorCount}`);
      } else {
        alert(`Kļūda: ${result.error}`);
      }
    } catch (error: any) {
      if (error.message === 'Forbidden' || error.message === 'Unauthorized') {
        return; // Already handled by fetchWithAuth
      }
      console.error("Upload error:", error);
      alert("Notika kļūda augšupielādējot failu.");
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const getCustomerAddress = (order: any) => {
    const ci = order?.customerInfo;
    if (ci) {
      const parts = [ci.street, ci.building, ci.apartment, ci.city, ci.zipCode].filter(Boolean);
      if (parts.length > 0) return parts.join(', ');
      if (ci.address) return ci.address;
    }
    
    // Fallback to user profile address if order snapshot is missing or incomplete
    const u = order?.user;
    if (u) {
      const userParts = [u.street, u.building, u.apartment, u.city, u.zipCode].filter(Boolean);
      if (userParts.length > 0) return userParts.join(', ');
      if (u.physicalAddress) return u.physicalAddress;
    }
    
    return order?.deliveryAddress || order?.shippingAddress || 'N/A';
  };

  const totalWeight = selectedOrderForModal?.items?.reduce((acc: number, item: any) => acc + (Number(item.weightPerMeter || 0) * Number(item.quantity || 0)), 0) || 0;

  return (
    <div className={`fixed inset-0 z-[200] flex flex-col bg-white overflow-hidden transition-all duration-300 ${isOpen ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0 pointer-events-none'}`}>
      <div className="p-6 md:p-8 bg-black text-white flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <Database className="text-[#8DB835]" />
          <div>
            <h2 className="text-xl font-black uppercase tracking-tight">ROKOF SYSTEM ADMIN</h2>
            <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">Management v2.0</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex bg-zinc-900 p-1 rounded-sm">
            {['products', 'inventory', 'categories', 'orders', 'customers', 'analytics', 'invoices'].map((tab) => (
              <button 
                key={tab}
                onClick={() => {
                  setActiveTab(tab as any);
                }}
                className={`px-6 py-2 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-[#8DB835] text-white' : 'text-zinc-500 hover:text-white'}`}
              >
                {tab === 'analytics' ? 'Analītika' : tab === 'invoices' ? 'Rēķini' : tab}
              </button>
            ))}
          </div>
          <button onClick={onClose} className="p-2 hover:bg-zinc-800 transition-colors"><X size={24} /></button>
        </div>
      </div>

      <div className="flex-grow flex overflow-hidden bg-zinc-50">
        <div className="flex-grow overflow-y-auto p-8 md:p-12 no-scrollbar">
          <div className="max-w-7xl mx-auto space-y-8">
            {activeTab === 'products' && (
              <div className="flex justify-between items-center">
                <div className="relative flex-grow max-w-md">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-300 w-4 h-4" />
                  <input 
                    type="text" 
                    placeholder="Search Database..." 
                    value={searchQuery} 
                    onChange={(e) => setSearchQuery(e.target.value)} 
                    className="w-full pl-12 pr-6 py-4 text-xs font-bold border border-zinc-200 focus:outline-none" 
                  />
                </div>
                <button 
                  onClick={() => { 
                    setEditingProduct({ 
                      id: '', 
                      sku: '', 
                      brand: 'ROKOF',
                      title: { LV: '', RU: '', EN: '' }, 
                      category: 'LED_STRIP', 
                      price: 0, 
                      b2bPrice: 0, 
                      unit: 'm',
                      stockQuantity: 0,
                      warrantyMonths: 36,
                      images: [''], 
                      description: { LV: '', RU: '', EN: '' }, 
                      specifications: { warranty: '3', weightPerMeter: 0 },
                      createdAt: new Date()
                    }); 
                    setIsAdding(true); 
                  }} 
                  className="px-8 py-4 bg-black text-white text-[10px] font-black uppercase flex items-center gap-3"
                >
                  <Plus size={16} /> Add Product
                </button>
              </div>
            )}

            {activeTab === 'products' && (
              <div className="bg-white border border-zinc-200">
                <table className="w-full text-left">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-[9px] font-black uppercase tracking-widest text-zinc-400">
                    <tr>
                      <th className="px-6 py-4">Image</th>
                      <th className="px-6 py-4">SKU / Name</th>
                      <th className="px-6 py-4">Category</th>
                      <th className="px-6 py-4">Price (B2C/B2B)</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.filter(p => {
                      const title = p.title?.[language] || '';
                      return p.sku.toLowerCase().includes(searchQuery.toLowerCase()) || title.toLowerCase().includes(searchQuery.toLowerCase());
                    }).map((p, idx) => (
                      <tr key={p.id || p.sku || `product-${idx}`} className="border-b border-zinc-100 group">
                        <td className="px-6 py-4">
                          <img src={p.images?.[0] || 'https://picsum.photos/seed/rokof/800/600'} className="w-10 h-8 object-cover grayscale" />
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-[10px] font-black text-[#8DB835]">{p.sku}</div>
                          <div className="text-[11px] font-bold text-black uppercase">{p.title?.[language] || 'Unnamed'}</div>
                          <div className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">{p.brand || 'ROKOF'}</div>
                        </td>
                        <td className="px-6 py-4">
                           <span className="text-[10px] font-black uppercase">{p.category}</span>
                        </td>
                        <td className="px-6 py-4 text-[11px] font-black text-black">
                          €{p.price.toFixed(2)} / <span className="text-[#8DB835]">€{p.b2bPrice.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => { setEditingProduct(p); setIsAdding(false); }} className="p-2 text-zinc-300 hover:text-black"><Pencil size={14} /></button>
                            <button onClick={() => handleDeleteProduct(p.id)} className="p-2 text-zinc-300 hover:text-rose-500"><Trash2 size={14} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'inventory' && (
              <div className="bg-white border border-zinc-200 p-8">
                <h3 className="text-lg font-black uppercase tracking-tight mb-6">Inventarizācija un Cenas</h3>
                
                <div className="space-y-6 max-w-xl">
                  <div className="p-6 bg-zinc-50 border border-zinc-200">
                    <h4 className="text-[10px] font-black uppercase tracking-widest mb-4">Datu Importēšana</h4>
                    <p className="text-xs text-zinc-500 mb-6">Augšupielādējiet XLSM vai XLSX failu, lai atjauninātu produktu cenas un atlikumus.</p>
                    
                    <label className={`relative flex items-center justify-center px-8 py-4 text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer ${isUploading ? 'bg-zinc-200 text-zinc-500' : 'bg-black text-white hover:bg-[#8DB835]'}`}>
                      {isUploading ? (
                        <><Loader2 size={16} className="animate-spin mr-3" /> Notiek apstrāde...</>
                      ) : (
                        <><Download size={16} className="mr-3" /> Augšupielādēt XLSM</>
                      )}
                      <input 
                        type="file" 
                        accept=".xlsx, .xls, .xlsm" 
                        className="hidden" 
                        onChange={handleFileUpload}
                        disabled={isUploading}
                      />
                    </label>
                  </div>

                  {importResult && importResult.errorCount > 0 && (
                    <div className="p-6 bg-rose-50 border border-rose-200">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-rose-600 mb-4">Kļūdu Saraksts ({importResult.errorCount})</h4>
                      <div className="max-h-48 overflow-y-auto text-xs text-rose-800 space-y-2 bg-white p-4 border border-rose-100">
                        {importResult.errors.map((err, idx) => (
                          <div key={`err-${idx}`} className="border-b border-rose-50 pb-2 last:border-0 last:pb-0">
                            <span className="font-bold">Rinda {err.row}:</span> {err.error}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'orders' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div className="relative flex-grow max-w-md">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-300 w-4 h-4" />
                    <input 
                      type="text" 
                      placeholder="Search Orders (ID, RKF, Name)..." 
                      value={orderSearchQuery} 
                      onChange={(e) => setOrderSearchQuery(e.target.value)} 
                      className="w-full pl-12 pr-6 py-4 text-xs font-bold border border-zinc-200 focus:outline-none" 
                    />
                  </div>
                  <button 
                    onClick={handleDeleteOldOrders}
                    className="px-6 py-4 bg-rose-50 text-rose-600 hover:bg-rose-100 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-colors border border-rose-200"
                  >
                    <Trash2 size={16} /> Cleanup &gt; 7 Days
                  </button>
                </div>

                <div className="bg-white border border-zinc-200">
                  <table className="w-full text-left">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-[9px] font-black uppercase tracking-widest text-zinc-400">
                    <tr>
                      <th className="px-6 py-4">Order ID</th>
                      <th className="px-6 py-4">Pre-Invoice Status</th>
                      <th className="px-6 py-4">Pavadzīme Status</th>
                      <th className="px-6 py-4">Customer</th>
                      <th className="px-6 py-4">Date</th>
                      <th className="px-6 py-4">Total</th>
                      <th className="px-6 py-4">Delivery</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.filter(o => {
                      const search = orderSearchQuery.toLowerCase();
                      const id = (o.invoiceNumber || o.id).toLowerCase();
                      const rkf = (o.rkfInvoiceNumber || '').toLowerCase();
                      const name = `${o.user?.firstName || ''} ${o.user?.lastName || ''}`.toLowerCase();
                      const email = (o.user?.email || '').toLowerCase();
                      return id.includes(search) || rkf.includes(search) || name.includes(search) || email.includes(search);
                    }).map((o, idx) => (
                      <tr key={o.id || `order-${idx}`} className="border-b border-zinc-100 group">
                        <td className="px-6 py-4 text-[11px] font-black">
                          {o.invoiceNumber || o.id.substring(0, 8)}
                        </td>
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-2">
                             {o.preInvoiceSentAt || ['PAID', 'PROCESSING', 'IN_DELIVERY', 'SHIPPED', 'COMPLETED'].includes(o.status) ? (
                               <button 
                                  className="px-3 py-1 bg-emerald-500 text-white text-[9px] font-black uppercase tracking-widest rounded-sm flex items-center gap-2 cursor-default"
                                  title={`Sent at ${o.preInvoiceSentAt ? new Date(o.preInvoiceSentAt).toLocaleString() : 'Unknown'}`}
                               >
                                 <CheckCircle2 size={10} /> SENT
                               </button>
                             ) : (
                               <button 
                                  onClick={() => handleSendPreInvoice(o.id)}
                                  className="px-3 py-1 bg-zinc-100 text-zinc-500 hover:bg-black hover:text-white text-[9px] font-black uppercase tracking-widest rounded-sm flex items-center gap-2 transition-all"
                               >
                                 <QrCode size={10} /> SEND PRE-INV
                               </button>
                             )}
                           </div>
                        </td>
                        <td className="px-6 py-4">
                           {o.rkfInvoiceNumber ? (
                             <div className="flex items-center gap-2">
                               <span className="text-[10px] font-black text-[#8DB835]">{o.rkfInvoiceNumber}</span>
                               <button 
                                  onClick={() => handleDownloadInvoice(o)}
                                  className="p-1 text-zinc-400 hover:text-[#8DB835]"
                                  title="Download RKF"
                               >
                                 <Download size={12} />
                               </button>
                             </div>
                           ) : (
                             <span className="text-[10px] text-zinc-300 uppercase">Not Generated</span>
                           )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-[11px] font-bold uppercase">{o.user?.firstName} {o.user?.lastName}</div>
                          <div className="text-[9px] text-zinc-400">{o.user?.email}</div>
                          <div className="text-[8px] font-black text-[#8DB835] uppercase tracking-widest mt-1">
                            {o.user?.type === 'UNREGISTERED' ? 'Unregistered user' : o.user?.type}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-[10px] font-bold">{new Date(o.createdAt).toLocaleDateString()}</td>
                        <td className="px-6 py-4 text-[11px] font-black">€{(o.totalAmount || 0).toFixed(2)}</td>
                        <td className="px-6 py-4">
                          <div className="text-[10px] font-bold text-zinc-600">{o.deliveryMethod}</div>
                          <div className="text-[9px] text-zinc-400 max-w-[150px] truncate" title={o.shippingAddress || o.deliveryAddress}>
                            {o.stationId ? `Pakomāts: ${o.stationId}` : (o.shippingAddress || o.deliveryAddress)}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 text-[8px] font-black uppercase rounded-full ${
                            o.status === 'PAID' ? 'bg-emerald-100 text-emerald-600' :
                            o.status === 'PROCESSING' ? 'bg-amber-100 text-amber-600' :
                            o.status === 'IN_DELIVERY' ? 'bg-blue-100 text-blue-600' :
                            o.status === 'SHIPPED' ? 'bg-indigo-100 text-indigo-600' :
                            o.status === 'COMPLETED' ? 'bg-emerald-500 text-white' :
                            o.status === 'CANCELLED' ? 'bg-rose-100 text-rose-600' :
                            'bg-zinc-100 text-zinc-600'
                          }`}>
                            {o.status === 'NEW' ? 'JAUNS' : 
                             o.status === 'PAID' ? 'APMAKSĀTS' : 
                             o.status === 'PROCESSING' ? 'APSTRĀDĀŠANA' : 
                             o.status === 'IN_DELIVERY' ? 'UZ PIEGĀDI' : 
                             o.status === 'SHIPPED' ? 'IZSŪTĪTS' : 
                             o.status === 'COMPLETED' ? 'PABEIGTS' : 
                             o.status === 'CANCELLED' ? 'ATCELTS' : o.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button 
                                onClick={() => handleViewOrder(o)}
                                className="p-2 text-zinc-300 hover:text-black"
                                title="View Details"
                            >
                                <Eye size={14} />
                            </button>
                            <button 
                                onClick={() => handleDeleteOrder(o.id)}
                                className="p-2 text-zinc-300 hover:text-rose-500"
                                title="Delete Order"
                            >
                                <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-8">
                {isLoadingAnalytics ? (
                  <div className="flex flex-col items-center justify-center py-32">
                    <Loader2 size={48} className="animate-spin text-[#8DB835] mb-4" />
                    <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Loading Analytics Data...</p>
                  </div>
                ) : analyticsData ? (
                  <>
                    {/* Sales Summary */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white border border-zinc-200 p-8 shadow-sm">
                        <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-6 flex items-center gap-2">
                          <Clock size={14} /> Šis mēnesis vs Iepriekšējais
                        </h3>
                        <div className="grid grid-cols-2 gap-8">
                          <div>
                            <p className="text-[9px] font-black uppercase text-zinc-400 mb-1">Revenue</p>
                            <p className="text-2xl font-black">€{analyticsData.summary.currentMonth.revenue.toFixed(2)}</p>
                            <p className={`text-[10px] font-bold mt-1 ${analyticsData.summary.currentMonth.revenue >= analyticsData.summary.prevMonth.revenue ? 'text-emerald-500' : 'text-rose-500'}`}>
                              {analyticsData.summary.currentMonth.revenue >= analyticsData.summary.prevMonth.revenue ? '↑' : '↓'} 
                              {analyticsData.summary.prevMonth.revenue > 0 
                                ? (((analyticsData.summary.currentMonth.revenue - analyticsData.summary.prevMonth.revenue) / analyticsData.summary.prevMonth.revenue) * 100).toFixed(1)
                                : '100'}% vs prev
                            </p>
                          </div>
                          <div>
                            <p className="text-[9px] font-black uppercase text-zinc-400 mb-1">Orders</p>
                            <p className="text-2xl font-black">{analyticsData.summary.currentMonth.orders}</p>
                            <p className="text-[10px] font-bold text-zinc-400 mt-1">Prev: {analyticsData.summary.prevMonth.orders}</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-black text-white p-8 shadow-xl flex flex-col justify-center">
                         <div className="flex items-center justify-between mb-4">
                            <h3 className="text-[10px] font-black uppercase tracking-widest text-[#8DB835]">Total Revenue (All Time)</h3>
                            <Zap size={20} className="text-[#8DB835]" />
                         </div>
                         <p className="text-4xl font-black tracking-tighter">€{orders.filter(o => o.status === 'COMPLETED').reduce((sum, o) => sum + o.totalAmount, 0).toFixed(2)}</p>
                         <p className="text-[9px] font-black uppercase tracking-widest text-zinc-500 mt-2">Based on completed orders</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      {/* Top 10 SKUs */}
                      <div className="lg:col-span-2 bg-white border border-zinc-200 shadow-sm overflow-hidden">
                        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                          <h3 className="text-xs font-black uppercase tracking-widest">Top 10 Pārdotākie SKUs</h3>
                          <Package size={16} className="text-zinc-300" />
                        </div>
                        <table className="w-full text-left">
                          <thead className="bg-zinc-50 text-[9px] font-black uppercase tracking-widest text-zinc-400">
                            <tr>
                              <th className="px-6 py-4">SKU / Nosaukums</th>
                              <th className="px-6 py-4 text-center">Daudzums</th>
                              <th className="px-6 py-4 text-right">Apgrozījums</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-zinc-50">
                            {analyticsData.topSKUs.map((item: any, idx: number) => (
                              <tr key={item.sku || `sku-${idx}`} className="hover:bg-zinc-50 transition-colors">
                                <td className="px-6 py-4">
                                  <div className="text-[10px] font-black text-[#8DB835]">{item.sku}</div>
                                  <div className="text-[11px] font-bold text-black uppercase truncate max-w-[300px]">{item.title}</div>
                                </td>
                                <td className="px-6 py-4 text-center text-[11px] font-black text-zinc-500">
                                  {item.quantity}
                                </td>
                                <td className="px-6 py-4 text-right text-[11px] font-black text-black">
                                  €{item.revenue.toFixed(2)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Brand Performance */}
                      <div className="bg-white border border-zinc-200 shadow-sm overflow-hidden">
                        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                          <h3 className="text-xs font-black uppercase tracking-widest">Zīmolu Sniegums</h3>
                          <Tag size={16} className="text-zinc-300" />
                        </div>
                        <div className="p-6 space-y-6">
                          {analyticsData.brandPerformance.map((brand: any, idx: number) => {
                            const maxRevenue = Math.max(...analyticsData.brandPerformance.map((b: any) => b.revenue));
                            const percentage = (brand.revenue / maxRevenue) * 100;
                            return (
                              <div key={brand.brand || `brand-${idx}`} className="space-y-2">
                                <div className="flex justify-between items-end">
                                  <span className="text-[10px] font-black uppercase tracking-widest">{brand.brand}</span>
                                  <span className="text-[11px] font-black">€{brand.revenue.toFixed(2)}</span>
                                </div>
                                <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-[#8DB835] transition-all duration-1000" 
                                    style={{ width: `${percentage}%` }}
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-20">
                    <p className="text-zinc-400">Nav pieejami dati analītikai.</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'invoices' && (
              <div className="bg-white border border-zinc-200">
                <InvoiceList />
              </div>
            )}

            {activeTab === 'customers' && (
              <div className="bg-white border border-zinc-200">
                <table className="w-full text-left">
                  <thead className="bg-zinc-50 border-b border-zinc-200 text-[9px] font-black uppercase tracking-widest text-zinc-400">
                    <tr>
                      <th className="px-6 py-4">Name</th>
                      <th className="px-6 py-4">Email</th>
                      <th className="px-6 py-4">Role</th>
                      <th className="px-6 py-4">Type</th>
                      <th className="px-6 py-4">Tier</th>
                      <th className="px-6 py-4">Discount (%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-xs text-zinc-500 font-medium uppercase tracking-widest">
                          No customers found
                        </td>
                      </tr>
                    ) : (
                      users.map((u, idx) => (
                        <tr key={u.id || `user-${idx}`} className="border-b border-zinc-100 group">
                          <td className="px-6 py-4 text-[11px] font-bold uppercase">
                            {u.firstName} {u.lastName}
                          </td>
                          <td className="px-6 py-4 text-[10px] text-zinc-500">
                            {u.email}
                          </td>
                          <td className="px-6 py-4 text-[10px] font-black uppercase">
                            {u.role}
                          </td>
                          <td className="px-6 py-4 text-[10px] font-black uppercase">
                            {u.type === 'UNREGISTERED' ? 'Unregistered user' : (u.type || 'N/A')}
                          </td>
                          <td className="px-6 py-4">
                            <select 
                              value={u.tier || 'BRONZE'} 
                              onChange={(e) => handleUpdateUser(u.id, { tier: e.target.value })}
                              className="text-[10px] font-black uppercase bg-zinc-100 border-none rounded px-2 py-1 focus:ring-0 cursor-pointer"
                            >
                              <option value="BRONZE">Bronze</option>
                              <option value="SILVER">Silver</option>
                              <option value="GOLD">Gold</option>
                            </select>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                value={u.discountLevel || 0}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value) || 0;
                                  const updatedUsers = users.map(user => 
                                    user.id === u.id ? { ...user, discountLevel: val } : user
                                  );
                                  setUsers(updatedUsers);
                                }}
                                className="w-16 text-[10px] font-black uppercase bg-zinc-100 border-none rounded px-2 py-1 focus:ring-0"
                                min="0"
                                max="100"
                              />
                              <button 
                                onClick={() => handleUpdateUser(u.id, { discountLevel: u.discountLevel })}
                                className="p-1 text-zinc-400 hover:text-[#8DB835] transition-colors"
                                title="Save Discount"
                              >
                                <Save size={14} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {editingProduct && (
          <div className="fixed inset-y-0 right-0 w-[450px] bg-white shadow-2xl border-l border-zinc-200 p-10 z-[210] animate-in slide-in-from-right duration-300 flex flex-col">
            <div className="flex items-center justify-between mb-10">
              <h3 className="text-lg font-black uppercase tracking-tight">{isAdding ? 'Add' : 'Edit'} Product</h3>
              <button onClick={() => setEditingProduct(null)}><X size={24} /></button>
            </div>
            <form onSubmit={handleSaveProduct} className="space-y-6 flex-grow overflow-y-auto no-scrollbar pb-10">
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">SKU</label>
                <input type="text" value={editingProduct.sku} onChange={e => setEditingProduct({...editingProduct, sku: e.target.value})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black" required />
              </div>
              <div className="space-y-4 p-4 bg-zinc-50 border border-zinc-100">
                <h4 className="text-[10px] font-black uppercase tracking-widest border-b pb-2">Product Titles</h4>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Title (LV)</label>
                  <input type="text" value={editingProduct.title?.LV || ''} onChange={e => setEditingProduct({...editingProduct, title: {...(editingProduct.title || {LV:'', RU:'', EN:''}), LV: e.target.value}})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black" required />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Title (RU)</label>
                  <input type="text" value={editingProduct.title?.RU || ''} onChange={e => setEditingProduct({...editingProduct, title: {...(editingProduct.title || {LV:'', RU:'', EN:''}), RU: e.target.value}})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black" required />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Title (EN)</label>
                  <input type="text" value={editingProduct.title?.EN || ''} onChange={e => setEditingProduct({...editingProduct, title: {...(editingProduct.title || {LV:'', RU:'', EN:''}), EN: e.target.value}})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black" required />
                </div>
              </div>

              <div className="space-y-4 p-4 bg-zinc-50 border border-zinc-100">
                <h4 className="text-[10px] font-black uppercase tracking-widest border-b pb-2">Product Descriptions</h4>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Description (LV)</label>
                  <textarea value={editingProduct.description?.LV || ''} onChange={e => setEditingProduct({...editingProduct, description: {...(editingProduct.description || {LV:'', RU:'', EN:''}), LV: e.target.value}})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black h-24" />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Description (RU)</label>
                  <textarea value={editingProduct.description?.RU || ''} onChange={e => setEditingProduct({...editingProduct, description: {...(editingProduct.description || {LV:'', RU:'', EN:''}), RU: e.target.value}})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black h-24" />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Description (EN)</label>
                  <textarea value={editingProduct.description?.EN || ''} onChange={e => setEditingProduct({...editingProduct, description: {...(editingProduct.description || {LV:'', RU:'', EN:''}), EN: e.target.value}})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none focus:border-black h-24" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">B2C Price</label>
                  <input type="number" step="0.01" value={editingProduct.price} onChange={e => setEditingProduct({...editingProduct, price: Number(e.target.value)})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none" required />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">B2B Price</label>
                  <input type="number" step="0.01" value={editingProduct.b2bPrice} onChange={e => setEditingProduct({...editingProduct, b2bPrice: Number(e.target.value)})} className="w-full p-4 text-xs font-bold border border-zinc-200 focus:outline-none" required />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Unit</label>
                  <select value={editingProduct.unit} onChange={e => setEditingProduct({...editingProduct, unit: e.target.value as 'm' | 'pcs'})} className="w-full p-4 text-xs font-bold border border-zinc-200">
                    <option value="m">Meters (m)</option>
                    <option value="pcs">Pieces (pcs)</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Stock Quantity</label>
                  <input type="number" value={editingProduct.stockQuantity} onChange={e => setEditingProduct({...editingProduct, stockQuantity: Number(e.target.value)})} className="w-full p-4 text-xs font-bold border border-zinc-200" required />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Garantijas termiņš (mēneši)</label>
                  <input type="number" value={editingProduct.warrantyMonths || 36} onChange={e => setEditingProduct({...editingProduct, warrantyMonths: Number(e.target.value)})} className="w-full p-4 text-xs font-bold border border-zinc-200" required />
                </div>
              </div>
              
              {/* Technical Specifications Addition */}
              <div className="p-6 bg-zinc-50 border border-zinc-100 space-y-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] border-b pb-2">Technical Specifications</h4>
                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2">
                      <label className="text-[8px] font-black uppercase tracking-widest text-zinc-400 flex items-center gap-2"><Shield size={10} /> Warranty (Years)</label>
                      <input type="text" value={editingProduct.specifications.warranty || '3'} onChange={e => updateSpec('warranty', e.target.value)} className="w-full p-3 text-xs font-bold border border-zinc-200" />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[8px] font-black uppercase tracking-widest text-zinc-400 flex items-center gap-2"><Weight size={10} /> Weight (kg/m)</label>
                      <input type="number" step="0.001" value={editingProduct.specifications.weightPerMeter || 0} onChange={e => updateSpec('weightPerMeter', Number(e.target.value))} className="w-full p-3 text-xs font-bold border border-zinc-200" />
                   </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Brand</label>
                <input type="text" value={editingProduct.brand || ''} onChange={e => setEditingProduct({...editingProduct, brand: e.target.value})} className="w-full p-4 text-xs font-bold border border-zinc-200" placeholder="e.g. ROKOF" />
              </div>

              {/* GPSR Compliance Fields */}
              <div className="p-6 bg-zinc-50 border border-zinc-100 space-y-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] border-b pb-2">GPSR Compliance</h4>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Energy Class</label>
                    <select 
                      value={editingProduct.energyClass || ''} 
                      onChange={e => setEditingProduct({...editingProduct, energyClass: e.target.value as any})}
                      className="w-full p-4 text-xs font-bold border border-zinc-200"
                    >
                      <option value="">None</option>
                      {['A', 'B', 'C', 'D', 'E', 'F', 'G'].map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Technical Documentation URL</label>
                    <input 
                      type="text" 
                      value={editingProduct.technicalDocumentationUrl || ''} 
                      onChange={e => setEditingProduct({...editingProduct, technicalDocumentationUrl: e.target.value})} 
                      className="w-full p-4 text-xs font-bold border border-zinc-200"
                      placeholder="https://..."
                    />
                  </div>
                  <div className="space-y-4 pt-4 border-t border-zinc-200">
                    <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">EU Responsible Person</label>
                    <div className="grid grid-cols-1 gap-4">
                      <input 
                        type="text" 
                        placeholder="Name"
                        value={editingProduct.euResponsiblePerson?.name || ''} 
                        onChange={e => setEditingProduct({
                          ...editingProduct, 
                          euResponsiblePerson: { ...(editingProduct.euResponsiblePerson || {name:'', address:'', email:''}), name: e.target.value }
                        })} 
                        className="w-full p-3 text-xs font-bold border border-zinc-200"
                      />
                      <input 
                        type="text" 
                        placeholder="Address"
                        value={editingProduct.euResponsiblePerson?.address || ''} 
                        onChange={e => setEditingProduct({
                          ...editingProduct, 
                          euResponsiblePerson: { ...(editingProduct.euResponsiblePerson || {name:'', address:'', email:''}), address: e.target.value }
                        })} 
                        className="w-full p-3 text-xs font-bold border border-zinc-200"
                      />
                      <input 
                        type="email" 
                        placeholder="Email"
                        value={editingProduct.euResponsiblePerson?.email || ''} 
                        onChange={e => setEditingProduct({
                          ...editingProduct, 
                          euResponsiblePerson: { ...(editingProduct.euResponsiblePerson || {name:'', address:'', email:''}), email: e.target.value }
                        })} 
                        className="w-full p-3 text-xs font-bold border border-zinc-200"
                      />
                      <input 
                        type="text" 
                        placeholder="Phone (Optional)"
                        value={editingProduct.euResponsiblePerson?.phone || ''} 
                        onChange={e => setEditingProduct({
                          ...editingProduct, 
                          euResponsiblePerson: { ...(editingProduct.euResponsiblePerson || {name:'', address:'', email:''}), phone: e.target.value }
                        })} 
                        className="w-full p-3 text-xs font-bold border border-zinc-200"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Category</label>
                <select 
                  value={editingProduct.category} 
                  onChange={e => setEditingProduct({...editingProduct, category: e.target.value as any})}
                  className="w-full p-4 text-xs font-bold border border-zinc-200"
                >
                  <option value="LED_STRIP">LED STRIP</option>
                  <option value="PROFILE">PROFILE</option>
                  <option value="POWER_SUPPLY">POWER SUPPLY</option>
                  <option value="CONTROLLER">CONTROLLER</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Image URL</label>
                <input type="text" value={editingProduct.images?.[0] || ''} onChange={e => setEditingProduct({...editingProduct, images: [e.target.value]})} className="w-full p-4 text-xs font-bold border border-zinc-200" required />
              </div>
              <button type="submit" className="w-full py-5 bg-black text-white text-[10px] font-black uppercase tracking-widest mt-6 hover:bg-[#8DB835] transition-all">
                <Save size={16} className="inline mr-2" /> Save Changes
              </button>
            </form>
          </div>
        )}
      </div>
      {previewPdfUrl && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 md:p-10">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setPreviewPdfUrl(null)} />
          <div className="relative w-full max-w-5xl h-full bg-white shadow-2xl border-2 border-black flex flex-col animate-in zoom-in-95 duration-300">
            <div className="p-6 bg-black text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-4">
                <FileText className="text-[#8DB835]" />
                <h3 className="text-sm font-black uppercase tracking-widest">{t.invoicePreview}</h3>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => window.print()} 
                  className="p-2 hover:bg-zinc-800 transition-colors"
                  title="Print"
                >
                  <Printer size={20} />
                </button>
                <button 
                  onClick={() => setPreviewPdfUrl(null)} 
                  className="p-2 hover:bg-zinc-800 transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="flex-grow bg-zinc-100 overflow-hidden relative">
              <iframe 
                src={previewPdfUrl} 
                className="w-full h-full border-none"
                title="Invoice Preview"
              />
            </div>
            <div className="p-6 bg-zinc-50 border-t border-zinc-200 flex justify-end shrink-0">
              <button 
                onClick={() => setPreviewPdfUrl(null)}
                className="px-8 py-3 bg-black text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Order Details Modal */}
      {isOrderModalOpen && selectedOrderForModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsOrderModalOpen(false)} />
          <div className="relative w-full max-w-4xl bg-white shadow-2xl border-2 border-black flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300">
            {/* Header */}
            <div className="p-6 border-b-2 border-black flex items-center justify-between bg-black text-white">
              <div>
                <h3 className="text-lg font-black uppercase tracking-tight">Pasūtījuma Detaļas</h3>
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
                  {selectedOrderForModal.invoiceNumber || selectedOrderForModal.id}
                </p>
              </div>
              <button onClick={() => setIsOrderModalOpen(false)} className="p-2 hover:bg-white/10 transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Customer Info */}
                <div className="space-y-4">
                  <h4 className="text-xs font-black uppercase tracking-widest pb-2 border-b border-zinc-100">Klienta Informācija</h4>
                  <div className="space-y-2 text-[11px]">
                    <p><span className="text-zinc-400 uppercase">Tips:</span> <span className="font-black text-[#8DB835] uppercase tracking-widest">{selectedOrderForModal.user?.type === 'UNREGISTERED' ? 'Unregistered user' : (selectedOrderForModal.user?.type || 'GUEST')}</span></p>
                    <p><span className="text-zinc-400 uppercase">Vārds:</span> <span className="font-bold">{selectedOrderForModal.user?.firstName || selectedOrderForModal.customerInfo?.name || 'N/A'} {selectedOrderForModal.user?.lastName || ''}</span></p>
                    {selectedOrderForModal.user?.companyName && (
                      <>
                        <p><span className="text-zinc-400 uppercase">Uzņēmums:</span> <span className="font-bold">{selectedOrderForModal.user.companyName}</span></p>
                        <p><span className="text-zinc-400 uppercase">Reģ. nr:</span> <span className="font-bold">{selectedOrderForModal.user.regNo}</span></p>
                      </>
                    )}
                    <p><span className="text-zinc-400 uppercase">E-pasts:</span> <span className="font-bold">{selectedOrderForModal.user?.email || selectedOrderForModal.customerInfo?.email}</span></p>
                    <p><span className="text-zinc-400 uppercase">Tālrunis:</span> <span className="font-bold">{selectedOrderForModal.user?.phone || selectedOrderForModal.customerInfo?.phone}</span></p>
                    <p><span className="text-zinc-400 uppercase">Adrese:</span> <span className="font-bold">{getCustomerAddress(selectedOrderForModal)} {selectedOrderForModal.stationId ? `(Pakomāts: ${selectedOrderForModal.stationId})` : ''}</span></p>
                  </div>
                </div>

                {/* Documents & Actions */}
                <div className="space-y-4">
                  <h4 className="text-xs font-black uppercase tracking-widest pb-2 border-b border-zinc-100">Dokumenti un Darbības</h4>
                  
                  {/* Delivery Document Upload */}
                  <div className="pb-4 mb-4 border-b border-zinc-100">
                    <h5 className="text-[10px] font-black uppercase tracking-widest mb-2 text-zinc-500">Piegādes Dokuments (Kurjers)</h5>
                    {selectedOrderForModal.deliveryDocumentUrl ? (
                      <div className="flex items-center gap-2 mb-3 bg-emerald-50 p-2 border border-emerald-100">
                        <a 
                          href={selectedOrderForModal.deliveryDocumentUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] font-bold text-emerald-600 hover:underline flex items-center gap-1"
                        >
                          <FileText size={12} /> Skatīt dokumentu
                        </a>
                        <span className="text-[9px] text-zinc-400 ml-auto uppercase tracking-widest">Augšupielādēts</span>
                      </div>
                    ) : null}
                    
                    <div className="flex gap-2 items-center">
                      <input 
                        type="file" 
                        accept="application/pdf"
                        onChange={handleDeliveryFileSelect}
                        className="hidden"
                        id="delivery-file-upload"
                      />
                      <label 
                        htmlFor="delivery-file-upload"
                        className="px-4 py-2 bg-zinc-100 text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all flex items-center gap-2 cursor-pointer border border-zinc-200"
                      >
                        <Upload size={12} /> {selectedDeliveryFile ? selectedDeliveryFile.name.substring(0, 15) + '...' : 'Izvēlēties failu'}
                      </label>
                      {selectedDeliveryFile && (
                        <button 
                          onClick={handleUploadDeliveryDocument}
                          disabled={isUploadingDelivery}
                          className="px-4 py-2 bg-[#8DB835] text-white text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all"
                        >
                          {isUploadingDelivery ? <Loader2 size={12} className="animate-spin" /> : 'Augšupielādēt'}
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    {/* Invoice Generation */}
                    <div className="w-full pb-4 mb-4 border-b border-zinc-100">
                      <h5 className="text-[10px] font-black uppercase tracking-widest mb-2 text-zinc-500">Rēķinu Ģenerēšana</h5>
                      <button 
                        onClick={() => handleGenerateInvoice(selectedOrderForModal)}
                        className="px-4 py-2 bg-black text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all flex items-center gap-2"
                      >
                        <FileText size={12} /> Ģenerēt PR
                      </button>
                    </div>

                    {/* Prepayment Invoice Upload */}
                    <div className="w-full pb-4 mb-4 border-b border-zinc-100">
                      <h5 className="text-[10px] font-black uppercase tracking-widest mb-2 text-zinc-500">Priekšapmaksas Rēķins</h5>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-[11px] font-bold">{selectedOrderForModal.invoiceNumber || selectedOrderForModal.id}</span>
                        <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${['PAID', 'PROCESSING', 'IN_DELIVERY', 'SHIPPED', 'COMPLETED'].includes(selectedOrderForModal.status) ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                          {['PAID', 'PROCESSING', 'IN_DELIVERY', 'SHIPPED', 'COMPLETED'].includes(selectedOrderForModal.status) ? 'Apmaksāts' : 'Neapmaksāts'}
                        </span>
                      </div>
                      
                      {selectedOrderForModal.prepaymentInvoiceUrl ? (
                        <div className="flex items-center gap-2 mb-3 bg-emerald-50 p-2 border border-emerald-100">
                          <a 
                            href={selectedOrderForModal.prepaymentInvoiceUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-[10px] font-bold text-emerald-600 hover:underline flex items-center gap-1"
                          >
                            <FileText size={12} /> Skatīt dokumentu
                          </a>
                          <span className="text-[9px] text-zinc-400 ml-auto uppercase tracking-widest">Augšupielādēts</span>
                        </div>
                      ) : null}
                    </div>

                    {/* Invoice Upload */}
                    <div className="w-full pb-4 mb-4 border-b border-zinc-100">
                      <h5 className="text-[10px] font-black uppercase tracking-widest mb-2 text-zinc-500">Pavadzīme</h5>
                      {(selectedOrderForModal.pavadzimeNumber || selectedOrderForModal.rkfInvoiceNumber) && (
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-[11px] font-bold">{selectedOrderForModal.pavadzimeNumber || selectedOrderForModal.rkfInvoiceNumber}</span>
                        </div>
                      )}
                      
                      {selectedOrderForModal.invoiceUrl ? (
                        <div className="flex items-center gap-2 mb-3 bg-emerald-50 p-2 border border-emerald-100">
                          <a 
                            href={selectedOrderForModal.invoiceUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-[10px] font-bold text-emerald-600 hover:underline flex items-center gap-1"
                          >
                            <FileText size={12} /> Skatīt dokumentu
                          </a>
                          <span className="text-[9px] text-zinc-400 ml-auto uppercase tracking-widest">Augšupielādēts</span>
                        </div>
                      ) : null}
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <h5 className="text-[10px] font-black uppercase tracking-widest mb-2">Statuss</h5>
                    <select 
                      value={selectedOrderForModal.status}
                      onChange={(e) => handleStatusChange(selectedOrderForModal.id, e.target.value)}
                      className="w-full p-3 mb-3 border-2 border-zinc-100 text-[11px] font-bold focus:border-black outline-none bg-white"
                    >
                      <option value="NEW">JAUNS (NEW)</option>
                      <option value="PAID">APMAKSĀTS (PAID)</option>
                      <option value="PROCESSING">APSTRĀDĀŠANA (PROCESSING)</option>
                      <option value="IN_DELIVERY">UZ PIEGĀDI (ON DELIVERY)</option>
                      <option value="SHIPPED">IZSŪTĪTS (SENT)</option>
                      <option value="COMPLETED">PABEIGTS (COMPLETED)</option>
                      <option value="CANCELLED">ATCELTS (CANCELLED)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-widest pb-2 border-b border-zinc-100">Pasūtījuma Kopsavilkums</h4>
                <div className="border border-zinc-100 overflow-hidden">
                  <table className="w-full text-left text-[11px]">
                    <thead className="bg-zinc-50 font-black uppercase tracking-widest text-zinc-400">
                      <tr>
                        <th className="px-4 py-3 w-16"></th>
                        <th className="px-4 py-3">Prece</th>
                        <th className="px-4 py-3 text-center">Daudzums</th>
                        <th className="px-4 py-3 text-right">Cena</th>
                        <th className="px-4 py-3 text-right">Kopā</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-50">
                      {selectedOrderForModal.items.map((item: any, idx: number) => (
                        <tr key={item.id || `item-${idx}`}>
                          <td className="px-4 py-3">
                            <div className="w-10 h-10 bg-zinc-100 border border-zinc-200 flex items-center justify-center overflow-hidden">
                              {item.image ? (
                                <img src={item.image} alt={item.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              ) : (
                                <Hash size={16} className="text-zinc-400" />
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <p className="font-bold">{item.title}</p>
                            <p className="text-[9px] text-zinc-400 uppercase">{item.sku}</p>
                          </td>
                          <td className="px-4 py-3 text-center font-bold">{item.quantity}</td>
                          <td className="px-4 py-3 text-right">€{Number(item.priceAtPurchase || item.price || 0).toFixed(2)}</td>
                          <td className="px-4 py-3 text-right font-bold">€{Number((item.priceAtPurchase || item.price || 0) * item.quantity).toFixed(2)}</td>
                        </tr>
                      ))}
                      {Number(selectedOrderForModal.deliveryCost || 0) > 0 && (
                        <tr>
                          <td className="px-4 py-3">
                            <p className="font-bold">Piegāde</p>
                            <p className="text-[9px] text-zinc-400 uppercase">{selectedOrderForModal.deliveryMethod}</p>
                          </td>
                          <td className="px-4 py-3 text-center font-bold">1</td>
                          <td className="px-4 py-3 text-right">€{Number(selectedOrderForModal.deliveryCost).toFixed(2)}</td>
                          <td className="px-4 py-3 text-right font-bold">€{Number(selectedOrderForModal.deliveryCost).toFixed(2)}</td>
                        </tr>
                      )}
                    </tbody>
                    <tfoot className="bg-zinc-50 font-bold">
                      <tr>
                        <td colSpan={4} className="px-4 py-2 text-right uppercase text-zinc-400">Kopējais Svars:</td>
                        <td className="px-4 py-2 text-right">{Number(totalWeight || 0).toFixed(2)} kg</td>
                      </tr>
                      <tr>
                        <td colSpan={4} className="px-4 py-2 text-right uppercase text-zinc-400">Kopā bez PVN:</td>
                        <td className="px-4 py-2 text-right">€{(selectedOrderForModal.subtotal ? Number(selectedOrderForModal.subtotal) + Number(selectedOrderForModal.deliveryCost || 0) : ((selectedOrderForModal.total || 0) / 1.21)).toFixed(2)}</td>
                      </tr>
                      <tr>
                        <td colSpan={4} className="px-4 py-2 text-right uppercase text-zinc-400">PVN 21%:</td>
                        <td className="px-4 py-2 text-right">€{Number(selectedOrderForModal.vatAmount || ((selectedOrderForModal.total || 0) - ((selectedOrderForModal.total || 0) / 1.21)) || 0).toFixed(2)}</td>
                      </tr>
                      <tr className="text-lg">
                        <td colSpan={4} className="px-4 py-3 text-right uppercase">Kopā apmaksai:</td>
                        <td className="px-4 py-3 text-right text-[#8DB835]">€{Number(selectedOrderForModal.totalAmount || selectedOrderForModal.total || 0).toFixed(2)}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              {/* Warranty Section */}
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-widest pb-2 border-b border-zinc-100">Garantijas</h4>
                <div className="border border-zinc-100 overflow-hidden">
                  <table className="w-full text-left text-[11px]">
                    <thead className="bg-zinc-50 font-black uppercase tracking-widest text-zinc-400">
                      <tr>
                        <th className="px-4 py-3">Prece</th>
                        <th className="px-4 py-3 text-right">Garantijas termiņš</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-50">
                      {selectedOrderForModal.items.map((item: any, idx: number) => (
                        <tr key={item.id || `warranty-${idx}`}>
                          <td className="px-4 py-3">
                            <p className="font-bold">{item.title}</p>
                            <p className="text-[9px] text-zinc-400 uppercase">{item.sku}</p>
                          </td>
                          <td className="px-4 py-3 text-right">
                            {editingWarranty?.itemId === item.id ? (
                              <div className="flex items-center justify-end gap-2">
                                <input 
                                  type="date" 
                                  value={editingWarranty.date}
                                  onChange={(e) => setEditingWarranty({ ...editingWarranty, date: e.target.value })}
                                  className="px-2 py-1 border border-zinc-200 text-[10px]"
                                />
                                <button 
                                  onClick={() => handleUpdateWarranty(item.id, editingWarranty.date)}
                                  className="p-1 text-[#8DB835] hover:bg-emerald-50"
                                >
                                  <CheckCircle2 size={14} />
                                </button>
                                <button 
                                  onClick={() => setEditingWarranty(null)}
                                  className="p-1 text-rose-500 hover:bg-rose-50"
                                >
                                  <X size={14} />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-end gap-2">
                                <span className={`font-bold ${item.warrantyUntil && new Date(item.warrantyUntil) < new Date() ? 'text-zinc-400' : 'text-emerald-600'}`}>
                                  {item.warrantyUntil ? new Date(item.warrantyUntil).toLocaleDateString('lv-LV') : 'Nav iestatīts'}
                                </span>
                                <button 
                                  onClick={() => setEditingWarranty({ 
                                    itemId: item.id, 
                                    date: item.warrantyUntil ? new Date(item.warrantyUntil).toISOString().split('T')[0] : new Date().toISOString().split('T')[0] 
                                  })}
                                  className="p-1 text-zinc-400 hover:text-black"
                                >
                                  <Pencil size={12} />
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Tracking */}
                <div className="space-y-4">
                  <h4 className="text-xs font-black uppercase tracking-widest pb-2 border-b border-zinc-100">Sūtījuma Izsekošana</h4>
                  <div className="flex gap-2">
                    <input 
                      type="text"
                      value={adminTrackingNumber}
                      onChange={(e) => setAdminTrackingNumber(e.target.value)}
                      placeholder="Omniva / DPD numurs"
                      className="flex-1 px-4 py-3 border-2 border-zinc-100 text-[11px] focus:border-black outline-none transition-all"
                    />
                    <button 
                      onClick={handleSaveTracking}
                      disabled={isSavingAdminFields}
                      className="px-6 py-3 bg-black text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#8DB835] transition-all disabled:opacity-50"
                    >
                      {isSavingAdminFields ? <Loader2 size={14} className="animate-spin" /> : 'Saglabāt'}
                    </button>
                  </div>
                </div>

                {/* Internal Notes */}
                <div className="space-y-4">
                  <h4 className="text-xs font-black uppercase tracking-widest pb-2 border-b border-zinc-100">Iekšējā Piezīme (Tikai Admin)</h4>
                  <div className="space-y-2">
                    <textarea 
                      value={adminInternalNote}
                      onChange={(e) => setAdminInternalNote(e.target.value)}
                      placeholder="Piezīmes par pasūtījumu..."
                      rows={3}
                      className="w-full px-4 py-3 border-2 border-zinc-100 text-[11px] focus:border-black outline-none transition-all resize-none"
                    />
                    <button 
                      onClick={handleSaveInternalNote}
                      disabled={isSavingAdminFields}
                      className="w-full py-3 bg-zinc-100 text-black text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isSavingAdminFields ? <Loader2 size={14} className="animate-spin" /> : <><Save size={14} /> Saglabāt Piezīmi</>}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
