import React, { useState } from 'react';
import { X, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { Language } from '../types';

interface WithdrawalWidgetProps {
  language: Language;
}

const WithdrawalWidget: React.FC<WithdrawalWidgetProps> = ({ language }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [orderId, setOrderId] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const t = TRANSLATIONS[language];

  const handleNext = () => {
    if (!orderId || !email) {
      setError('Lūdzu, aizpildiet visus laukus');
      return;
    }
    setError('');
    setStep(2);
  };

  const handleConfirm = async () => {
    setIsLoading(true);
    setError('');
    try {
      const response = await fetch('/api/orders/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ orderId, email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to process withdrawal');
      }

      setStep(3);
    } catch (err: any) {
      setError(err.message);
      setStep(1);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors mt-4 block"
      >
        Atteikuma veidlapa (Widerrufsbutton)
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md border-2 border-black shadow-[10px_10px_0px_rgba(0,0,0,0.1)] relative">
            <button 
              onClick={() => { setIsOpen(false); setStep(1); setError(''); }}
              className="absolute top-4 right-4 text-zinc-400 hover:text-black transition-colors"
            >
              <X size={24} />
            </button>

            <div className="p-8">
              <h2 className="text-2xl font-black uppercase tracking-tight mb-6">
                Atteikuma tiesības
              </h2>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-600 text-sm font-bold flex items-start gap-3">
                  <AlertTriangle size={20} className="shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {step === 1 && (
                <div className="space-y-6">
                  <p className="text-sm text-zinc-600 font-medium">
                    Ievadiet pasūtījuma numuru un e-pastu, lai uzsāktu atteikuma procesu.
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                        Pasūtījuma Numurs (Order ID)
                      </label>
                      <input 
                        type="text" 
                        value={orderId}
                        onChange={(e) => setOrderId(e.target.value)}
                        className="w-full bg-zinc-50 border-2 border-zinc-200 p-3 text-sm font-bold focus:border-[#8DB835] focus:outline-none transition-colors"
                        placeholder="Piemēram, ROK/2026-0001 vai ID"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">
                        E-pasts (Email)
                      </label>
                      <input 
                        type="email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-zinc-50 border-2 border-zinc-200 p-3 text-sm font-bold focus:border-[#8DB835] focus:outline-none transition-colors"
                        placeholder="jusu@epasts.lv"
                      />
                    </div>
                  </div>

                  <button 
                    onClick={handleNext}
                    className="w-full bg-black text-white p-4 text-[11px] font-black uppercase tracking-widest hover:bg-[#8DB835] hover:text-black transition-colors"
                  >
                    Turpināt
                  </button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="p-4 bg-zinc-50 border-2 border-zinc-200 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-500 font-bold">Pasūtījums:</span>
                      <span className="font-black">{orderId}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-500 font-bold">E-pasts:</span>
                      <span className="font-black">{email}</span>
                    </div>
                  </div>

                  <p className="text-sm text-zinc-600 font-medium">
                    Vai tiešām vēlaties atteikties no šī pasūtījuma? Šī darbība nav atsaucama.
                  </p>

                  <div className="flex gap-4">
                    <button 
                      onClick={() => setStep(1)}
                      disabled={isLoading}
                      className="flex-1 bg-zinc-100 text-black p-4 text-[11px] font-black uppercase tracking-widest hover:bg-zinc-200 transition-colors disabled:opacity-50"
                    >
                      Atpakaļ
                    </button>
                    <button 
                      onClick={handleConfirm}
                      disabled={isLoading}
                      className="flex-1 bg-red-600 text-white p-4 text-[11px] font-black uppercase tracking-widest hover:bg-red-700 transition-colors disabled:opacity-50"
                    >
                      {isLoading ? 'Lūdzu uzgaidiet...' : 'Confirm withdrawal'}
                    </button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6 text-center py-8">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 size={32} />
                  </div>
                  <h3 className="text-xl font-black uppercase tracking-tight">
                    Atteikums pieņemts
                  </h3>
                  <p className="text-sm text-zinc-600 font-medium">
                    Jūsu atteikums ir reģistrēts. Apstiprinājums nosūtīts uz jūsu e-pastu.
                  </p>
                  <button 
                    onClick={() => { setIsOpen(false); setStep(1); setError(''); setOrderId(''); setEmail(''); }}
                    className="w-full mt-4 bg-black text-white p-4 text-[11px] font-black uppercase tracking-widest hover:bg-[#8DB835] hover:text-black transition-colors"
                  >
                    Aizvērt
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default WithdrawalWidget;