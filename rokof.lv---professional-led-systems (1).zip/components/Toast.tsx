
import React, { useEffect } from 'react';
import { CheckCircle2, X } from 'lucide-react';

interface ToastProps {
  id: string;
  message: string;
  onClose: (id: string) => void;
}

const Toast: React.FC<ToastProps> = ({ id, message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => onClose(id), 3000);
    return () => clearTimeout(timer);
  }, [id, onClose]);

  return (
    <div className="flex items-center gap-4 bg-black text-white p-4 pr-6 shadow-[0_10px_40px_rgba(0,0,0,0.2)] border-l-4 border-[#8DB835] animate-in slide-in-from-right fade-in duration-300 pointer-events-auto font-sans">
      <div className="text-[#8DB835]">
        <CheckCircle2 size={18} />
      </div>
      <div className="flex flex-col">
        <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-0.5">Notification</span>
        <span className="text-[11px] font-black uppercase tracking-tight">{message}</span>
      </div>
      <button 
        onClick={() => onClose(id)}
        className="ml-4 text-zinc-500 hover:text-white transition-colors"
      >
        <X size={14} />
      </button>
    </div>
  );
};

export default Toast;
