
import React, { useState } from 'react';
import { Calculator as CalcIcon, Info } from 'lucide-react';

const Calculator: React.FC = () => {
  const [meters, setMeters] = useState<number>(5);
  const [wattsPerMeter, setWattsPerMeter] = useState<number>(14.4);
  const [safetyFactor, setSafetyFactor] = useState<number>(1.2);

  const totalWatts = meters * wattsPerMeter;
  const recommendedWatts = totalWatts * safetyFactor;

  return (
    <div className="bg-white border border-zinc-200 p-8 rounded-none shadow-sm">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 bg-zinc-100 rounded flex items-center justify-center">
          <CalcIcon className="w-5 h-5 text-black" />
        </div>
        <div>
          <h2 className="text-lg font-black uppercase tracking-tight">PSU Load Calculator</h2>
          <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Engineering Utility v1.0</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
        <div className="space-y-3">
          <label className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Total Length (meters)</label>
          <input 
            type="number" 
            value={meters}
            onChange={(e) => setMeters(Number(e.target.value))}
            className="w-full bg-zinc-50 border border-zinc-200 p-3 text-sm focus:outline-none focus:border-black transition-colors"
          />
        </div>
        <div className="space-y-3">
          <label className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Power Draw (W/m)</label>
          <select 
            value={wattsPerMeter}
            onChange={(e) => setWattsPerMeter(Number(e.target.value))}
            className="w-full bg-zinc-50 border border-zinc-200 p-3 text-sm focus:outline-none focus:border-black transition-colors"
          >
            <option value={4.8}>4.8 W/m - Ambient</option>
            <option value={7.2}>7.2 W/m - Decorative</option>
            <option value={14.4}>14.4 W/m - Professional</option>
            <option value={19.2}>19.2 W/m - Industrial</option>
          </select>
        </div>
        <div className="space-y-3">
          <label className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Safety Overhead</label>
          <select 
            value={safetyFactor}
            onChange={(e) => setSafetyFactor(Number(e.target.value))}
            className="w-full bg-zinc-50 border border-zinc-200 p-3 text-sm focus:outline-none focus:border-black transition-colors"
          >
            <option value={1.1}>10% Buffer</option>
            <option value={1.2}>20% Recommended</option>
            <option value={1.3}>30% Industrial</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-6 bg-zinc-50 border border-zinc-200">
          <div className="text-[10px] text-zinc-400 font-black uppercase tracking-widest mb-1">Raw Consumption</div>
          <div className="text-3xl font-black text-black">{totalWatts.toFixed(1)} <span className="text-sm font-normal text-zinc-400">Watts</span></div>
        </div>
        <div className="p-6 bg-black">
          <div className="text-[10px] text-zinc-400 font-black uppercase tracking-widest mb-1">Required PSU Rating</div>
          <div className="text-3xl font-black text-white">{recommendedWatts.toFixed(1)} <span className="text-sm font-normal text-zinc-500">Watts</span></div>
        </div>
      </div>

      <div className="mt-8 flex gap-3 items-start text-[11px] text-zinc-500 italic bg-zinc-50 p-4 border border-zinc-200">
        <Info className="w-4 h-4 flex-shrink-0 text-zinc-400" />
        <p>Technical Note: Power supplies should ideally operate at 50-80% of their rated capacity for maximum longevity and efficiency.</p>
      </div>
    </div>
  );
};

export default Calculator;
