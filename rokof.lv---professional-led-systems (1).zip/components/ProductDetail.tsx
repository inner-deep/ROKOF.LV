
import React, { useState } from 'react';
import { X, ShoppingCart, Minus, Plus, ArrowLeft, Info, Tag, Heart, Truck } from 'lucide-react';
import { Product, Language, User } from '../types';
import { TRANSLATIONS, VAT_RATE } from '../constants';
import { getPersonalizedPrice } from '../src/utils/calculations';

interface ProductDetailProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (p: Product, qty: number) => void;
  language: Language;
  user: User | null;
  isWishlisted?: boolean;
  onToggleWishlist?: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ 
  product, onClose, onAddToCart, language, user, isWishlisted, onToggleWishlist
}) => {
  const [qty, setQty] = useState(5);
  const t = TRANSLATIONS[language];
  const isB2B = user?.type === 'BUSINESS';
  
  const netPrice = getPersonalizedPrice(product.price, product.b2bPrice, user);
  const grossPrice = netPrice * (1 + VAT_RATE);
  const isOutOfStock = product.stockQuantity <= 0;
  const isDiscounted = netPrice < product.price;

  const specLabels = t.specs;
  const s = product.specifications;

  // Ordered array matching the screenshot's standard layout
  const fullSpecs = [
    { label: specLabels.dimmable, value: s.dimmable },
    { label: specLabels.power, value: s.powerPerMeter },
    { label: specLabels.nodesPerMeter, value: s.nodesPerMeter },
    { label: specLabels.ipRating, value: s.ipRating },
    { label: specLabels.cuttingLength, value: s.cuttingLength },
    { label: specLabels.voltage, value: s.voltage },
    { label: specLabels.voltageType, value: s.voltageType },
    { label: specLabels.colorTemp, value: s.colorTemperature },
    { label: specLabels.cri, value: s.cri },
    { label: specLabels.energyClass, value: s.energyClass },
    { label: specLabels.luminousFlux, value: s.luminousFlux },
    { label: specLabels.beamAngle, value: s.beamAngle },
    { label: specLabels.width, value: s.width },
    { label: specLabels.height, value: s.height },
    { label: specLabels.colorConsistency, value: s.colorConsistency },
    { label: specLabels.operatingTemp, value: s.operatingTemp }
  ].filter(item => item.value !== undefined);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-white overflow-hidden animate-in slide-in-from-right duration-500">
      <div className="px-6 md:px-12 py-6 flex items-center justify-between shrink-0 bg-white border-b border-zinc-50">
        <button 
          onClick={onClose} 
          className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 hover:text-black transition-colors"
        >
          <ArrowLeft size={14} strokeWidth={3} /> {t.backToCatalog}
        </button>
        <div className="flex items-center gap-6">
          <button 
            onClick={() => onToggleWishlist?.()} 
            className={`p-2 transition-all ${isWishlisted ? 'text-[#8DB835]' : 'text-zinc-300 hover:text-black'}`}
          >
            <Heart size={24} fill={isWishlisted ? '#8DB835' : 'none'} />
          </button>
          <button onClick={onClose} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
            <X size={32} strokeWidth={1.5} />
          </button>
        </div>
      </div>

      <div className="flex-grow overflow-y-auto no-scrollbar">
        <div className="container mx-auto px-6 md:px-12 py-10 md:py-16">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-24 items-start">
            <div className="lg:w-[45%] w-full">
              <div className="aspect-square md:aspect-[16/10] border border-zinc-100 bg-[#FBFBFB] flex items-center justify-center p-12 relative shadow-sm">
                <img 
                  src={product.images?.[0] || 'https://picsum.photos/seed/rokof/800/600'} 
                  className={`max-w-full max-h-full object-contain mix-blend-multiply transition-all duration-700 ${isOutOfStock ? 'grayscale opacity-50' : ''}`} 
                  alt={product.title?.[language] || product.sku} 
                />
                <div className="absolute top-8 left-8 flex flex-col gap-2">
                  {isOutOfStock && (
                    <div className="bg-rose-500 text-white px-4 py-2 text-[10px] font-black uppercase tracking-widest shadow-lg">
                      {t.stockStatus.out}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="mt-12 space-y-8">
                <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300 border-b pb-4">{t.description}</h3>
                <p className="text-zinc-500 text-[14px] leading-relaxed font-medium">
                  {product.description?.[language] || ''}
                </p>
              </div>
            </div>

            <div className="lg:w-[55%] w-full flex flex-col">
              <div className="mb-8">
                <span className="text-[11px] font-black text-[#8DB835] uppercase tracking-[0.3em] mb-2 block">{product.sku}</span>
                <h1 className="text-2xl md:text-3xl font-black text-black uppercase tracking-tight leading-tight mb-8">
                  {product.title?.[language] || ''}
                </h1>

                <div className="bg-[#F8F9FA] p-8 md:p-10 border border-zinc-200 mb-12">
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                       <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                         {isB2B ? t.partnerPrice : t.retailPrice}
                       </span>
                       {isDiscounted && (
                         <span className="bg-[#8DB835] text-white px-3 py-1 text-[9px] font-black uppercase tracking-widest flex items-center gap-2">
                           <Tag size={12} /> {t.personalDiscount}: {user.discountLevel || 20}%
                         </span>
                       )}
                    </div>
                    <div className="flex items-baseline gap-4">
                       <span className={`text-5xl md:text-6xl font-black tracking-tighter leading-none ${isB2B ? 'text-[#8DB835]' : 'text-black'}`}>
                          €{netPrice.toFixed(2)}
                       </span>
                       {product.onSale && product.originalPrice && (
                         <span className="text-2xl text-slate-400 line-through font-bold">
                           €{product.originalPrice.toFixed(2)}
                         </span>
                       )}
                       <span className="text-zinc-400 font-black uppercase tracking-[0.3em] text-[11px]">
                          / {product.unit.toUpperCase()} {t.priceNet}
                       </span>
                    </div>
                    {product.onSale && product.lowestPrice30d && (
                      <div className="text-[10px] font-bold text-slate-500 italic mt-[-8px]">
                        {t.lowestPrice30d.replace('{price}', product.lowestPrice30d.toFixed(2))}
                      </div>
                    )}
                    <div className="text-[14px] font-bold text-rose-600">
                      €{grossPrice.toFixed(2)} {t.priceGross}
                    </div>
                  </div>
                </div>

                {/* TECHNICAL DATA GRID - Matching provided screenshot style */}
                <div className="grid grid-cols-2 gap-y-12 gap-x-8">
                  {fullSpecs.map((spec, idx) => (
                    <div key={idx} className="flex flex-col">
                      <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1.5 leading-none">
                        {spec.label}
                      </span>
                      <p className="text-[13px] md:text-[14px] font-black uppercase text-black">
                        {spec.value || '-'}
                      </p>
                    </div>
                  ))}
                </div>

                {/* GPSR Compliance Info */}
                {(product.energyClass || product.technicalDocumentationUrl || product.euResponsiblePerson) && (
                  <div className="mt-12 pt-12 border-t border-zinc-100 space-y-8">
                    <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-300">{t.gpsrTitle}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {product.energyClass && (
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">{t.energyClassLabel}</span>
                          <div className={`w-10 h-10 flex items-center justify-center font-black text-white rounded-sm ${
                            ['A','B'].includes(product.energyClass) ? 'bg-emerald-500' :
                            ['C','D'].includes(product.energyClass) ? 'bg-yellow-500' : 'bg-rose-500'
                          }`}>
                            {product.energyClass}
                          </div>
                        </div>
                      )}
                      {product.technicalDocumentationUrl && (
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">{t.techDocLabel}</span>
                          <a 
                            href={product.technicalDocumentationUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-[13px] font-black uppercase text-[#8DB835] hover:underline flex items-center gap-2"
                          >
                            <Info size={14} /> {t.download}
                          </a>
                        </div>
                      )}
                      {product.euResponsiblePerson && (
                        <div className="flex flex-col col-span-full">
                          <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">{t.responsiblePersonLabel}</span>
                          <div className="text-[13px] text-zinc-600 bg-zinc-50 p-4 border border-zinc-100">
                            <p className="font-black text-black uppercase mb-1">{product.euResponsiblePerson.name}</p>
                            <p>{product.euResponsiblePerson.address}</p>
                            <p>{product.euResponsiblePerson.email}</p>
                            {product.euResponsiblePerson.phone && <p>{product.euResponsiblePerson.phone}</p>}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-12 pt-12 border-t border-zinc-100">
                <div className="flex flex-col gap-3">
                  <div className={`flex items-center h-16 ${isOutOfStock ? 'opacity-40' : ''}`}>
                    <div className="flex items-center bg-white h-full border border-zinc-200 rounded-md overflow-hidden shrink-0">
                      <button 
                        disabled={isOutOfStock}
                        onClick={() => setQty(Math.max(5, qty - 5))} 
                        className="w-14 h-full flex items-center justify-center bg-zinc-50 hover:bg-zinc-100 text-zinc-400 transition-colors border-r border-zinc-200"
                      >
                        <Minus size={16} strokeWidth={3} />
                      </button>
                      <div className="w-16 h-full flex items-center justify-center font-black text-black text-lg bg-white">
                        {qty}
                      </div>
                      <button 
                        disabled={isOutOfStock}
                        onClick={() => setQty(qty + 5)} 
                        className="w-14 h-full flex items-center justify-center bg-zinc-50 hover:bg-zinc-100 text-zinc-400 transition-colors border-l border-zinc-200"
                      >
                        <Plus size={16} strokeWidth={3} />
                      </button>
                    </div>
                    
                    <button 
                      disabled={isOutOfStock}
                      onClick={() => onAddToCart(product, qty)}
                      className={`ml-4 flex-grow h-full bg-black text-white text-[12px] font-bold uppercase tracking-wider rounded-md transition-all flex items-center justify-center gap-4 active:scale-[0.98] ${isOutOfStock ? 'bg-zinc-50 text-zinc-300 cursor-not-allowed shadow-none' : 'shadow-xl hover:bg-zinc-800'}`}
                    >
                      <ShoppingCart size={20} className="stroke-[2.5px]" />
                      {isOutOfStock ? t.stockStatus.out : t.add}
                    </button>
                  </div>
                  <div className="text-center mt-1">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{t.minStep}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
