
import React, { useState } from 'react';
import { X, Send, CheckCircle2, Loader2, Info } from 'lucide-react';
import { Product, Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { sendInquiryNotification } from '../services/mailService';

interface InquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  language: Language;
}

const InquiryModal: React.FC<InquiryModalProps> = ({ isOpen, onClose, product, language }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const t = TRANSLATIONS[language];

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
    quantity: '5' // Минимум 5 метров
  });

  if (!isOpen || !product) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (parseInt(formData.quantity) < 5) {
      alert("Minimum order is 5m");
      return;
    }
    setIsSubmitting(true);
    
    try {
      await sendInquiryNotification(product, formData, language);
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 3000);
    } catch (error) {
      console.error("Failed to send inquiry:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300" 
        onClick={onClose} 
      />
      
      <div className="relative w-full max-w-xl bg-white shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        {isSuccess ? (
          <div className="p-16 flex flex-col items-center text-center space-y-6">
            <div className="w-20 h-20 bg-[#8DB835]/10 rounded-full flex items-center justify-center text-[#8DB835] mb-4">
              <CheckCircle2 size={48} />
            </div>
            <h3 className="text-2xl font-black uppercase tracking-tight">Inquiry Sent</h3>
            <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest max-w-xs">
              We have received your technical inquiry. Our engineers will contact you shortly.
            </p>
          </div>
        ) : (
          <>
            <div className="p-8 border-b border-zinc-100 flex items-center justify-between bg-black text-white">
              <div className="flex flex-col">
                <span className="text-[8px] font-black uppercase tracking-[0.3em] text-zinc-500 mb-1">Technical Inquiry</span>
                <h3 className="text-sm font-black uppercase tracking-widest">{product.title?.[language] || ''}</h3>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-zinc-800 transition-colors">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-10 space-y-8">
              <div className="flex gap-4 p-4 bg-zinc-50 border border-zinc-100">
                <div className="w-16 h-16 bg-white border border-zinc-200 p-1 shrink-0">
                  <img src={product.images?.[0] || 'https://picsum.photos/seed/rokof/800/600'} className="w-full h-full object-cover grayscale" alt={product.sku} />
                </div>
                <div>
                  <p className="text-[10px] font-black text-black uppercase mb-1">{product.sku}</p>
                  <p className="text-[9px] text-zinc-400 font-bold uppercase tracking-tight leading-tight">
                    Technical consultation and wholesale quote request
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-[#F8F9FA] border border-[#DEE2E6] px-5 py-3 text-xs font-bold focus:outline-none focus:border-black transition-colors" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Quantity (Min 5m)</label>
                  <input 
                    type="number" 
                    required
                    min="5"
                    step="5"
                    value={formData.quantity}
                    onChange={e => setFormData({...formData, quantity: e.target.value})}
                    className="w-full bg-[#F8F9FA] border border-[#DEE2E6] px-5 py-3 text-xs font-bold focus:outline-none focus:border-black transition-colors" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Email</label>
                  <input 
                    type="email" 
                    required
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                    className="w-full bg-[#F8F9FA] border border-[#DEE2E6] px-5 py-3 text-xs font-bold focus:outline-none focus:border-black transition-colors" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Phone</label>
                  <input 
                    type="tel" 
                    required
                    value={formData.phone}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                    className="w-full bg-[#F8F9FA] border border-[#DEE2E6] px-5 py-3 text-xs font-bold focus:outline-none focus:border-black transition-colors" 
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Project Details</label>
                <textarea 
                  rows={4}
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                  className="w-full bg-[#F8F9FA] border border-[#DEE2E6] px-5 py-4 text-xs font-bold focus:outline-none focus:border-black transition-colors resize-none" 
                  placeholder="Describe your project requirements..."
                />
              </div>

              <div className="pt-4">
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-5 bg-black text-white text-[11px] font-black uppercase tracking-[0.3em] flex items-center justify-center gap-4 hover:bg-zinc-800 transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                  Send Inquiry
                </button>
              </div>

              <div className="flex gap-2 items-start text-[9px] text-zinc-400 font-bold uppercase tracking-widest">
                <Info size={12} className="shrink-0 text-zinc-300" />
                Requests are processed within 2-4 working hours.
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default InquiryModal;
