
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, Phone, Mail, MapPin, Building2, CreditCard } from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { Language, Page } from '../types';
import WithdrawalWidget from './WithdrawalWidget';

interface FooterProps {
  language: Language;
}

const Footer: React.FC<FooterProps> = ({ language }) => {
  const navigate = useNavigate();
  const t = TRANSLATIONS[language];

  return (
    <footer className="bg-black text-white pt-20 pb-10 mt-auto border-t border-zinc-900">
      <div className="container mx-auto px-4 xl:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 xl:gap-x-12 gap-y-16 mb-16">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#8DB835] flex items-center justify-center">
                <Zap className="text-black w-6 h-6 fill-black" />
              </div>
              <span className="text-2xl font-black tracking-tighter uppercase">
                ROKOF<span className="text-[#8DB835]">.LV</span>
              </span>
            </div>
            <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-widest leading-relaxed max-w-xs">
              {t.siteSlogan}
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-none bg-zinc-900 flex items-center justify-center hover:bg-[#8DB835] hover:text-black transition-all">
                <span className="text-xs font-black">FB</span>
              </a>
              <a href="#" className="w-10 h-10 rounded-none bg-zinc-900 flex items-center justify-center hover:bg-[#8DB835] hover:text-black transition-all">
                <span className="text-xs font-black">IG</span>
              </a>
            </div>
          </div>

          {/* Navigation Column */}
          <div className="space-y-6">
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#8DB835] border-b border-zinc-900 pb-3">{t.about}</h4>
            <nav className="flex flex-col gap-4">
              <button onClick={() => navigate('/')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">Katalogs</button>
              <button onClick={() => navigate('/partners')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">B2B zona</button>
              <button onClick={() => navigate('/contacts')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">Kontakti</button>
            </nav>
          </div>

          {/* Legal Column */}
          <div className="space-y-6">
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#8DB835] border-b border-zinc-900 pb-3">{t.legal}</h4>
            <nav className="flex flex-col gap-4">
              <button onClick={() => navigate('/terms')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">{t.distanceContract}</button>
              <button onClick={() => navigate('/privacy')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">{t.privacyPolicy}</button>
              <button onClick={() => navigate('/delivery')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">{t.deliveryPayment}</button>
              <button onClick={() => navigate('/returns')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">{t.returnsPolicy}</button>
              <button onClick={() => navigate('/faq')} className="text-[11px] font-black uppercase tracking-widest text-zinc-400 hover:text-white text-left transition-colors">{t.faq}</button>
              <WithdrawalWidget language={language} />
            </nav>
          </div>

          {/* Company Data Column */}
          <div className="space-y-6">
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#8DB835] border-b border-zinc-900 pb-3">{t.contacts}</h4>
            <div className="flex flex-col gap-6">
              <div className="flex items-start gap-4">
                <Building2 size={16} className="text-[#8DB835] mt-1 shrink-0" />
                <div className="text-[11px] font-bold text-zinc-400 uppercase leading-tight flex flex-col gap-1">
                  <span className="text-white font-black">{t.companyName}</span>
                  <span>{t.regNo}</span>
                  <span>{t.vatNo}</span>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <MapPin size={16} className="text-[#8DB835] mt-1 shrink-0" />
                <div className="text-[11px] font-bold text-zinc-400 uppercase leading-tight">{t.address}</div>
              </div>
              <div className="flex items-start gap-4">
                <CreditCard size={16} className="text-[#8DB835] mt-1 shrink-0" />
                <div className="text-[11px] font-bold text-zinc-400 uppercase leading-tight flex flex-col gap-1">
                  <span className="text-white font-black">{t.bank}</span>
                  <span>{t.swift}</span>
                  <span>{t.iban}</span>
                </div>
              </div>
              <div className="flex flex-col gap-4 pt-2">
                <a href={`tel:${t.phone}`} className="flex items-center gap-4 text-zinc-400 hover:text-[#8DB835] transition-colors">
                  <Phone size={16} /> <span className="text-[11px] font-black uppercase">{t.phone}</span>
                </a>
                <a href={`mailto:${t.email}`} className="flex items-center gap-4 text-zinc-400 hover:text-[#8DB835] transition-colors">
                  <Mail size={16} /> <span className="text-[11px] font-black uppercase">{t.email}</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-zinc-900 pt-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] font-black uppercase text-zinc-600 tracking-widest text-center md:text-left">
            © {new Date().getFullYear()} {t.companyName}. {t.rights}
          </p>
          <div className="flex items-center gap-8">
             <div className="h-6 w-10 bg-zinc-900/50 border border-zinc-800 rounded-sm"></div>
             <div className="h-6 w-10 bg-zinc-900/50 border border-zinc-800 rounded-sm"></div>
             <div className="h-6 w-10 bg-zinc-900/50 border border-zinc-800 rounded-sm"></div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
