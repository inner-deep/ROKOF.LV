import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Sparkles, X } from 'lucide-react';
import { getLightingAdvice } from '../services/geminiService';

const GeminiConsultant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', content: string}[]>([
    { role: 'model', content: "Sveiki. I am Roko, the project assistant for ROKOF.LV. \n\nAre you looking for a residential lighting kit or do you need a technical estimation for a B2B project today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    const history = messages.slice(-5);
    const response = await getLightingAdvice(userMsg, history);
    
    setMessages(prev => [...prev, { role: 'model', content: response }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-10 right-10 z-[60]">
      {isOpen ? (
        <div className="w-80 md:w-[450px] h-[600px] bg-white border border-zinc-900 flex flex-col shadow-[40px_40px_0px_rgba(0,0,0,0.05)] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
          <div className="p-6 bg-black flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <Sparkles className="w-4 h-4" />
              <div className="flex flex-col">
                 <span className="text-[10px] font-black uppercase tracking-widest">ROKOF Technical AI</span>
                 <span className="text-[8px] text-zinc-500 font-bold uppercase tracking-widest">Consultant #ROKO-01</span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="w-8 h-8 flex items-center justify-center hover:bg-zinc-800 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-grow p-8 overflow-y-auto space-y-8 bg-zinc-50/30">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] p-5 text-xs leading-relaxed shadow-sm whitespace-pre-wrap ${
                  m.role === 'user' 
                    ? 'bg-black text-white font-medium' 
                    : 'bg-white text-zinc-600 border border-zinc-100'
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-5 border border-zinc-100">
                  <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 bg-black rounded-full animate-pulse" />
                    <div className="w-1.5 h-1.5 bg-black rounded-full animate-pulse [animation-delay:0.2s]" />
                    <div className="w-1.5 h-1.5 bg-black rounded-full animate-pulse [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 border-t border-zinc-200 bg-white flex gap-4">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask Roko about project specs..."
              className="flex-grow bg-zinc-50 border border-zinc-200 px-5 py-4 text-xs focus:outline-none focus:border-black transition-colors"
            />
            <button 
              onClick={handleSend}
              disabled={isLoading}
              className="px-6 bg-black text-white hover:bg-zinc-800 transition-all disabled:opacity-20"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-20 h-20 bg-black text-white flex flex-col items-center justify-center shadow-2xl hover:scale-105 transition-transform group relative"
        >
          <Bot className="w-8 h-8 mb-1" />
          <span className="text-[8px] font-black uppercase tracking-widest">ROKO AI</span>
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
        </button>
      )}
    </div>
  );
};

export default GeminiConsultant;