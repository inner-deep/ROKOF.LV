
import React, { useState } from 'react';
import { 
  Building2, Phone, Mail, MapPin, CreditCard, 
  Send, CheckCircle2, Loader2, Globe, Landmark
} from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { Language } from '../types';

interface ContactsPageProps {
  language: Language;
}

const ContactsPage: React.FC<ContactsPageProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const ft = TRANSLATIONS[language];
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulation
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({ firstName: '', lastName: '', email: '', phone: '', message: '' });
      setTimeout(() => setIsSuccess(false), 5000);
    }, 1500);
  };

  // Fix: Making children optional to resolve TypeScript "missing children" error when using component as a wrapper
  const InfoBlock = ({ title, icon: Icon, children }: { title: string, icon: any, children?: React.ReactNode }) => (
    <div className="bg-white border-2 border-black p-8 shadow-[10px_10px_0px_rgba(0,0,0,0.05)] h-full">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-10 h-10 bg-[#8DB835] flex items-center justify-center text-black">
          <Icon size={20} />
        </div>
        <h3 className="text-[14px] font-black uppercase tracking-widest text-black">{title}</h3>
      </div>
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );

  return (
    <div className="py-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="mb-16 text-center lg:text-left">
          <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tight mb-4">{t.title}</h1>
          <p className="text-zinc-400 text-sm font-black uppercase tracking-widest">{t.subtitle}</p>
          <div className="w-20 h-1.5 bg-[#8DB835] mt-6 mx-auto lg:mx-0"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
          {/* Rekvizīti */}
          <InfoBlock title={t.requisites} icon={Building2}>
            <div className="space-y-4">
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{ft.companyName}</span>
                <p className="text-sm font-bold text-black">ROKOF SIA</p>
              </div>
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.regNo}</span>
                <p className="text-sm font-bold text-black">40203287104</p>
              </div>
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.vatNo}</span>
                <p className="text-sm font-bold text-black">LV40203287104</p>
              </div>
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.address}</span>
                <p className="text-sm font-bold text-black">Pūces iela 11/1-7, Rīga, LV-1082</p>
              </div>
            </div>
          </InfoBlock>

          {/* Saziņa */}
          <InfoBlock title={t.communication} icon={Globe}>
            <div className="space-y-6">
              <a href="tel:+37129577303" className="flex items-start gap-4 group transition-colors">
                <div className="w-10 h-10 border border-zinc-100 flex items-center justify-center shrink-0 group-hover:border-[#8DB835] group-hover:bg-[#8DB835]/5">
                  <Phone size={16} className="text-zinc-400 group-hover:text-black" />
                </div>
                <div>
                  <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.phone}</span>
                  <p className="text-sm font-bold text-black group-hover:text-[#8DB835]">+371 29577303</p>
                </div>
              </a>
              <a href="mailto:pavels@pzka.lv" className="flex items-start gap-4 group transition-colors">
                <div className="w-10 h-10 border border-zinc-100 flex items-center justify-center shrink-0 group-hover:border-[#8DB835] group-hover:bg-[#8DB835]/5">
                  <Mail size={16} className="text-zinc-400 group-hover:text-black" />
                </div>
                <div>
                  <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.email}</span>
                  <p className="text-sm font-bold text-black group-hover:text-[#8DB835]">pavels@pzka.lv</p>
                </div>
              </a>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 border border-zinc-100 flex items-center justify-center shrink-0">
                  <MapPin size={16} className="text-zinc-400" />
                </div>
                <div>
                  <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">Noliktava</span>
                  <p className="text-sm font-bold text-black uppercase">Rīga, Pūces iela 11/1-7</p>
                </div>
              </div>
            </div>
          </InfoBlock>

          {/* Bankas dati */}
          <InfoBlock title={t.bankData} icon={Landmark}>
            <div className="space-y-4">
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.bank}</span>
                <p className="text-sm font-bold text-black">AS "Citadele banka"</p>
              </div>
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.iban}</span>
                <p className="text-sm font-bold text-black break-all">LV47PARX0023781080001</p>
              </div>
              <div>
                <span className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t.swift}</span>
                <p className="text-sm font-bold text-black">PARXLV22</p>
              </div>
            </div>
          </InfoBlock>
        </div>

        {/* Feedback Form */}
        <div className="bg-zinc-900 text-white p-10 lg:p-16 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#8DB835]/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
          
          <div className="relative z-10">
            <h2 className="text-3xl font-black uppercase tracking-tight mb-12 flex items-center gap-4">
              <Send size={24} className="text-[#8DB835]" /> {t.formTitle}
            </h2>

            {isSuccess ? (
              <div className="py-20 text-center flex flex-col items-center animate-in zoom-in-95 duration-500">
                <div className="w-20 h-20 bg-[#8DB835] text-black rounded-none flex items-center justify-center mb-8 shadow-xl">
                  <CheckCircle2 size={40} />
                </div>
                <h3 className="text-2xl font-black uppercase tracking-tight mb-4">{t.success}</h3>
                <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest">Mēs sazināsimies ar jums pēc iespējas ātrāk.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest pl-1">{t.firstName}</label>
                    <input 
                      required
                      type="text" 
                      value={formData.firstName}
                      onChange={e => setFormData({...formData, firstName: e.target.value})}
                      className="w-full bg-zinc-800 border-2 border-zinc-700 px-6 py-4 text-xs font-bold text-white focus:outline-none focus:border-[#8DB835] transition-colors"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest pl-1">{t.lastName}</label>
                    <input 
                      required
                      type="text" 
                      value={formData.lastName}
                      onChange={e => setFormData({...formData, lastName: e.target.value})}
                      className="w-full bg-zinc-800 border-2 border-zinc-700 px-6 py-4 text-xs font-bold text-white focus:outline-none focus:border-[#8DB835] transition-colors"
                    />
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest pl-1">{t.email}</label>
                    <input 
                      required
                      type="email" 
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full bg-zinc-800 border-2 border-zinc-700 px-6 py-4 text-xs font-bold text-white focus:outline-none focus:border-[#8DB835] transition-colors"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest pl-1">{t.phone}</label>
                    <input 
                      type="tel" 
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                      className="w-full bg-zinc-800 border-2 border-zinc-700 px-6 py-4 text-xs font-bold text-white focus:outline-none focus:border-[#8DB835] transition-colors"
                    />
                  </div>
                </div>

                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest pl-1">{t.message}</label>
                  <textarea 
                    required
                    rows={5}
                    value={formData.message}
                    onChange={e => setFormData({...formData, message: e.target.value})}
                    className="w-full bg-zinc-800 border-2 border-zinc-700 px-6 py-4 text-xs font-bold text-white focus:outline-none focus:border-[#8DB835] transition-colors resize-none"
                  />
                </div>

                <div className="md:col-span-2 pt-4">
                  <button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full md:w-auto px-12 py-5 bg-[#8DB835] text-black text-[11px] font-black uppercase tracking-[0.3em] flex items-center justify-center gap-4 hover:bg-white hover:text-black transition-all active:scale-[0.98] disabled:opacity-50"
                  >
                    {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                    {isSubmitting ? t.sending : t.send}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactsPage;
