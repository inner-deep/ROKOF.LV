
import React from 'react';
import { 
  Briefcase, Truck, Headset, 
  ArrowRight, ShieldCheck, Building2, UserPlus, Percent, Clock
} from 'lucide-react';
import { TRANSLATIONS } from '../constants';
import { Language } from '../types';

interface PartnersPageProps {
  language: Language;
  onOpenAuth: (mode?: 'login' | 'signup', type?: 'B2C' | 'B2B') => void;
}

const PartnersPage: React.FC<PartnersPageProps> = ({ language, onOpenAuth }) => {
  const t = TRANSLATIONS[language];
  const gl = TRANSLATIONS[language];

  return (
    <div className="py-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header Section */}
        <div className="mb-24 text-center">
          <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight mb-6 leading-tight">
            {t.b2bZone}
          </h1>
          <p className="text-zinc-500 text-sm md:text-base font-bold uppercase tracking-[0.2em] leading-relaxed max-w-3xl mx-auto">
            {t.partnerZoneDesc}
          </p>
          <div className="w-24 h-1 bg-[#8DB835] mt-8 mx-auto"></div>
        </div>

        {/* Benefits Grid - Matches screenshot style */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {[
            { icon: Percent, text: t.benefit1 },
            { icon: Truck, text: t.benefit2 },
            { icon: Headset, text: t.benefit3 }
          ].map((benefit, i) => (
            <div key={i} className="bg-white border border-zinc-200 p-12 flex flex-col items-center text-center shadow-[15px_15px_60px_-15px_rgba(0,0,0,0.08)] transition-all hover:translate-y-[-4px]">
              <div className="w-16 h-16 bg-[#F8F9FA] flex items-center justify-center mb-10 rounded-none border border-zinc-100">
                <benefit.icon size={32} className="text-black" strokeWidth={1.5} />
              </div>
              <p className="text-[12px] font-black uppercase tracking-[0.1em] leading-relaxed text-black max-w-[200px]">
                {benefit.text}
              </p>
            </div>
          ))}
        </div>

        {/* Shipping Time Notice for B2B */}
        <div className="max-w-3xl mx-auto mb-24 p-6 bg-[#F9F4E8] border border-[#8DB835] border-dashed flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
           <div className="w-12 h-12 bg-black flex items-center justify-center shrink-0">
             <Clock size={24} className="text-[#8DB835]" />
           </div>
           <div>
             <h4 className="text-[11px] font-black uppercase tracking-widest text-black mb-1">{t.deliveryTimeTitle}</h4>
             <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{gl.estDeliveryTime}</p>
           </div>
        </div>

        {/* Banner CTA - Matches screenshot exactly */}
        <div className="bg-black text-white p-10 md:p-16 lg:p-20 mb-32 relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Subtle gradient/glow as seen in screenshot */}
          <div className="absolute right-0 bottom-0 w-[50%] h-[100%] bg-gradient-to-tl from-[#8DB835]/10 to-transparent pointer-events-none"></div>
          
          <div className="relative z-10 text-center lg:text-left flex flex-col gap-6">
            <h3 className="text-2xl md:text-4xl font-black uppercase tracking-tight leading-tight">
              {t.ctaTitlePart1} <br />
              <span className="text-[#8DB835]">{t.ctaTitlePart2}</span>
            </h3>
            <p className="text-zinc-500 font-bold uppercase tracking-[0.2em] text-[10px] md:text-xs">
              {t.ctaSub}
            </p>
          </div>

          <div className="relative z-10 flex flex-col gap-8 w-full lg:w-auto items-center lg:items-end">
            <button 
              onClick={() => onOpenAuth('signup', 'B2B')}
              className="w-full md:w-auto px-10 py-7 bg-[#8DB835] text-black text-[13px] font-black uppercase tracking-[0.15em] flex items-center justify-center gap-4 hover:bg-white transition-all active:scale-[0.98]"
            >
              <UserPlus size={18} /> {t.registerBtn}
            </button>
            <div className="flex items-center gap-3 text-[11px] font-black uppercase tracking-widest">
              <span className="text-white opacity-60">{t.alreadyPartner}</span> 
              <button 
                onClick={() => onOpenAuth('login')}
                className="text-[#8DB835] hover:underline transition-all"
              >
                {t.loginNow}
              </button>
            </div>
          </div>
        </div>

        {/* Requisites - Final block for trust */}
        <div className="max-w-4xl mx-auto border-t border-zinc-100 pt-20 flex flex-col items-center">
          <div className="flex items-center gap-4 mb-8">
            <ShieldCheck size={24} className="text-[#8DB835]" />
            <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-300">
              {t.requisitesTitle}
            </h4>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-8 md:gap-24">
            <div className="flex items-center gap-4">
              <Building2 size={18} className="text-zinc-300" />
              <span className="text-sm font-black uppercase tracking-widest text-zinc-800">{t.companyName}</span>
            </div>
            <div className="text-sm font-bold text-zinc-400 uppercase tracking-widest">
              {t.regNo}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PartnersPage;
