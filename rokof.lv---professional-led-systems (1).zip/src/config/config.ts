export const VAT_RATE = 0.21;
