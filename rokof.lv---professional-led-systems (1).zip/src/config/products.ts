import { Category, Product, Language } from '../../types';

const SOB_5_DESC: Record<Language, string> = {
  EN: "A professional next-generation LED-strip designed for continuous operation, offering luminous efficacy up to 125 lm/W. The SOB/SMD technology is an enhanced alternative to traditional COB strips – combining the uniform, seamless light line typical of COB with the higher durability and efficiency of SMD diodes. Features an ultra-short 1.25 cm cutting module and 3M 300 LSE adhesive.",
  LV: "Profesionāla jaunās paaudzes LED lente, kas paredzēta nepārtrauktai darbībai, piedāvājot gaismas atdevi līdz 125 lm/W. SOB/SMD tehnoloģija ir uzlabota alternatīva tradicionālajām COB lentēm – apvienojot COB raksturīgo vienmērīgo gaismu ar SMD diožu augstāku izturību un efektivitāti. Īpaši īss 1,25 cm griešanas modulis.",
  RU: "Профессиональная светодиодная лента нового поколения, разработанная для непрерывной работы, обеспечивающая светоотдачу до 125 лм/Вт. Технология SOB/SMD является улучшенной альтернативой традиционным COB лентам – сочетая равномерную световую линию с более высокой долговечностью SMD-диодов. Шаг резки 1,25 см."
};

const SOB_8_DESC: Record<Language, string> = {
  EN: "A professional next-generation LED-strip designed for continuous operation, offering luminous efficacy up to 135 lm/W. Features 48V input for ultra-long continuous runs without voltage drop. The SOB/SMD technology ensures uniform, seamless light. Ultra-short 2.5 cm cutting module and high CRI Ra92 for perfect color rendering.",
  LV: "Profesionāla jaunās paaudzes LED lente, kas paredzēta nepārtrauktai darbībai, piedāvājot gaismas atdevi līdz 135 lm/W. 48V ieeja īpaši gariem nepārtrauktiem posmiem bez sprieguma krituma. 2,5 cm griešanas modulis un augsts CRI Ra92.",
  RU: "Профессиональная светодиодная лента нового поколения, обеспечивающая светоотдачу до 135 лм/Вт. Питание 48В позволяет создавать сверхдлинные непрерывные линии без падения напряжения. Шаг резки 2,5 см и индекс цветопередачи CRI Ra92."
};

const COBH_4_DESC: Record<Language, string> = {
  EN: "A professional next-generation LED-strip featuring an impressive 640 chips per meter for maximum light uniformity. The increased number of LEDs results in significantly longer lifespan and higher efficiency. The advanced construction provides a perfectly seamless line of light – with no visible hotspots, even when dimmed. Features 2.5 cm cutting module and wide beam angle.",
  LV: "Profesionāla jaunās paaudzes LED lente ar iespaidīgiem 640 čipiem metrā maksimālai gaismas vienmērībai. Palielināts LED skaits nodроšina ilgāku kalpošanas laiku un augstāku efektivitāti. Nodrošina pilnīgi vienmērīgu gaismas līniju bez redzamiem punktiem. 2,5 cm griešanas modulis.",
  RU: "Профессиональная светодиодная лента нового поколения с впечатляющими 640 чипами на метр для максимальной равномерности света. Увеличенное количество светодиодов обеспечивает значительно более долгий срок службы. Идеально бесшовная линия света без видимых точек. Шаг резки 2,5 см."
};

const generateSOB5 = (sku: string, cct: string, ip: string, flux: string, width: string, price: number, avail: string, reel: string): Product => ({
  id: sku.toLowerCase(),
  sku,
  title: {
    LV: `LED lente SOB 320 • 12V • 5W • ${cct} • ${ip} • ${flux} • Ra92 • ${width}`,
    RU: `LED лента SOB 320 • 12V • 5W • ${cct} • ${ip} • ${flux} • Ra92 • ${width}`,
    EN: `LED strip SOB 320 • 12V • 5W • ${cct} • ${ip} • ${flux} • Ra92 • ${width}`
  },
  category: 'LED_STRIP',
  price: price,
  b2bPrice: Number((price * 0.8).toFixed(2)),
  unit: 'm',
  stockQuantity: parseFloat(avail) || 0,
  warrantyMonths: 36,
  images: ['https://www.fose.eu/products/photos/SOB-5/SOB-5.webp'],
  description: SOB_5_DESC,
  specifications: {
    dimmable: 'Yes (PWM)',
    powerPerMeter: 5,
    nodesPerMeter: '320',
    ipRating: ip,
    cuttingLength: '1.25 cm',
    voltage: '12V',
    voltageType: 'DC',
    colorTemperature: cct,
    cri: 'Ra92',
    energyClass: 'E',
    luminousFlux: flux,
    beamAngle: '160°',
    width: width,
    height: ip === 'IP20' ? '1.5 mm' : '4 mm',
    colorConsistency: 'SDCM < 3',
    operatingTemp: '-20°C ~ +45°C',
    warranty: '3',
    weightPerMeter: ip === 'IP20' ? 0.045 : 0.12,
    technology: 'SOB',
    length: parseInt(reel.replace('reel ', '').replace('m', ''))
  },
  createdAt: new Date()
});

const generateSOB8 = (sku: string, cct: string, ip: string, flux: string, width: string, price: number, avail: string, reel: string): Product => ({
  id: sku.toLowerCase(),
  sku,
  title: {
    LV: `LED lente SOB 320 • 48V • 8W • ${cct} • ${ip} • ${flux} • Ra92 • ${width}`,
    RU: `LED лента SOB 320 • 48V • 8W • ${cct} • ${ip} • ${flux} • Ra92 • ${width}`,
    EN: `LED strip SOB 320 • 48V • 8W • ${cct} • ${ip} • ${flux} • Ra92 • ${width}`
  },
  category: 'LED_STRIP',
  price: price,
  b2bPrice: Number((price * 0.8).toFixed(2)),
  unit: 'm',
  stockQuantity: parseFloat(avail) || 0,
  warrantyMonths: 36,
  images: ['https://www.fose.eu/products/photos/SOB-8-48/SOB-8-48.webp'],
  description: SOB_8_DESC,
  specifications: {
    dimmable: 'Yes (PWM)',
    powerPerMeter: 8,
    nodesPerMeter: '320',
    ipRating: ip,
    cuttingLength: '2.5 cm',
    voltage: '48V',
    voltageType: 'DC',
    colorTemperature: cct,
    cri: 'Ra92',
    energyClass: 'D',
    luminousFlux: flux,
    beamAngle: '160°',
    width: width,
    height: ip === 'IP20' ? '1.5 mm' : (ip === 'IP66' ? '4 mm' : '5 mm'),
    colorConsistency: 'SDCM < 3',
    operatingTemp: '-20°C ~ +45°C',
    warranty: '3',
    weightPerMeter: ip === 'IP20' ? 0.05 : (ip === 'IP66' ? 0.13 : 0.22),
    technology: 'SOB',
    length: parseInt(reel.replace('reel ', '').replace('m', ''))
  },
  createdAt: new Date()
});

const generateCOBH4 = (sku: string, cct: string, ip: string, flux: string, width: string, price: number, avail: string, reel: string): Product => ({
  id: sku.toLowerCase(),
  sku,
  title: {
    LV: `LED lente COB • 24V • 4W • ${cct} • ${ip} • ${flux} • Ra90 • ${width}`,
    RU: `LED лента COB • 24V • 4W • ${cct} • ${ip} • ${flux} • Ra90 • ${width}`,
    EN: `LED strip COB • 24V • 4W • ${cct} • ${ip} • ${flux} • Ra90 • ${width}`
  },
  category: 'LED_STRIP',
  price: price,
  b2bPrice: Number((price * 0.8).toFixed(2)),
  unit: 'm',
  stockQuantity: parseFloat(avail) || 0,
  warrantyMonths: 36,
  images: ['https://www.fose.eu/products/photos/COBH-4/COBH-4.webp'],
  description: COBH_4_DESC,
  specifications: {
    dimmable: 'Yes (PWM)',
    powerPerMeter: 4,
    nodesPerMeter: '640',
    ipRating: ip,
    cuttingLength: '2.5 cm',
    voltage: '24V',
    voltageType: 'DC',
    colorTemperature: cct,
    cri: 'Ra90',
    energyClass: 'E',
    luminousFlux: flux,
    beamAngle: '160°+',
    width: width,
    height: ip === 'IP20' ? '1.5 mm' : '4 mm',
    colorConsistency: 'SDCM < 3',
    operatingTemp: '-20°C ~ +45°C',
    warranty: '3',
    weightPerMeter: ip === 'IP20' ? 0.04 : 0.11,
    technology: 'COB',
    length: parseInt(reel.replace('reel ', '').replace('m', ''))
  },
  createdAt: new Date()
});

export const PRODUCTS: Product[] = [
  // SOB-5 Series (12V, 5W)
  generateSOB5('SOB-5-CW', '6500K', 'IP20', '650lm', '8mm', 5.32, '600', 'reel 30m'),
  generateSOB5('SOB-5-CW-66', '6500K', 'IP66', '650lm', '8.3mm', 6.68, '300', 'reel 10m'),
  generateSOB5('SOB-5-50', '5000K', 'IP20', '620lm', '8mm', 5.32, '570', 'reel 30m'),
  generateSOB5('SOB-5-50-66', '5000K', 'IP66', '620lm', '8.3mm', 6.68, '0', 'reel 10m'),
  generateSOB5('SOB-5-NW', '4000K', 'IP20', '590lm', '8mm', 5.32, '600', 'reel 30m'),
  generateSOB5('SOB-5-NW-66', '4000K', 'IP66', '590lm', '8.3mm', 6.68, '280', 'reel 10m'),
  generateSOB5('SOB-5-35', '3500K', 'IP20', '575lm', '8mm', 5.32, '375', 'reel 30m'),
  generateSOB5('SOB-5-35-66', '3500K', 'IP66', '575lm', '8.3mm', 6.68, '0', 'reel 10m'),
  generateSOB5('SOB-5-WW', '3000K', 'IP20', '565lm', '8mm', 5.32, '581', 'reel 30m'),
  generateSOB5('SOB-5-WW-66', '3000K', 'IP66', '565lm', '8.3mm', 6.68, '300', 'reel 10m'),
  generateSOB5('SOB-5-HW', '2700K', 'IP20', '540lm', '8mm', 5.32, '600', 'reel 30m'),
  generateSOB5('SOB-5-HW-66', '2700K', 'IP66', '540lm', '8.3mm', 6.68, '500', 'reel 10m'),

  // SOB-8 Series (48V, 8W)
  generateSOB8('SOB-8-CW-48', '6500K', 'IP20', '1160lm', '8mm', 6.00, '570', 'reel 30m'),
  generateSOB8('SOB-8-CW-66-48', '6500K', 'IP66', '1160lm', '8.3mm', 7.35, '450', 'reel 15m'),
  generateSOB8('SOB-8-CW-68-48', '6500K', 'IP68', '1160lm', '10mm', 8.13, '0', 'reel 20m'),
  generateSOB8('SOB-8-NW-48', '4000K', 'IP20', '1120lm', '8mm', 6.00, '480', 'reel 30m'),
  generateSOB8('SOB-8-NW-66-48', '4000K', 'IP66', '1120lm', '8.3mm', 7.35, '450', 'reel 15m'),
  generateSOB8('SOB-8-NW-68-48', '4000K', 'IP68', '1120lm', '10mm', 8.13, '0', 'reel 20m'),
  generateSOB8('SOB-8-WW-48', '3000K', 'IP20', '1080lm', '8mm', 6.00, '450', 'reel 30m'),
  generateSOB8('SOB-8-WW-66-48', '3000K', 'IP66', '1080lm', '8.3mm', 7.35, '439', 'reel 15m'),
  generateSOB8('SOB-8-WW-68-48', '3000K', 'IP68', '1080lm', '10mm', 8.13, '0', 'reel 20m'),
  generateSOB8('SOB-8-HW-48', '2700K', 'IP20', '1010lm', '8mm', 6.00, '600', 'reel 30m'),
  generateSOB8('SOB-8-HW-66-48', '2700K', 'IP66', '1010lm', '8.3mm', 7.35, '450', 'reel 15m'),
  generateSOB8('SOB-8-HW-68-48', '2700K', 'IP68', '1010lm', '10mm', 8.13, '0', 'reel 20m'),

  // COBH-4 Series (24V, 4W, 640 LEDs/m)
  generateCOBH4('COBH-4-CW-24-10M', '6000K', 'IP20', '460lm', '8mm', 4.84, '500', 'reel 10m'),
  generateCOBH4('COBH-4-CW-24-30M', '6000K', 'IP20', '460lm', '8mm', 4.84, '300', 'reel 30m'),
  generateCOBH4('COBH-4-CW-66-24-10M', '6000K', 'IP66', '460lm', '8.3mm', 6.20, '500', 'reel 10m'),
  generateCOBH4('COBH-4-NW-24-10M', '4000K', 'IP20', '440lm', '8mm', 4.84, '420', 'reel 10m'),
  generateCOBH4('COBH-4-NW-24-30M', '4000K', 'IP20', '440lm', '8mm', 4.84, '288', 'reel 30m'),
  generateCOBH4('COBH-4-NW-66-24-10M', '4000K', 'IP66', '440lm', '8.3mm', 6.20, '340', 'reel 10m'),
  generateCOBH4('COBH-4-WW-24-10M', '3000K', 'IP20', '410lm', '8mm', 4.84, '370', 'reel 10m'),
  generateCOBH4('COBH-4-WW-24-30M', '3000K', 'IP20', '410lm', '8mm', 4.84, '105', 'reel 30m'),
  generateCOBH4('COBH-4-WW-66-24-10M', '3000K', 'IP66', '410lm', '8.3mm', 6.20, '0', 'reel 10m'),
  generateCOBH4('COBH-4-HW-24-10M', '2700K', 'IP20', '380lm', '8mm', 4.84, '90', 'reel 10m'),
  generateCOBH4('COBH-4-HW-24-30M', '2700K', 'IP20', '380lm', '8mm', 4.84, '78', 'reel 30m'),
  generateCOBH4('COBH-4-HW-66-24-10M', '2700K', 'IP66', '380lm', '8.3mm', 6.20, '0', 'reel 10m'),
  generateCOBH4('COBH-4-22-24-10M', '2200K', 'IP20', '320lm', '8mm', 4.84, '500', 'reel 10m'),
  generateCOBH4('COBH-4-22-24-30M', '2200K', 'IP20', '320lm', '8mm', 4.84, '300', 'reel 30m'),
  generateCOBH4('COBH-4-22-66-24-10M', '2200K', 'IP66', '320lm', '8.3mm', 6.20, '400', 'reel 10m')
];
