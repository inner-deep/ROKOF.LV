
import { User, CartItem } from '../../types';
import { VAT_RATE } from '../../constants';

export const getPersonalizedPrice = (price: number, b2bPrice: number, currentUser: User | null) => {
  if (!currentUser) return price;
  
  // 1. Manual Discount (Overrides everything)
  if (currentUser.discountLevel > 0) {
    return price * (1 - currentUser.discountLevel / 100);
  }

  // 2. Business Price (Default for B2B)
  if (currentUser.type === 'BUSINESS') {
    return b2bPrice;
  }

  // 3. Retail Price (Default for B2C)
  return price;
};

export const calculateVolumeDiscountRate = (totalMeters: number, currentUser: User | null) => {
  if (currentUser?.type === 'BUSINESS') return 0;
  if (totalMeters >= 100) return 10;
  if (totalMeters >= 50) return 5;
  return 0;
};

export const calculateTotals = (cart: CartItem[], currentUser: User | null) => {
  const totalMeters = cart.reduce((acc, item) => acc + item.quantity, 0);
  const volumeDiscountRate = calculateVolumeDiscountRate(totalMeters, currentUser);

  const rawSubtotalNet = cart.reduce((sum, item) => {
    const price = getPersonalizedPrice(item.price, item.b2bPrice, currentUser);
    return sum + (price * item.quantity);
  }, 0);

  const volumeDiscountValueNet = rawSubtotalNet * (volumeDiscountRate / 100);
  const subtotalNet = rawSubtotalNet - volumeDiscountValueNet;
  
  const vatValue = subtotalNet * VAT_RATE;
  const totalGross = subtotalNet + vatValue;

  return {
    totalMeters,
    volumeDiscountRate,
    rawSubtotalNet,
    volumeDiscountValueNet,
    subtotalNet,
    vatValue,
    totalGross
  };
};
