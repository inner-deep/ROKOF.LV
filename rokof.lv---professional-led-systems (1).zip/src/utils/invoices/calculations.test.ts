import { describe, it, expect } from 'vitest';
import { calcTotals } from './calculations';
import { InvoiceLine } from './types';

describe('calcTotals', () => {
  it('should calculate totals correctly for a single line item', () => {
    const lines: InvoiceLine[] = [
      { id: '1', pos: 1, sku: 'SKU1', unit: 'pcs', description: 'Item 1', quantity: 2, unitPrice: 10, lineTotal: 20 }
    ];
    const vatRate = 21;
    const result = calcTotals(lines, vatRate);

    expect(result.subtotal).toBe(20);
    expect(result.vat).toBe(4.2); // 20 * 0.21
    expect(result.total).toBe(24.2);
    expect(result.due).toBe(24.2);
  });

  it('should calculate totals correctly for multiple line items', () => {
    const lines: InvoiceLine[] = [
      { id: '1', pos: 1, sku: 'SKU1', unit: 'pcs', description: 'Item 1', quantity: 2, unitPrice: 10, lineTotal: 20 },
      { id: '2', pos: 2, sku: 'SKU2', unit: 'pcs', description: 'Item 2', quantity: 1, unitPrice: 50, lineTotal: 50 }
    ];
    const vatRate = 21;
    const result = calcTotals(lines, vatRate);

    expect(result.subtotal).toBe(70);
    expect(result.vat).toBe(14.7); // 70 * 0.21
    expect(result.total).toBe(84.7);
    expect(result.due).toBe(84.7);
  });

  it('should handle zero quantity or price', () => {
    const lines: InvoiceLine[] = [
      { id: '1', pos: 1, sku: 'SKU1', unit: 'pcs', description: 'Item 1', quantity: 0, unitPrice: 10, lineTotal: 0 },
      { id: '2', pos: 2, sku: 'SKU2', unit: 'pcs', description: 'Item 2', quantity: 5, unitPrice: 0, lineTotal: 0 }
    ];
    const vatRate = 21;
    const result = calcTotals(lines, vatRate);

    expect(result.subtotal).toBe(0);
    expect(result.vat).toBe(0);
    expect(result.total).toBe(0);
    expect(result.due).toBe(0);
  });

  it('should handle floating point numbers correctly', () => {
    const lines: InvoiceLine[] = [
      { id: '1', pos: 1, sku: 'SKU1', unit: 'pcs', description: 'Item 1', quantity: 3, unitPrice: 3.33, lineTotal: 9.99 }
    ];
    const vatRate = 21;
    const result = calcTotals(lines, vatRate);

    // 3 * 3.33 = 9.99
    // VAT = 9.99 * 0.21 = 2.0979 -> 2.10 (rounded half up)
    // Total = 9.99 + 2.10 = 12.09
    
    expect(result.subtotal).toBe(9.99);
    expect(result.vat).toBe(2.10);
    expect(result.total).toBe(12.09);
    expect(result.due).toBe(12.09);
  });

  it('should subtract prepaid amount from due amount', () => {
    const lines: InvoiceLine[] = [
      { id: '1', pos: 1, sku: 'SKU1', unit: 'pcs', description: 'Item 1', quantity: 1, unitPrice: 100, lineTotal: 100 }
    ];
    const vatRate = 21;
    const prepaidAmount = 50;
    const result = calcTotals(lines, vatRate, prepaidAmount);

    expect(result.subtotal).toBe(100);
    expect(result.vat).toBe(21);
    expect(result.total).toBe(121);
    expect(result.due).toBe(71); // 121 - 50
  });

  it('should handle prepaid amount greater than total', () => {
    const lines: InvoiceLine[] = [
      { id: '1', pos: 1, sku: 'SKU1', unit: 'pcs', description: 'Item 1', quantity: 1, unitPrice: 100, lineTotal: 100 }
    ];
    const vatRate = 21;
    const prepaidAmount = 150;
    const result = calcTotals(lines, vatRate, prepaidAmount);

    expect(result.total).toBe(121);
    expect(result.due).toBe(-29); // 121 - 150
  });
});
