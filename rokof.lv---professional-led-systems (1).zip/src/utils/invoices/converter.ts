import { Invoice } from './types';

export function convertToInvoice(prepaymentInvoice: Invoice, newDocumentNumber: string): Invoice {
  return {
    ...prepaymentInvoice,
    uuid: crypto.randomUUID(),
    documentNumber: newDocumentNumber,
    documentType: 'invoice',
    status: 'draft',
    isSent: false,
    sentAt: undefined,
    sentToEmail: undefined,
    paidAmount: prepaymentInvoice.totalWithVat,
    remainingAmount: 0,
    prepaymentUuid: prepaymentInvoice.uuid,
    createdAt: new Date(),
    updatedAt: new Date()
  };
}
