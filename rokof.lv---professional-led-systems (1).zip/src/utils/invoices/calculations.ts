import { InvoiceLine } from './types';

export const calcTotals = (lines: InvoiceLine[], vatRate: number, prepaidAmount: number = 0) => {
  const subtotal = Number(lines.reduce((sum, line) => sum + line.lineTotal, 0).toFixed(2));
  const vat = Number((subtotal * (vatRate / 100)).toFixed(2));
  const total = Number((subtotal + vat).toFixed(2));
  const due = Number((total - prepaidAmount).toFixed(2));

  return {
    subtotal,
    vat,
    total,
    due
  };
};
