import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { convertToInvoice } from './converter';
import { Invoice } from './types';

describe('convertToInvoice', () => {
  beforeEach(() => {
    // Mock crypto.randomUUID
    if (!global.crypto) {
      Object.defineProperty(global, 'crypto', {
        value: {
          randomUUID: vi.fn().mockReturnValue('mock-uuid')
        },
        writable: true
      });
    } else {
      vi.spyOn(global.crypto, 'randomUUID').mockReturnValue('mock-uuid' as any);
    }
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should convert a prepayment invoice to a regular invoice correctly', () => {
    const prepaymentInvoice: Invoice = {
      uuid: 'prepay-uuid',
      documentNumber: 'PR-123',
      documentType: 'prepayment',
      status: 'sent',
      issueDate: '01.01.2023',
      payDeadline: '08.01.2023',
      shipDate: '',
      issuePlace: 'Riga',
      receivePlace: 'Riga',
      vatRate: 21,
      seller: {
        id: 'seller-id',
        name: 'Seller',
        regNo: '123',
        vatNo: 'LV123',
        address: 'Address',
        bankName: 'Bank',
        swift: 'SWIFT',
        iban: 'Account',
        email: 'seller@example.com',
        phone: '12345678',
        signatoryName: 'Signatory'
      },
      buyer: {
        id: 'buyer-id',
        name: 'Buyer',
        regNo: '456',
        vatNo: 'LV456',
        address: 'Buyer Address',
        bankName: '',
        swift: '',
        iban: '',
        email: 'buyer@example.com',
        phone: '87654321',
        signatoryName: ''
      },
      lines: [],
      totalWithoutVat: 100,
      vatAmount: 21,
      totalWithVat: 121,
      paidAmount: 0,
      remainingAmount: 121,
      isSent: true,
      sentAt: new Date('2023-01-02'),
      sentToEmail: 'buyer@example.com',
      createdAt: new Date('2023-01-01'),
      updatedAt: new Date('2023-01-01'),
      notes: ''
    };

    const newNumber = 'INV-001';
    const result = convertToInvoice(prepaymentInvoice, newNumber);

    expect(result.documentType).toBe('invoice');
    expect(result.documentNumber).toBe(newNumber);
    expect(result.uuid).toBe('mock-uuid');
    expect(result.prepaymentUuid).toBe('prepay-uuid');
    expect(result.status).toBe('draft');
    expect(result.isSent).toBe(false);
    expect(result.sentAt).toBeUndefined();
    expect(result.sentToEmail).toBeUndefined();
    expect(result.paidAmount).toBe(121); // Should be fully paid by prepayment
    expect(result.remainingAmount).toBe(0);
  });
});
