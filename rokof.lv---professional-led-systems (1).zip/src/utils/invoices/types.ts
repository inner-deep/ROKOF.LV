export interface InvoiceLine {
  id: string;
  pos: number;
  description: string;
  sku: string | null;
  unit: string | null;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
}

export interface Company {
  id: string;
  customerType?: 'b2b' | 'b2c';
  name: string;
  firstName?: string;
  lastName?: string;
  regNo: string;
  vatNo: string;
  address: string;
  bankName: string;
  swift: string;
  iban: string;
  email: string;
  phone: string;
  signatoryName: string;
}

export type DocumentType = 'invoice' | 'prepayment';

export interface Invoice {
  uuid: string;
  documentNumber: string;
  documentType: DocumentType;
  status: string;
  issueDate: string;
  payDeadline: string;
  lines: InvoiceLine[];
  vatRate: number;
  totalWithoutVat: number;
  vatAmount: number;
  totalWithVat: number;
  paidAmount: number;
  remainingAmount: number;
  seller: Company;
  buyer: Company;
  notes?: string;
  createdAt?: string | Date;
  updatedAt?: string | Date;
  isSent?: boolean;
  shipDate?: string;
  issuePlace?: string;
  receivePlace?: string;
  sentAt?: string | Date;
  sentToEmail?: string;
  prepaymentUuid?: string;
  orderId?: string;
  orderNumber?: string;
  sendCount?: number;
  _converted?: boolean;
}

export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';

export interface InvoiceTotals {
  subtotal: number;
  vat: number;
  total: number;
  due: number;
}
