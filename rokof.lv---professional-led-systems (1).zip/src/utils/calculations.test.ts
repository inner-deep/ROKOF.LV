import { describe, it, expect, vi } from 'vitest';
import { getPersonalizedPrice, calculateVolumeDiscountRate, calculateTotals } from './calculations';
import { User, CartItem } from '../../types';
import { VAT_RATE } from '../../constants';

describe('src/utils/calculations', () => {
  const mockUserIndividual: User = {
    id: '1',
    email: 'test@test.com',
    role: 'CUSTOMER',
    type: 'INDIVIDUAL',
    tier: 'BRONZE',
    firstName: 'Test',
    lastName: 'User',
    phone: '123',
    createdAt: new Date(),
    discountLevel: 0
  };

  const mockUserBusiness: User = {
    ...mockUserIndividual,
    type: 'BUSINESS',
    discountLevel: 0
  };

  const mockUserDiscount: User = {
    ...mockUserIndividual,
    discountLevel: 10 // 10% discount
  };

  describe('getPersonalizedPrice', () => {
    it('should return regular price for individual user without discount', () => {
      const price = 100;
      const b2bPrice = 80;
      expect(getPersonalizedPrice(price, b2bPrice, mockUserIndividual)).toBe(100);
    });

    it('should return regular price for null user', () => {
      const price = 100;
      const b2bPrice = 80;
      expect(getPersonalizedPrice(price, b2bPrice, null)).toBe(100);
    });

    it('should return B2B price for business user', () => {
      const price = 100;
      const b2bPrice = 80;
      expect(getPersonalizedPrice(price, b2bPrice, mockUserBusiness)).toBe(80);
    });

    it('should return discounted price if user has manual discount', () => {
      const price = 100;
      const b2bPrice = 80;
      // 10% off 100 = 90
      expect(getPersonalizedPrice(price, b2bPrice, mockUserDiscount)).toBe(90);
    });

    it('should prioritize manual discount over business price', () => {
      const userWithBoth: User = {
        ...mockUserBusiness,
        discountLevel: 50 // 50% off
      };
      const price = 100;
      const b2bPrice = 80;
      // 50% off 100 = 50. (Logic says if discountLevel > 0, use it on base price)
      // Let's verify logic in calculations.ts:
      // if (currentUser.discountLevel > 0) { return price * (1 - currentUser.discountLevel / 100); }
      expect(getPersonalizedPrice(price, b2bPrice, userWithBoth)).toBe(50);
    });
  });

  describe('calculateVolumeDiscountRate', () => {
    it('should return 0 for business users regardless of volume', () => {
      expect(calculateVolumeDiscountRate(1000, mockUserBusiness)).toBe(0);
    });

    it('should return 0 for low volume individual', () => {
      expect(calculateVolumeDiscountRate(49, mockUserIndividual)).toBe(0);
    });

    it('should return 5 for volume >= 50 and < 100', () => {
      expect(calculateVolumeDiscountRate(50, mockUserIndividual)).toBe(5);
      expect(calculateVolumeDiscountRate(99, mockUserIndividual)).toBe(5);
    });

    it('should return 10 for volume >= 100', () => {
      expect(calculateVolumeDiscountRate(100, mockUserIndividual)).toBe(10);
      expect(calculateVolumeDiscountRate(150, mockUserIndividual)).toBe(10);
    });
  });

  describe('calculateTotals', () => {
    const mockCartItem: CartItem = {
      id: 'p1',
      sku: 'SKU1',
      title: { LV: 'P1', RU: 'P1', EN: 'P1' },
      description: { LV: '', RU: '', EN: '' },
      category: 'LED_STRIP',
      price: 10,
      b2bPrice: 8,
      unit: 'm',
      stockQuantity: 1000,
      warrantyMonths: 24,
      images: [],
      specifications: {},
      createdAt: new Date(),
      quantity: 10
    };

    it('should calculate totals correctly for individual user (no volume discount)', () => {
      const cart = [mockCartItem]; // 10 items * 10 eur = 100 eur
      const totals = calculateTotals(cart, mockUserIndividual);

      expect(totals.totalMeters).toBe(10);
      expect(totals.volumeDiscountRate).toBe(0);
      expect(totals.rawSubtotalNet).toBe(100);
      expect(totals.volumeDiscountValueNet).toBe(0);
      expect(totals.subtotalNet).toBe(100);
      expect(totals.vatValue).toBe(100 * VAT_RATE);
      expect(totals.totalGross).toBe(100 * (1 + VAT_RATE));
    });

    it('should calculate totals correctly for business user', () => {
      const cart = [mockCartItem]; // 10 items * 8 eur (B2B) = 80 eur
      const totals = calculateTotals(cart, mockUserBusiness);

      expect(totals.totalMeters).toBe(10);
      expect(totals.volumeDiscountRate).toBe(0); // Business gets no volume discount
      expect(totals.rawSubtotalNet).toBe(80);
      expect(totals.volumeDiscountValueNet).toBe(0);
      expect(totals.subtotalNet).toBe(80);
      expect(totals.vatValue).toBe(80 * VAT_RATE);
      expect(totals.totalGross).toBe(80 * (1 + VAT_RATE));
    });

    it('should apply volume discount for individual user', () => {
      const cart = [{ ...mockCartItem, quantity: 50 }]; // 50 items * 10 eur = 500 eur
      const totals = calculateTotals(cart, mockUserIndividual);

      expect(totals.totalMeters).toBe(50);
      expect(totals.volumeDiscountRate).toBe(5); // 5% discount
      expect(totals.rawSubtotalNet).toBe(500);
      expect(totals.volumeDiscountValueNet).toBe(500 * 0.05); // 25
      expect(totals.subtotalNet).toBe(475); // 500 - 25
      expect(totals.vatValue).toBe(475 * VAT_RATE);
      expect(totals.totalGross).toBe(475 + (475 * VAT_RATE));
    });
  });
});
