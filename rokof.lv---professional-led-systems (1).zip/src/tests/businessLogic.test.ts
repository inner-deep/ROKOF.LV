
import { describe, it, expect } from 'vitest';
import { calculateTotals, getPersonalizedPrice, calculateVolumeDiscountRate } from '../utils/calculations';
import { User, CartItem, Category } from '../../types';

const mockProduct: any = {
  id: 'test-product',
  sku: 'TEST-SKU',
  price: 10.00,
  b2bPrice: 8.00,
  category: Category.STRIPS,
  specifications: {}
};

describe('Business Logic - Pricing and Discounts', () => {
  
  describe('getPersonalizedPrice', () => {
    it('should return retail price for B2C users', () => {
      const user = { type: 'INDIVIDUAL', discountLevel: 0 } as unknown as User;
      expect(getPersonalizedPrice(10, 8, user)).toBe(10);
    });

    it('should return B2B price for B2B users with no extra discount', () => {
      const user = { type: 'BUSINESS', discountLevel: 0 } as unknown as User;
      expect(getPersonalizedPrice(10, 8, user)).toBe(8);
    });

    it('should apply custom discount level for B2B users', () => {
      const user = { type: 'BUSINESS', discountLevel: 25 } as unknown as User;
      expect(getPersonalizedPrice(10, 8, user)).toBe(7.5); // 10 * 0.75
    });
  });

  describe('calculateVolumeDiscountRate', () => {
    it('should return 0% for B2B users regardless of volume', () => {
      const user = { type: 'BUSINESS' } as unknown as User;
      expect(calculateVolumeDiscountRate(150, user)).toBe(0);
    });

    it('should return 0% for B2C users with < 50m', () => {
      const user = { type: 'INDIVIDUAL' } as unknown as User;
      expect(calculateVolumeDiscountRate(49, user)).toBe(0);
    });

    it('should return 5% for B2C users with >= 50m and < 100m', () => {
      const user = { type: 'INDIVIDUAL' } as unknown as User;
      expect(calculateVolumeDiscountRate(50, user)).toBe(5);
      expect(calculateVolumeDiscountRate(99, user)).toBe(5);
    });

    it('should return 10% for B2C users with >= 100m', () => {
      const user = { type: 'INDIVIDUAL' } as unknown as User;
      expect(calculateVolumeDiscountRate(100, user)).toBe(10);
      expect(calculateVolumeDiscountRate(1000, user)).toBe(10);
    });
  });

  describe('calculateTotals', () => {
    it('should calculate VAT (21%) correctly', () => {
      const cart: CartItem[] = [{ ...mockProduct, quantity: 10 }];
      const user = { type: 'INDIVIDUAL' } as unknown as User;
      const totals = calculateTotals(cart, user);
      
      // 10 items * 10.00 = 100.00
      // No volume discount (10 < 50)
      // Subtotal = 100.00
      // VAT = 21.00
      // Total = 121.00
      expect(totals.subtotalNet).toBe(100);
      expect(totals.vatValue).toBe(21);
      expect(totals.totalGross).toBe(121);
    });

    it('should apply B2C volume discount and then calculate VAT', () => {
      const cart: CartItem[] = [{ ...mockProduct, quantity: 100 }];
      const user = { type: 'INDIVIDUAL' } as unknown as User;
      const totals = calculateTotals(cart, user);
      
      // 100 items * 10.00 = 1000.00
      // Volume discount = 10% = 100.00
      // Subtotal Net = 900.00
      // VAT = 900 * 0.21 = 189.00
      // Total Gross = 1089.00
      expect(totals.volumeDiscountRate).toBe(10);
      expect(totals.subtotalNet).toBe(900);
      expect(totals.vatValue).toBe(189);
      expect(totals.totalGross).toBe(1089);
    });
  });
});
