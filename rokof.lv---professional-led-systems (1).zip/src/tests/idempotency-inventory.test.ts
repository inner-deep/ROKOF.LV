import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import { PrismaClient } from '@prisma/client';

const { RedisMock, instances } = vi.hoisted(() => {
  const RedisMock = require('ioredis-mock');
  const instances: any[] = [];
  return { RedisMock, instances };
});

vi.mock('ioredis', () => {
  return {
    default: class {
      constructor() {
        const instance = new RedisMock();
        instance.config = async () => 'OK';
        instances.push(instance);
        return instance;
      }
    }
  };
});

import '../../server'; // Import to start the subscriber

const prisma = new PrismaClient();
const redis = new RedisMock();
redis.config = async () => 'OK';

describe('Race Conditions & Idempotency', () => {
  let testOrderId: string;
  let testProductId: string;
  let testUserId = 'test-user-id';

  beforeAll(async () => {
    // Setup test product
    const product = await prisma.product.create({
      data: {
        sku: 'TEST-SKU-1',
        titleLV: 'Test Product',
        titleRU: 'Test Product',
        titleEN: 'Test Product',
        price: 100,
        b2bPrice: 90,
        stockQuantity: 10
      }
    });
    testProductId = product.id;

    // Setup test order
    const order = await prisma.order.create({
      data: {
        invoiceNumber: 'ROK/TEST-WEBHOOK',
        subtotal: 100,
        vatAmount: 21,
        totalAmount: 121,
        status: 'NEW',
        deliveryAddress: 'Test Address',
        customerInfo: JSON.stringify({ email: 'test@example.com' })
      }
    });
    testOrderId = order.id;
  });

  afterAll(async () => {
    // Cleanup
    await prisma.processedWebhook.deleteMany({});
    await prisma.orderItem.deleteMany({ where: { orderId: testOrderId } });
    await prisma.order.delete({ where: { id: testOrderId } });
    await prisma.cartItem.deleteMany({ where: { productId: testProductId } });
    await prisma.product.delete({ where: { id: testProductId } });
    await prisma.$disconnect();
    redis.disconnect();
  });

  it('Stripe Webhook Idempotency: should ignore duplicate webhooks sent in parallel', async () => {
    const payload = {
      id: 'evt_test_123',
      type: 'payment_intent.succeeded',
      data: {
        object: {
          id: 'pi_test_123',
          amount: 12100,
          metadata: { orderId: testOrderId }
        }
      }
    };

    const processWebhook = async () => {
      try {
        await prisma.processedWebhook.create({
          data: { eventId: payload.id }
        });
        
        // Simulate processing
        await prisma.order.updateMany({
          where: { id: testOrderId, status: 'NEW' },
          data: { status: 'PAID' }
        });
        return 'PROCESSED';
      } catch (err: any) {
        if (err.code === 'P2002') {
          return 'SKIPPED';
        }
        throw err;
      }
    };

    // Send two requests in parallel
    const results = await Promise.all([
      processWebhook(),
      processWebhook()
    ]);

    // One should be PROCESSED, one should be SKIPPED
    expect(results).toContain('PROCESSED');
    expect(results).toContain('SKIPPED');

    // Order should be PAID
    const order = await prisma.order.findUnique({ where: { id: testOrderId } });
    expect(order?.status).toBe('PAID');
    
    // ProcessedWebhook should have exactly one entry for this event
    const count = await prisma.processedWebhook.count({ where: { eventId: payload.id } });
    expect(count).toBe(1);
  });

  it('Inventory Locks: should restore stock after TTL expires', async () => {
    // 1. Initial stock is 10
    const initialProduct = await prisma.product.findUnique({ where: { id: testProductId } });
    expect(initialProduct?.stockQuantity).toBe(10);

    // 2. Simulate adding to cart (reserving 2 items)
    // We'll manually do what the endpoint does to avoid auth issues in test
    await prisma.product.update({
      where: { id: testProductId },
      data: { stockQuantity: { decrement: 2 } }
    });
    
    // Set TTL to 1 second for testing instead of 15 minutes
    await redis.setex(`reservation:${testUserId}:${testProductId}:2`, 1, "reserved");

    // 3. Verify stock is decremented
    const reservedProduct = await prisma.product.findUnique({ where: { id: testProductId } });
    expect(reservedProduct?.stockQuantity).toBe(8);

    // 4. Wait for TTL to expire (1.5 seconds)
    // Since we are using ioredis-mock, keyspace notifications don't fire automatically.
    // We manually emit the message on the subscriber instance.
    for (const instance of instances) {
      instance.emit('message', '__keyevent@0__:expired', `reservation:${testUserId}:${testProductId}:2`);
    }

    await new Promise(resolve => setTimeout(resolve, 500)); // Wait for processing

    // 5. Verify stock is restored by the keyspace notification subscriber
    const restoredProduct = await prisma.product.findUnique({ where: { id: testProductId } });
    expect(restoredProduct?.stockQuantity).toBe(10);
  });
});
