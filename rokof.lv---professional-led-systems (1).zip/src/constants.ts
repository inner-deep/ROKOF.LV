export { TRANSLATIONS } from './i18n/translations';
export { VAT_RATE } from './config/config';
