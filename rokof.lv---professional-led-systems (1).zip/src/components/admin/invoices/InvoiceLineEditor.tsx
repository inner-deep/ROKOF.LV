import React, { useState, useEffect } from 'react';
import { InvoiceLine } from '../../../utils/invoices/types';
import { Trash2, Plus } from 'lucide-react';
import Decimal from 'decimal.js';

interface Props {
  lines: InvoiceLine[];
  onChange: (lines: InvoiceLine[]) => void;
  isLocked?: boolean;
}

export default function InvoiceLineEditor({ lines, onChange, isLocked = false }: Props) {
  const addLine = () => {
    const newLine: InvoiceLine = {
      id: crypto.randomUUID(),
      pos: lines.length + 1,
      description: '',
      sku: '',
      unit: 'gab.',
      quantity: 1,
      unitPrice: 0,
      lineTotal: 0
    };
    onChange([...lines, newLine]);
  };

  const updateLine = (index: number, field: keyof InvoiceLine, value: any) => {
    const newLines = [...lines];
    const line = { ...newLines[index], [field]: value };
    
    // Recalculate total
    if (field === 'quantity' || field === 'unitPrice') {
      line.lineTotal = new Decimal(line.quantity).times(line.unitPrice).toDecimalPlaces(2).toNumber();
    }
    
    newLines[index] = line;
    onChange(newLines);
  };

  const removeLine = (index: number) => {
    onChange(lines.filter((_, i) => i !== index));
  };

  return (
    <div className="w-full overflow-x-auto">
      <table className="min-w-full divide-y divide-zinc-200">
        <thead className="bg-zinc-50">
          <tr>
            <th className="px-6 py-4 text-left text-[9px] font-black text-zinc-400 uppercase tracking-widest">Apraksts</th>
            <th className="px-4 py-4 text-left text-[9px] font-black text-zinc-400 uppercase tracking-widest w-32">SKU</th>
            <th className="px-4 py-4 text-left text-[9px] font-black text-zinc-400 uppercase tracking-widest w-24">Mērv.</th>
            <th className="px-4 py-4 text-right text-[9px] font-black text-zinc-400 uppercase tracking-widest w-28">Daudz.</th>
            <th className="px-4 py-4 text-right text-[9px] font-black text-zinc-400 uppercase tracking-widest w-36">Cena (€)</th>
            <th className="px-6 py-4 text-right text-[9px] font-black text-zinc-400 uppercase tracking-widest w-36">Summa</th>
            <th className="w-14 px-4 py-4"></th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-zinc-100">
          {lines.map((line, index) => (
            <tr key={line.id || `line-${index}`} className="hover:bg-zinc-50 transition-colors group">
              <td className="px-4 py-2">
                <input
                  type="text"
                  value={line.description}
                  onChange={isLocked ? undefined : (e) => updateLine(index, 'description', e.target.value)}
                  readOnly={isLocked}
                  placeholder="Preces vai pakalpojuma nosaukums"
                  className={`w-full bg-transparent border border-transparent px-3 py-2 text-xs font-bold transition-all outline-none ${isLocked ? 'cursor-not-allowed text-zinc-500' : 'hover:border-zinc-200 focus:border-black focus:bg-white'}`}
                />
              </td>
              <td className="px-2 py-2">
                <input
                  type="text"
                  value={line.sku}
                  onChange={isLocked ? undefined : (e) => updateLine(index, 'sku', e.target.value)}
                  readOnly={isLocked}
                  placeholder="Kods"
                  className={`w-full bg-transparent border border-transparent px-3 py-2 text-xs font-bold transition-all outline-none font-mono ${isLocked ? 'cursor-not-allowed text-zinc-500' : 'hover:border-zinc-200 focus:border-black focus:bg-white'}`}
                />
              </td>
              <td className="px-2 py-2">
                <input
                  type="text"
                  value={line.unit}
                  onChange={isLocked ? undefined : (e) => updateLine(index, 'unit', e.target.value)}
                  readOnly={isLocked}
                  className={`w-full bg-transparent border border-transparent px-3 py-2 text-xs font-bold transition-all outline-none text-center ${isLocked ? 'cursor-not-allowed text-zinc-500' : 'hover:border-zinc-200 focus:border-black focus:bg-white'}`}
                />
              </td>
              <td className="px-2 py-2">
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={line.quantity}
                  onChange={isLocked ? undefined : (e) => updateLine(index, 'quantity', parseFloat(e.target.value) || 0)}
                  readOnly={isLocked}
                  className={`w-full bg-transparent border border-transparent px-3 py-2 text-xs font-bold transition-all outline-none text-right font-mono ${isLocked ? 'cursor-not-allowed text-zinc-500' : 'hover:border-zinc-200 focus:border-black focus:bg-white'}`}
                />
              </td>
              <td className="px-2 py-2">
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={line.unitPrice}
                  onChange={isLocked ? undefined : (e) => updateLine(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                  readOnly={isLocked}
                  className={`w-full bg-transparent border border-transparent px-3 py-2 text-xs font-bold transition-all outline-none text-right font-mono ${isLocked ? 'cursor-not-allowed text-zinc-500' : 'hover:border-zinc-200 focus:border-black focus:bg-white'}`}
                />
              </td>
              <td className="px-6 py-2 text-right font-mono font-bold text-xs text-zinc-900">
                €{line.lineTotal.toFixed(2)}
              </td>
              <td className="px-4 py-2 text-center">
                {!isLocked && (
                  <button 
                    onClick={() => removeLine(index)} 
                    className="text-zinc-400 hover:text-rose-600 opacity-0 group-hover:opacity-100 transition-all p-1.5 hover:bg-rose-50"
                    title="Dzēst rindu"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </td>
            </tr>
          ))}
          {lines.length === 0 && (
            <tr>
              <td colSpan={7} className="px-6 py-12 text-center text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                Nav pievienota neviena pozīcija.
              </td>
            </tr>
          )}
        </tbody>
      </table>
      <div className="p-4 border-t border-zinc-100 bg-zinc-50">
        {!isLocked ? (
          <button
            type="button"
            onClick={addLine}
            className="flex items-center gap-2 text-[10px] font-black text-zinc-500 hover:text-black uppercase tracking-widest transition-colors"
          >
            <Plus size={14} /> Pievienot jaunu rindu
          </button>
        ) : (
          <div className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">
            Rēķins ir saglabāts un nav rediģējams
          </div>
        )}
      </div>
    </div>
  );
}
