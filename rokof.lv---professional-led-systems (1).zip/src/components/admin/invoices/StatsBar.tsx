import React from 'react';
import { InvoiceTotals } from '../../../utils/invoices/types';

interface Props {
  totals: InvoiceTotals;
  vatRate: number;
}

export default function StatsBar({ totals, vatRate }: Props) {
  return (
    <div className="bg-zinc-50 border border-zinc-200 p-5 space-y-3 text-xs font-bold font-mono">
      <div className="flex justify-between items-center text-zinc-500 uppercase tracking-widest text-[9px]">
        <span>Summa bez PVN</span>
        <span className="text-zinc-900 text-xs">€{totals.subtotal.toFixed(2)}</span>
      </div>
      <div className="flex justify-between items-center text-zinc-500 uppercase tracking-widest text-[9px]">
        <span>PVN ({vatRate}%)</span>
        <span className="text-zinc-900 text-xs">€{totals.vat.toFixed(2)}</span>
      </div>
      
      <div className="h-px bg-zinc-200 my-3"></div>
      
      <div className="flex justify-between items-center text-base">
        <span className="font-black text-zinc-900 font-sans uppercase tracking-widest text-[11px]">Kopā apmaksai</span>
        <span className="font-black text-[#8DB835] text-lg">€{totals.total.toFixed(2)}</span>
      </div>
      
      {totals.due !== totals.total && (
        <div className="flex justify-between items-center text-base mt-2 bg-rose-50 p-3 -mx-2 border border-rose-200">
          <span className="font-black text-rose-700 font-sans uppercase tracking-widest text-[10px]">Atlicis apmaksāt</span>
          <span className="font-black text-rose-700 text-lg">€{totals.due.toFixed(2)}</span>
        </div>
      )}
    </div>
  );
}
