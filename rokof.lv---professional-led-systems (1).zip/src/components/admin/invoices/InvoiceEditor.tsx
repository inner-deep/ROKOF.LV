import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Invoice, InvoiceLine, Company, DocumentType } from '../../../utils/invoices/types';
import { calcTotals } from '../../../utils/invoices/calculations';
import InvoiceLineEditor from './InvoiceLineEditor';
import StatsBar from './StatsBar';
import { Save, ArrowLeft, FileText, Send } from 'lucide-react';

const emptyCompany: Company = {
  id: '',
  customerType: 'b2b',
  name: '',
  firstName: '',
  lastName: '',
  regNo: '',
  vatNo: '',
  address: '',
  bankName: '',
  swift: '',
  iban: '',
  email: '',
  phone: '',
  signatoryName: ''
};

const today = new Date();
const nextWeek = new Date(today);
nextWeek.setDate(today.getDate() + 7);

const emptyInvoice: Invoice = {
  uuid: '',
  documentNumber: '', // Will be generated
  documentType: 'invoice',
  status: 'draft',
  issueDate: today.toISOString().split('T')[0],
  payDeadline: nextWeek.toISOString().split('T')[0],
  shipDate: '',
  issuePlace: 'Rīga',
  receivePlace: '',
  vatRate: 21,
  seller: { ...emptyCompany, name: 'SIA ROKOF', regNo: '40203287104', address: 'Pūces iela 11/1-7, Rīga, LV-1082' }, // Default seller
  buyer: { ...emptyCompany },
  lines: [],
  totalWithoutVat: 0,
  vatAmount: 0,
  totalWithVat: 0,
  paidAmount: 0,
  remainingAmount: 0,
  isSent: false,
  createdAt: new Date(),
  updatedAt: new Date(),
  notes: ''
};

export default function InvoiceEditor() {
  const { uuid } = useParams();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState<Invoice>(emptyInvoice);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (uuid && uuid !== 'new') {
      fetchInvoice(uuid);
    } else if (uuid === 'new') {
      const prefilled = sessionStorage.getItem('prefilledInvoice');
      if (prefilled) {
        try {
          const data = JSON.parse(prefilled);
          setInvoice(prev => ({
            ...prev,
            documentType: data.documentType || prev.documentType,
            buyer: { ...prev.buyer, ...data.buyer },
            lines: data.lines,
            notes: data.notes || prev.notes,
            orderId: data.orderId || prev.orderId
          }));
          sessionStorage.removeItem('prefilledInvoice');
        } catch (e) {
          console.error('Failed to parse prefilled invoice data', e);
        }
      }
    }
  }, [uuid]);

  const fetchInvoice = async (id: string) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/invoices/${id}`, {
        headers
      });
      if (!res.ok) {
        const err = await res.json();
        setError(err.error || 'Neizdevās ielādēt rēķinu.');
        return;
      }
      
      const data = await res.json();
      // Ensure numeric fields are numbers
      data.vatRate = Number(data.vatRate);
      data.totalWithoutVat = Number(data.totalWithoutVat);
      data.vatAmount = Number(data.vatAmount);
      data.totalWithVat = Number(data.totalWithVat);
      data.paidAmount = Number(data.paidAmount);
      data.remainingAmount = Number(data.remainingAmount);
      data.lines = data.lines.map((l: any) => ({
        ...l,
        quantity: Number(l.quantity),
        unitPrice: Number(l.unitPrice),
        lineTotal: Number(l.lineTotal)
      }));
      setInvoice(data);
    } catch (error) {
      console.error('Failed to fetch invoice', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setError(null);
    if (invoice.lines.length === 0) {
      setError('Rēķinam jābūt vismaz vienai pozīcijai.');
      return;
    }

    setLoading(true);
    try {
      const isNew = uuid === 'new';
      if (!isNew && invoice.status !== 'draft') {
        throw new Error('Tikai jaunu vai melnraksta rēķinu var rediģēt.');
      }
      
      const method = isNew ? 'POST' : 'PUT';
      const url = isNew ? '/api/invoices' : `/api/invoices/${uuid}`;
      
      // Recalculate totals before saving
      const totals = calcTotals(invoice.lines, invoice.vatRate, invoice.paidAmount);
      const dataToSave = {
        ...invoice,
        totalWithoutVat: totals.subtotal,
        vatAmount: totals.vat,
        totalWithVat: totals.total,
        remainingAmount: totals.due
      };

      const token = localStorage.getItem('token');
      
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(url, {
        method,
        headers,
        body: JSON.stringify(dataToSave)
      });

      if (res.ok) {
        const savedInvoice = await res.json();
        navigate(`/admin/invoices/${savedInvoice.uuid}`);
      } else {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to save invoice');
      }
    } catch (err: any) {
      console.error('Failed to save invoice', err);
      setError(err.message || 'Neizdevās saglabāt rēķinu.');
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/invoices/${uuid}/send-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ email: invoice.buyer.email })
      });

      if (res.ok) {
        setInvoice(prev => ({ ...prev, isSent: true, status: 'sent' }));
      } else {
        const err = await res.json();
        setError(err.error || 'Neizdevās nosūtīt rēķinu.');
      }
    } catch (err: any) {
      setError(err.message || 'Neizdevās nosūtīt rēķinu.');
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field: keyof Invoice, value: any) => {
    setInvoice(prev => ({ ...prev, [field]: value }));
  };

  const updateBuyer = (field: keyof Company, value: any) => {
    setInvoice(prev => ({ ...prev, buyer: { ...prev.buyer, [field]: value } }));
  };

  const totals = calcTotals(invoice.lines, invoice.vatRate, invoice.paidAmount);

  const isLocked = uuid !== 'new' && invoice.status !== 'draft';
  const inputClass = (baseClass: string) => 
    `${baseClass} ${isLocked ? 'bg-zinc-50 cursor-not-allowed text-zinc-500' : 'bg-white focus:border-black'}`;

  if (loading && uuid !== 'new') return (
    <div className="flex justify-center items-center h-64">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
    </div>
  );

  return (
    <div className="p-8 max-w-6xl mx-auto font-sans text-zinc-900">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/admin?tab=invoices')} className="p-2 text-zinc-400 hover:text-black hover:bg-zinc-100 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-2xl font-black tracking-tight uppercase">
              {uuid === 'new' ? 'Jauns rēķins' : `Rēķins ${invoice.documentNumber}`}
            </h1>
            <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mt-1">
              {uuid === 'new' ? 'Izveidojiet jaunu rēķinu vai priekšapmaksu' : `Izveidots ${new Date(invoice.createdAt).toLocaleDateString('lv-LV')}`}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {uuid !== 'new' && (
            <>
              <a href={`/api/invoices/${uuid}/pdf`} target="_blank" rel="noopener noreferrer" className="bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 px-4 py-2 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all">
                <FileText size={14} /> PDF
              </a>
              <button 
                onClick={handleSend}
                disabled={invoice.status === 'sent' || invoice.isSent || loading}
                className="bg-white border border-zinc-200 text-zinc-700 hover:bg-zinc-50 px-4 py-2 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={14} /> {invoice.isSent ? 'Nosūtīts' : 'Nosūtīt'}
              </button>
            </>
          )}
          {(uuid === 'new' || invoice.status === 'draft') && (
            <button 
              onClick={handleSave} 
              disabled={loading || !invoice.orderId || invoice.lines.length === 0} 
              title={invoice.lines.length === 0 ? 'Pievienojiet vismaz vienu pozīciju' : ''}
              className="bg-black hover:bg-zinc-800 text-white px-6 py-2 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all disabled:opacity-70 disabled:cursor-not-allowed"
            >
              <Save size={14} /> {loading ? 'Saglabā...' : 'Saglabāt'}
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6 text-sm font-medium">
          {error}
        </div>
      )}

      {uuid === 'new' && !invoice.orderId && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6 text-sm font-medium">
          Uzmanību: Jaunu rēķinu var izveidot tikai no pasūtījuma. Lūdzu, atveriet pasūtījumu un izvēlieties "Izveidot rēķinu".
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Document Info */}
        <div className="bg-white p-6 border border-zinc-200 flex flex-col gap-5">
          <div className="flex items-center gap-3 border-b border-zinc-100 pb-4">
            <div className="w-8 h-8 bg-zinc-100 flex items-center justify-center text-zinc-600">
              <FileText size={16} />
            </div>
            <h3 className="text-[11px] font-black uppercase tracking-widest text-zinc-800">Dokumenta info</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Tips</label>
              <select
                value={invoice.documentType}
                onChange={isLocked ? undefined : (e) => updateField('documentType', e.target.value as DocumentType)}
                disabled={isLocked}
                className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
              >
                <option value="invoice">Rēķins</option>
                <option value="prepayment">Priekšapmaksas rēķins</option>
              </select>
            </div>
            <div>
              <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Numurs</label>
              <input
                type="text"
                value={invoice.documentNumber}
                readOnly
                className="block w-full border border-zinc-200 bg-zinc-50 px-3 py-2 text-xs font-bold text-zinc-500 cursor-not-allowed font-mono focus:outline-none"
                placeholder="(Automātiski ģenerēts)"
              />
            </div>
            <div>
              <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Pasūtījuma ID</label>
              <input
                type="text"
                value={invoice.orderNumber || '—'}
                readOnly
                className="block w-full border border-zinc-200 bg-zinc-50 px-3 py-2 text-xs font-bold text-zinc-500 cursor-not-allowed font-mono focus:outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Datums</label>
                <input
                  type="date"
                  value={invoice.issueDate}
                  onChange={isLocked ? undefined : (e) => updateField('issueDate', e.target.value)}
                  readOnly={isLocked}
                  className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                />
              </div>
              <div>
                <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Termiņš</label>
                <input
                  type="date"
                  value={invoice.payDeadline}
                  onChange={isLocked ? undefined : (e) => updateField('payDeadline', e.target.value)}
                  readOnly={isLocked}
                  className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Buyer Info */}
        <div className="bg-white p-6 border border-zinc-200 flex flex-col gap-5">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-zinc-100 flex items-center justify-center text-zinc-600">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </div>
              <h3 className="text-[11px] font-black uppercase tracking-widest text-zinc-800">Pircējs</h3>
            </div>
            <div className="flex bg-zinc-100 p-1 rounded">
              <button
                onClick={isLocked ? undefined : () => updateBuyer('customerType', 'b2b')}
                disabled={isLocked}
                className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded transition-all ${invoice.buyer.customerType === 'b2b' ? 'bg-white shadow-sm text-black' : 'text-zinc-500 hover:text-zinc-700'} ${isLocked ? 'cursor-not-allowed opacity-70' : ''}`}
              >
                Juridiska pers.
              </button>
              <button
                onClick={isLocked ? undefined : () => updateBuyer('customerType', 'b2c')}
                disabled={isLocked}
                className={`px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded transition-all ${invoice.buyer.customerType === 'b2c' ? 'bg-white shadow-sm text-black' : 'text-zinc-500 hover:text-zinc-700'} ${isLocked ? 'cursor-not-allowed opacity-70' : ''}`}
              >
                Privātpersona
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            {invoice.buyer.customerType === 'b2b' ? (
              <>
                <div>
                  <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Nosaukums</label>
                  <input
                    type="text"
                    value={invoice.buyer.name}
                    onChange={isLocked ? undefined : (e) => updateBuyer('name', e.target.value)}
                    readOnly={isLocked}
                    className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                    placeholder="SIA Piemērs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Reģ. Nr.</label>
                    <input
                      type="text"
                      value={invoice.buyer.regNo}
                      onChange={isLocked ? undefined : (e) => updateBuyer('regNo', e.target.value)}
                      readOnly={isLocked}
                      className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all font-mono")}
                      placeholder="40000000000"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">PVN Nr.</label>
                    <input
                      type="text"
                      value={invoice.buyer.vatNo}
                      onChange={isLocked ? undefined : (e) => updateBuyer('vatNo', e.target.value)}
                      readOnly={isLocked}
                      className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all font-mono")}
                      placeholder="LV40000000000"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Juridiskā adrese</label>
                  <input
                    type="text"
                    value={invoice.buyer.address}
                    onChange={isLocked ? undefined : (e) => updateBuyer('address', e.target.value)}
                    readOnly={isLocked}
                    className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                    placeholder="Ielas nosaukums 1, Pilsēta, LV-1000"
                  />
                </div>
              </>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Vārds</label>
                    <input
                      type="text"
                      value={invoice.buyer.firstName || ''}
                      onChange={isLocked ? undefined : (e) => updateBuyer('firstName', e.target.value)}
                      readOnly={isLocked}
                      className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                      placeholder="Jānis"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Uzvārds</label>
                    <input
                      type="text"
                      value={invoice.buyer.lastName || ''}
                      onChange={isLocked ? undefined : (e) => updateBuyer('lastName', e.target.value)}
                      readOnly={isLocked}
                      className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                      placeholder="Bērziņš"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Piegādes adrese</label>
                  <input
                    type="text"
                    value={invoice.buyer.address}
                    onChange={isLocked ? undefined : (e) => updateBuyer('address', e.target.value)}
                    readOnly={isLocked}
                    className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                    placeholder="Ielas nosaukums 1, Pilsēta, LV-1000"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">E-pasts</label>
                    <input
                      type="email"
                      value={invoice.buyer.email}
                      onChange={isLocked ? undefined : (e) => updateBuyer('email', e.target.value)}
                      readOnly={isLocked}
                      className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                      placeholder="janis@piemers.lv"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-black text-zinc-400 uppercase tracking-widest mb-1.5">Tālrunis</label>
                    <input
                      type="text"
                      value={invoice.buyer.phone}
                      onChange={isLocked ? undefined : (e) => updateBuyer('phone', e.target.value)}
                      readOnly={isLocked}
                      className={inputClass("block w-full border border-zinc-200 px-3 py-2 text-xs font-bold focus:outline-none transition-all")}
                      placeholder="+371 20000000"
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Summary */}
        <div className="bg-white p-6 border border-zinc-200 flex flex-col gap-5">
          <div className="flex items-center gap-3 border-b border-zinc-100 pb-4">
            <div className="w-8 h-8 bg-zinc-100 flex items-center justify-center text-zinc-600">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <h3 className="text-[11px] font-black uppercase tracking-widest text-zinc-800">Kopsavilkums</h3>
          </div>
          
          <div className="flex-1">
            <StatsBar totals={totals} vatRate={invoice.vatRate} />
          </div>
        </div>
      </div>

      {/* Lines */}
      <div className="bg-white border border-zinc-200 overflow-hidden mb-8">
        <div className="p-6 border-b border-zinc-200 flex justify-between items-center bg-zinc-50">
          <h3 className="text-[11px] font-black uppercase tracking-widest text-zinc-800">Pozīcijas</h3>
        </div>
        <div className="p-0">
          <InvoiceLineEditor lines={invoice.lines} onChange={isLocked ? () => {} : (lines) => updateField('lines', lines)} isLocked={isLocked} />
        </div>
      </div>
    </div>
  );
}
