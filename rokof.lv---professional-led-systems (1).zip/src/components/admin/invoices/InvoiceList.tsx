import React, { useState, useEffect } from 'react';
import { Invoice, InvoiceStatus } from '../../../utils/invoices/types';
import { Link } from 'react-router-dom';
import { Plus, Search, FileText, Trash2, Edit, ChevronRight } from 'lucide-react';
import { storeService } from '../../../../services/storeService';

export default function InvoiceList() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<'invoice' | 'prepayment'>('invoice');
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchInvoices();
  }, [filterType, search]);

  const getAuthToken = () => {
    const storedUser = storeService.getStoredUser();
    let token = storedUser?.token || localStorage.getItem('token');
    if (token && token.startsWith('"') && token.endsWith('"')) {
      token = token.slice(1, -1);
    }
    return token;
  };

  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({ type: filterType });
      if (search) query.append('q', search);
      
      const token = getAuthToken();
      
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/invoices?${query.toString()}`, {
        headers
      });
      if (res.ok) {
        const data = await res.json();
        setInvoices(data);
      }
    } catch (error) {
      console.error('Failed to fetch invoices', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (uuid: string) => {
    if (!confirm('Are you sure you want to delete this invoice?')) return;
    try {
      const token = getAuthToken();
      
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/invoices/${uuid}`, {
        method: 'DELETE',
        headers
      });
      if (res.ok) {
        fetchInvoices();
      }
    } catch (error) {
      console.error('Failed to delete invoice', error);
    }
  };

  const handleUpdateInvoiceStatus = async (uuid: string, status: string) => {
    try {
      const token = getAuthToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/invoices/${uuid}/status`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchInvoices();
      } else {
        const err = await res.json();
        alert(`Kļūda: ${err.error || 'Neizdevās atjaunināt statusu'}`);
      }
    } catch (error) {
      console.error('Failed to update status', error);
      alert('Neizdevās sazināties ar serveri.');
    }
  };

  const handleSendInvoiceEmail = async (uuid: string) => {
    try {
      const token = getAuthToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/invoices/${uuid}/send-email`, {
        method: 'POST',
        headers
      });
      if (res.ok) {
        fetchInvoices();
      } else {
        const err = await res.json();
        alert(`Kļūda: ${err.error || 'Neizdevās nosūtīt e-pastu'}`);
      }
    } catch (error) {
      console.error('Failed to send email', error);
      alert('Neizdevās sazināties ar serveri.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="relative flex-grow max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-300 w-4 h-4" />
          <input
            type="text"
            placeholder="Meklēt pēc numura vai pircēja..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-6 py-4 text-xs font-bold border border-zinc-200 focus:outline-none"
          />
        </div>
        <Link 
          to="/admin/invoices/new" 
          className="px-6 py-4 bg-black text-white hover:bg-zinc-800 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-colors"
        >
          <Plus size={16} /> Jauns rēķins
        </Link>
      </div>

      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setFilterType('invoice')}
          className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest transition-all border ${
            filterType === 'invoice' 
              ? 'bg-black text-white border-black' 
              : 'bg-white text-zinc-500 border-zinc-200 hover:bg-zinc-50 hover:text-black'
          }`}
        >
          Rēķini
        </button>
        <button
          onClick={() => setFilterType('prepayment')}
          className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest transition-all border ${
            filterType === 'prepayment' 
              ? 'bg-black text-white border-black' 
              : 'bg-white text-zinc-500 border-zinc-200 hover:bg-zinc-50 hover:text-black'
          }`}
        >
          Priekšapmaksas
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
        </div>
      ) : (
        <div className="bg-white border border-zinc-200">
          <table className="w-full text-left">
            <thead className="bg-zinc-50 border-b border-zinc-200 text-[9px] font-black uppercase tracking-widest text-zinc-400">
              <tr>
                <th className="px-6 py-4">Nr.</th>
                <th className="px-6 py-4">Datums</th>
                <th className="px-6 py-4">Pircējs</th>
                <th className="px-6 py-4 text-right">Summa</th>
                <th className="px-6 py-4 text-center">Statuss</th>
                <th className="px-6 py-4 text-right">Darbības</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {invoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                    Nav atrasts neviens rēķins.
                  </td>
                </tr>
              ) : (
                invoices.map((invoice) => (
                  <tr key={invoice.uuid} className="hover:bg-zinc-50 transition-colors group">
                    <td className="px-6 py-4 text-[11px] font-black">
                      <Link to={`/admin/invoices/${invoice.uuid}`} className="hover:underline">
                        {invoice.documentNumber || 'Melnraksts'}
                      </Link>
                    </td>
                    <td className="px-6 py-4 text-xs font-bold text-zinc-500 font-mono">
                      {invoice.issueDate}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-[11px] font-bold uppercase">{invoice.buyer.name || 'Nezināms pircējs'}</div>
                      <div className="text-[9px] text-zinc-400">{invoice.buyer.regNo}</div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-bold text-xs text-[#8DB835]">
                      €{Number(invoice.totalWithVat).toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`px-3 py-1 text-[9px] font-black uppercase tracking-widest rounded-sm flex items-center justify-center gap-2 w-max mx-auto
                        ${invoice.status === 'paid' ? 'bg-emerald-500 text-white' : 
                          invoice.status === 'sent' ? 'bg-blue-500 text-white' : 
                          invoice.status === 'draft' ? 'bg-zinc-200 text-zinc-600' :
                          'bg-rose-500 text-white'}`}>
                        {invoice.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        {invoice.status === 'draft' && (
                          <button
                            onClick={() => handleUpdateInvoiceStatus(invoice.uuid, 'ready_to_send')}
                            className="px-3 py-1 bg-zinc-200 text-zinc-700 text-[9px] font-black uppercase tracking-widest rounded-sm hover:bg-zinc-300 transition-colors"
                          >
                            Send (Ready)
                          </button>
                        )}
                        {invoice.status === 'ready_to_send' && (
                          <button
                            onClick={() => handleSendInvoiceEmail(invoice.uuid)}
                            className="px-3 py-1 bg-blue-500 text-white text-[9px] font-black uppercase tracking-widest rounded-sm hover:bg-blue-600 transition-colors"
                          >
                            SENT
                          </button>
                        )}
                        {(invoice.status === 'sent' || invoice.status === 'paid') && (
                          <button
                            onClick={() => handleSendInvoiceEmail(invoice.uuid)}
                            className="px-3 py-1 bg-zinc-800 text-white text-[9px] font-black uppercase tracking-widest rounded-sm hover:bg-black transition-colors"
                          >
                            Resend ({invoice.sendCount || 0})
                          </button>
                        )}
                        <a 
                          href={`/api/invoices/${invoice.uuid}/pdf`} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-zinc-400 hover:text-black transition-colors"
                          title="Lejupielādēt PDF"
                        >
                          <FileText size={16} />
                        </a>
                        <Link 
                          to={`/admin/invoices/${invoice.uuid}`} 
                          className="text-zinc-400 hover:text-black transition-colors"
                          title="Rediģēt"
                        >
                          <Edit size={16} />
                        </Link>
                        <button 
                          onClick={() => handleDelete(invoice.uuid)} 
                          className="text-zinc-400 hover:text-rose-600 transition-colors"
                          title="Dzēst"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
