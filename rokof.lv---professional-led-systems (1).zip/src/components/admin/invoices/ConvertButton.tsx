import React from 'react';
import { Invoice } from '../../../utils/invoices/types';
import { convertToInvoice } from '../../../utils/invoices/converter';
import { useNavigate } from 'react-router-dom';
import { storeService } from '../../../../services/storeService';

interface Props {
  invoice: Invoice;
}

export default function ConvertButton({ invoice }: Props) {
  const navigate = useNavigate();

  const handleConvert = async () => {
    if (!confirm('Vai tiešām vēlaties konvertēt šo priekšapmaksas rēķinu par rēķinu?')) return;

    // Generate new invoice object
    // In a real app, we might want to fetch the next number from the server first
    // For now, we'll let the server handle the number generation or use a placeholder
    const newInvoice = convertToInvoice(invoice, ''); 
    
    try {
      const storedUser = storeService.getStoredUser();
      const token = storedUser?.token;
      
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers,
        body: JSON.stringify(newInvoice)
      });

      if (res.ok) {
        const savedInvoice = await res.json();
        navigate(`/admin/invoices/${savedInvoice.uuid}`);
      }
    } catch (error) {
      console.error('Failed to convert invoice', error);
    }
  };

  if (invoice.documentType !== 'prepayment' || invoice._converted) return null;

  return (
    <button
      onClick={handleConvert}
      className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition-colors"
    >
      Konvertēt uz Rēķinu
    </button>
  );
}
