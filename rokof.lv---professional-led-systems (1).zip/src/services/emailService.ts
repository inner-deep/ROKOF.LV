import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export const sendWelcomeEmail = async (email: string, recipientName: string, language: string) => {
  const smtpHost = process.env.SMTP_HOST;
  const smtpUser = process.env.SMTP_USER;
  
  // Skip sending if SMTP is not configured or uses placeholder values
  if (!smtpHost || smtpHost === 'smtp.example.com' || !smtpUser || smtpUser === 'user@example.com') {
    console.warn(`⚠️ SMTP is not configured or uses placeholder values. Skipping welcome email to ${email}.`);
    console.log(`[SIMULATED EMAIL] To: ${email}, Name: ${recipientName}, Language: ${language}`);
    return;
  }

  console.log(`Attempting to send welcome email to ${email}. SMTP_USER: ${smtpUser ? 'Set' : 'Not Set'}`);
  try {
    const subject = language === 'LV' ? 'Laipni lūdzam ROKOF.LV — Jūsu profils ir izveidots!' : 'Welcome to ROKOF.LV — Your profile has been created!';
    
    const contentHtml = language === 'LV' ? `
<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; border: 1px solid #eee; padding: 20px; border-radius: 10px;">
  <h2 style="color: #000;">Laipni lūdzam ROKOF.LV!</h2>
  <p>Labdien, <strong>${recipientName}</strong>!</p>
  <p>Paldies, ka izvēlējāties reģistrēt savu lietotāja profilu ROKOF.LV platformā. Jūsu konts ir veiksmīgi izveidots.</p>
  <p>Tagad Jums ir pieejamas visas sistēmas priekšrocības:</p>
  <ul>
    <li><strong>Pasūtījumu vēsture:</strong> Pārvaldiet savus pirkumus un sekojiet līdzi to izpildes statusam.</li>
    <li><strong>Garantijas kontrole:</strong> Sekojiet iegādāto profesionālo LED iekārtu garantijas termiņiem savā profilā.</li>
    <li><strong>B2B priekšrocības:</strong> Ja pārstāvat uzņēmumu, atgādinām, ka pasūtījumiem virs 200€ (bez PVN) piegāde Latvijas teritorijā ir bez maksas.</li>
  </ul>
  <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <p><strong>Jūsu konta informācija:</strong><br>
    E-pasts: ${email}</p>
    <a href="https://rokof.lv/login" style="display: inline-block; background-color: #000; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">Pieslēgties profilam</a>
  </div>
  <p style="font-size: 0.9em; color: #777;">Datu aizsardzība un Jūsu tiesības: Mēs augsti vērtējam Jūsu privātumu. Jūsu dati tiek apstrādāti saskaņā ar mūsu <a href="https://rokof.lv/privacy-policy" style="color: #000;">Privātuma politiku</a>.</p>
  <p style="font-size: 0.9em; color: #777;">Ja Jums rodas jautājumi, lūdzam sazināties ar mums: <a href="mailto:pavels@pzka.lv" style="color: #000;">pavels@pzka.lv</a>.</p>
  <p>Ar cieņu,<br>ROKOF.LV komanda</p>
</div>` : `
<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; border: 1px solid #eee; padding: 20px; border-radius: 10px;">
  <h2 style="color: #000;">Welcome to ROKOF.LV!</h2>
  <p>Hello, <strong>${recipientName}</strong>!</p>
  <p>Thank you for registering your user profile on the ROKOF.LV platform. Your account has been successfully created.</p>
  <p>You now have access to all system benefits:</p>
  <ul>
    <li><strong>Order history:</strong> Manage your purchases and track their fulfillment status.</li>
    <li><strong>Warranty control:</strong> Track the warranty terms of purchased professional LED equipment in your profile.</li>
    <li><strong>B2B benefits:</strong> If you represent a company, we remind you that delivery within Latvia is free for orders over 200€ (excluding VAT).</li>
  </ul>
  <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
    <p><strong>Your account information:</strong><br>
    Email: ${email}</p>
    <a href="https://rokof.lv/login" style="display: inline-block; background-color: #000; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">Login to your profile</a>
  </div>
  <p style="font-size: 0.9em; color: #777;">Data protection and your rights: We highly value your privacy. Your data is processed in accordance with our <a href="https://rokof.lv/privacy-policy" style="color: #000;">Privacy Policy</a>.</p>
  <p style="font-size: 0.9em; color: #777;">If you have any questions, please contact us: <a href="mailto:pavels@pzka.lv" style="color: #000;">pavels@pzka.lv</a>.</p>
  <p>Best regards,<br>ROKOF.LV team</p>
</div>`;

    console.log(`Sending mail to ${email}...`);
    const info = await transporter.sendMail({
      from: `"${process.env.SMTP_FROM_NAME || 'ROKOF.LV'}" <${process.env.SMTP_FROM || 'pavels@pzka.lv'}>`,
      to: email,
      subject: subject,
      html: contentHtml,
    });
    console.log(`Welcome email successfully sent to ${email}. Message ID: ${info.messageId}`);
  } catch (error) {
    console.error(`Failed to send welcome email to ${email}:`, error);
    // Do not throw error to avoid crashing registration flow
  }
};
