
import { test, expect } from '@playwright/test';

test.describe('UI/UX Validation', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('Responsive Layout - 16-inch screen', async ({ page }) => {
    await page.setViewportSize({ width: 1536, height: 864 });
    // Check if header is visible and not broken
    await expect(page.locator('header')).toBeVisible();
    // Check if product grid/list is visible
    await expect(page.locator('main')).toBeVisible();
  });

  test('Element Collision - PIEVIENOT button vs Quantity Input', async ({ page }) => {
    // In list view, check if button and input are properly aligned
    const productRow = page.locator('div[data-testid="product-row"]').first();
    if (await productRow.isVisible()) {
      const addButton = productRow.locator('button:has-text("PIEVIENOT")');
      const quantityInput = productRow.locator('input[type="number"]');
      
      const buttonBox = await addButton.boundingBox();
      const inputBox = await quantityInput.boundingBox();
      
      if (buttonBox && inputBox) {
        // Ensure they don't overlap horizontally if they are on the same line
        // Or ensure they have enough space
        expect(buttonBox.x).toBeGreaterThan(inputBox.x + inputBox.width);
      }
    }
  });

  test('Modal Behavior - Registration modal scrollability', async ({ page }) => {
    await page.click('button:has-text("REĢISTRĒTIES")');
    const modal = page.locator('div[role="dialog"]');
    await expect(modal).toBeVisible();
    
    // Check if modal content is scrollable if it exceeds viewport
    const modalContent = modal.locator('.overflow-y-auto');
    await expect(modalContent).toBeVisible();
  });

  test('Autofill CSS Fix - input:-webkit-autofill', async ({ page }) => {
    // This is hard to test with Playwright directly as it involves browser internals,
    // but we can check if the style is present in the document
    const styleTag = await page.locator('style').textContent();
    expect(styleTag).toContain('input:-webkit-autofill');
    expect(styleTag).toContain('-webkit-box-shadow: 0 0 0 100px white inset !important');
  });
});
