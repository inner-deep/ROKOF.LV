
import { test, expect } from '@playwright/test';

test.describe('User Flows', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('Registration Flow - B2C', async ({ page }) => {
    await page.click('button:has-text("REĢISTRĒTIES")');
    await page.click('button:has-text("PRIVATE")');
    
    await page.fill('input[placeholder="VĀRDS"]', 'Test');
    await page.fill('input[placeholder="UZVĀRDS"]', 'User');
    await page.fill('input[placeholder="E-PASTS"]', 'test@example.com');
    await page.fill('input[placeholder="PAROLE"]', 'password123');
    
    // Submit registration (assuming there's a submit button)
    // await page.click('button[type="submit"]');
  });

  test('Registration Flow - B2B with VAT prefix', async ({ page }) => {
    await page.click('button:has-text("REĢISTRĒTIES")');
    await page.click('button:has-text("BUSINESS")');
    
    await page.fill('input[placeholder="UZŅĒMUMA NOSAUKUMS"]', 'Test Corp');
    const vatInput = page.locator('input[placeholder="PVN MAKSĀTĀJA NUMURS"]');
    await vatInput.fill('123456789');
    
    // Check if 'LV' prefix is handled correctly (either auto-added or validated)
    const value = await vatInput.inputValue();
    // Logic check depends on implementation, but here we just ensure it's filled
    expect(value).toContain('123456789');
  });

  test('Checkout Process and PDF Invoice Link', async ({ page }) => {
    // Add item to cart
    await page.click('button:has-text("PIEVIENOT")');
    await page.click('button:has-text("Grozs")');
    await page.click('button:has-text("Turpināt noformēšanu")');
    
    // Fill checkout details
    await page.fill('input[placeholder="Iela, Pilsēta, Pasta indekss"]', 'Test Street 1, Riga');
    await page.fill('input[placeholder="Kontakttālrunis"]', '20000000');
    
    // Confirm order
    await page.click('button:has-text("Apstiprināt pasūtījumu")');
    
    // Check for success message and Order ID format ROK-XXXX
    await expect(page.locator('text=Paldies par pasūtījumu!')).toBeVisible();
    const orderNo = await page.locator('text=Pasūtījuma nr:').textContent();
    expect(orderNo).toMatch(/ROK-\d+/);
    
    // Login and check User Profile for PDF link
    // (Assuming user is logged in or we log in here)
    // await page.goto('/account');
    // await expect(page.locator('text=LEJUPIELĀDĒT PDF')).toBeVisible();
  });

  test('Auth State - Restricted Access', async ({ page }) => {
    // Try to access orders without login
    // Depending on routing, this might redirect or show login modal
    await page.goto('/account'); 
    // If it's a SPA, it might stay on home and open auth modal
    await expect(page.locator('text=IENĀKT')).toBeVisible();
  });
});
