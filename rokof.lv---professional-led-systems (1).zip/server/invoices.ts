import express from 'express';
import { PrismaClient } from '@prisma/client';
import nodemailer from 'nodemailer';
import { generateInvoicePdfData, InvoiceForPdf } from './pdfUtils';

import { COMPANY_DETAILS } from './config';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();
const prisma = new PrismaClient();

router.use(authMiddleware);

// Email Transporter (reused from server.ts or configured here)
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Helper: Format Date as DD.MM.YYYY
function formatDate(d: Date): string {
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

// Helper: Generate Next Invoice Number
async function getNextNumber(type: 'invoice' | 'prepayment', prismaClient: PrismaClient): Promise<string> {
  const prefix = type === 'invoice' ? 'RKF-' : 'PR-';
  const sequenceName = type === 'invoice' ? 'invoice_number' : 'prepayment_number';
  
  try {
    const seq = await prismaClient.sequence.update({
      where: { name: sequenceName },
      data: { value: { increment: 1 } }
    });
    return `${prefix}${String(seq.value).padStart(6, '0')}`;
  } catch (error: any) {
    if (error.code === 'P2025') { // Record to update not found
      const lastInvoice = await prismaClient.invoice.findFirst({
        where: { documentType: type },
        orderBy: { documentNumber: 'desc' },
      });
      
      let startValue = 0;
      if (lastInvoice) {
        const lastNumStr = lastInvoice.documentNumber.replace(prefix, '');
        const lastNum = parseInt(lastNumStr, 10);
        if (!isNaN(lastNum)) {
          startValue = lastNum;
        }
      }
      
      const seq = await prismaClient.sequence.upsert({
        where: { name: sequenceName },
        update: { value: { increment: 1 } },
        create: { name: sequenceName, value: startValue + 1 }
      });
      return `${prefix}${String(seq.value).padStart(6, '0')}`;
    }
    throw error;
  }
}

// Helper: Create Invoice with retry for documentNumber race condition
async function createInvoiceWithRetry(prismaClient: PrismaClient, data: any, include: any = undefined) {
  let retries = 5;
  while (retries > 0) {
    try {
      const invoice = await prismaClient.invoice.create({
        data,
        include
      });
      return invoice;
    } catch (error: any) {
      if (error.code === 'P2002' && error.meta?.target?.includes('documentNumber')) {
        retries--;
        if (retries === 0) throw new Error('Failed to generate unique document number after multiple attempts');
        await new Promise(resolve => setTimeout(resolve, Math.random() * 50 + 10));
        data.documentNumber = await getNextNumber(data.documentType, prismaClient);
      } else {
        throw error;
      }
    }
  }
}

export const mapInvoice = (invoice: any) => {
  const order = invoice.order;
  // Try to find a human-readable number, fallback to UUID only if it's not a standard UUID format
  let orderNumber = null;
  if (order) {
    orderNumber = order.orderNumber || order.invoiceNumber || order.rkfInvoiceNumber || order.pavadzimeNumber || order.id;
  } else if (invoice.orderId) {
    // If it's a UUID (contains hyphens and is long), don't use it as the display number
    const isUuid = invoice.orderId.includes('-') && invoice.orderId.length > 20;
    orderNumber = isUuid ? null : invoice.orderId;
  }

  let mappedLines = invoice.lines || [];

  // If buyer details are missing on the invoice but we have an order, try to extract them
  let buyerName = invoice.buyerName || '';
  let buyerRegNo = invoice.buyerRegNo || '';
  let buyerVatNo = invoice.buyerVatNo || '';
  let buyerAddress = invoice.buyerAddress || '';
  let buyerEmail = invoice.buyerEmail || '';
  let buyerPhone = invoice.buyerPhone || '';
  let buyerBank = invoice.buyerBank || '';
  let buyerSwift = invoice.buyerSwift || '';
  let buyerAccount = invoice.buyerAccount || '';

  return {
    ...invoice,
    orderId: invoice.orderId || null,
    orderNumber: orderNumber,
    prepaymentNumber: invoice.prepayment?.documentNumber || null,
    hasInvoice: invoice.finalInvoice?.length > 0,
    invoiceUuid: invoice.finalInvoice?.[0]?.uuid || null,
    finalInvoiceUuid: invoice.finalInvoice?.[0]?.uuid || null,
    finalInvoiceNumber: invoice.finalInvoice?.[0]?.documentNumber || null,
    lines: mappedLines,
    seller: {
      name: invoice.sellerName || '',
      regNo: invoice.sellerRegNo || '',
      vatNo: invoice.sellerVatNo || '',
      address: invoice.sellerAddress || '',
      bankName: invoice.sellerBank || '',
      swift: invoice.sellerSwift || '',
      iban: invoice.sellerAccount || '',
      email: invoice.sellerEmail || '',
      phone: invoice.sellerPhone || '',
      signatoryName: invoice.sellerSignatory || '',
    },
    buyer: {
      customerType: invoice.buyerCustomerType || 'b2b',
      name: buyerName,
      firstName: invoice.buyerFirstName || '',
      lastName: invoice.buyerLastName || '',
      regNo: buyerRegNo,
      vatNo: buyerVatNo,
      address: buyerAddress,
      bankName: buyerBank,
      swift: buyerSwift,
      iban: buyerAccount,
      email: buyerEmail,
      phone: buyerPhone,
      signatoryName: invoice.buyerSignatory || '',
    }
  };
};

// GET /api/invoices
router.get('/', async (req, res) => {
  try {
    const { type, status, q } = req.query;
    
    const where: any = {
      deletedAt: null
    };
    if (type) where.documentType = type;
    if (status) {
      where.status = status;
      if (status === 'cancelled') {
        delete where.deletedAt; // Allow viewing cancelled/deleted invoices if explicitly requested
      }
    }
    if (q) {
      where.OR = [
        { documentNumber: { contains: String(q) } },
        { sellerName: { contains: String(q) } },
        { buyerName: { contains: String(q) } },
      ];
    }

    const invoices = await prisma.invoice.findMany({
      where,
      include: { lines: true, order: true, prepayment: true, finalInvoice: true },
      orderBy: { createdAt: 'desc' },
    });

    res.json(invoices.map(mapInvoice));
  } catch (error) {
    console.error('Error fetching invoices:', error);
    res.status(500).json({ error: 'Failed to fetch invoices' });
  }
});

// GET /api/invoices/:uuid
router.get('/:uuid', async (req, res) => {
  try {
    const { uuid } = req.params;
    const invoice = await prisma.invoice.findUnique({
      where: { uuid },
      include: { lines: true, order: true, prepayment: true, finalInvoice: true },
    });

    if (!invoice || invoice.deletedAt) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    res.json(mapInvoice(invoice));
  } catch (error) {
    console.error('Error fetching invoice:', error);
    res.status(500).json({ error: 'Failed to fetch invoice' });
  }
});

// Helper: Create Invoice From Order Logic
export async function createInvoiceFromOrder(orderId: string, prismaClient: PrismaClient) {
    // 1. Fetch Order
    const order = await prismaClient.order.findUnique({
      where: { id: orderId },
      include: { user: true, items: true }
    });

    if (!order) {
      throw new Error('Order not found');
    }

    // 2. Determine document type
    // If order is paid or processing, it's a final invoice. Otherwise prepayment.
    const documentType = ['PAID', 'PROCESSING', 'IN_DELIVERY', 'SHIPPED', 'COMPLETED'].includes(order.status) ? 'invoice' : 'prepayment';

    // 3. Check if already exists
    const existingInvoice = await prismaClient.invoice.findFirst({
      where: { orderId, documentType },
      include: { lines: true, order: true, prepayment: true, finalInvoice: true }
    });

    if (existingInvoice) {
      return mapInvoice(existingInvoice);
    }

    // 4. Prepare Buyer Snapshot
    let buyerData: any = {};
    if (order.user) {
      const u = order.user;
      const isB2B = u.type === 'COMPANY' || u.type === 'BUSINESS' || !!u.regNo;
      
      if (isB2B) {
        buyerData = {
          buyerCustomerType: 'b2b',
          buyerName: u.companyName || '',
          buyerRegNo: u.regNo || '',
          buyerVatNo: u.vatNo || '',
          buyerAddress: u.legalAddress || '',
          buyerEmail: u.email || '',
          buyerPhone: u.phone || '',
          buyerBank: u.bankName || '',
          buyerSwift: u.swift || '',
          buyerAccount: u.bankAccount || '',
        };
      } else {
        // B2C
        buyerData = {
          buyerCustomerType: 'b2c',
          buyerFirstName: u.firstName || '',
          buyerLastName: u.lastName || '',
          buyerName: `${u.firstName || ''} ${u.lastName || ''}`.trim(),
          buyerRegNo: null,
          buyerVatNo: null,
          buyerAddress: u.physicalAddress || order.deliveryAddress || '',
          buyerEmail: u.email || '',
          buyerPhone: u.phone || '',
          buyerBank: u.bankName || '',
          buyerSwift: u.swift || '',
          buyerAccount: u.bankAccount || '',
        };
      }
    } else if (order.customerInfo) {
      try {
        const info = JSON.parse(order.customerInfo);
        buyerData = {
          buyerCustomerType: info.customerType || (info.company ? 'b2b' : 'b2c'),
          buyerFirstName: info.firstName || '',
          buyerLastName: info.lastName || '',
          buyerName: info.companyName || info.company || info.name || '',
          buyerRegNo: info.regNo || '',
          buyerVatNo: info.vatNo || '',
          buyerAddress: (info.customerType === 'b2b' || info.company) ? (info.legalAddress || '') : (info.address || order.deliveryAddress || ''),
          buyerEmail: info.email || '',
          buyerPhone: info.phone || '',
          buyerBank: info.bankName || '',
          buyerSwift: info.swift || '',
          buyerAccount: info.iban || info.bankAccount || '',
        };
      } catch (e) {
        console.error('Failed to parse customerInfo', e);
      }
    }

    // 5. Generate Number
    const documentNumber = await getNextNumber(documentType, prismaClient);

    // 6. Map Lines
    const lines = order.items.map((item, index) => ({
      pos: index + 1,
      description: item.title,
      sku: item.productId,
      unit: (item as any).unit || 'gab.',
      quantity: item.quantity,
      unitPrice: item.priceAtPurchase || 0,
      lineTotal: item.total || (item.priceAtPurchase * item.quantity)
    }));

    if (order.deliveryCost > 0) {
      lines.push({
        pos: lines.length + 1,
        description: 'Piegāde',
        sku: 'DELIVERY',
        unit: 'gab.',
        quantity: 1,
        unitPrice: order.deliveryCost,
        lineTotal: order.deliveryCost
      });
    }

    if (lines.length === 0) {
      throw new Error('Cannot generate invoice for an order without items.');
    }

    // 7. Calculate Amounts
    const totalWithVat = Number(order.totalAmount);
    const totalWithoutVat = order.subtotal ? Number(order.subtotal) : (totalWithVat / 1.21);
    const vatAmount = order.vatAmount ? Number(order.vatAmount) : (totalWithVat - totalWithoutVat);

    // 8. Create Invoice
    const invoice = await createInvoiceWithRetry(prismaClient, {
      documentNumber,
      documentType,
      status: order.status === 'PAID' ? 'paid' : 'draft',
      issueDate: formatDate(new Date()),
      payDeadline: formatDate(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)), // 7 days default
      issuePlace: 'Rīga',
      vatRate: 21,
      
      sellerName: COMPANY_DETAILS.name,
      sellerRegNo: COMPANY_DETAILS.regNo,
      sellerVatNo: COMPANY_DETAILS.vatNo,
      sellerAddress: COMPANY_DETAILS.address,
      sellerBank: COMPANY_DETAILS.bankName,
      sellerSwift: COMPANY_DETAILS.swift,
      sellerAccount: COMPANY_DETAILS.iban,
      sellerEmail: COMPANY_DETAILS.email,
      sellerPhone: COMPANY_DETAILS.phone,
      
      ...buyerData,
      
      totalWithoutVat,
      vatAmount,
      totalWithVat,
      remainingAmount: totalWithVat,
      notes: `Izveidots automātiski no pasūtījuma ${order.orderNumber || order.invoiceNumber || order.id}`,
      order: { connect: { id: order.id } },
      
      lines: {
        create: lines
      }
    }, { lines: true, order: true, prepayment: true, finalInvoice: true });

    return mapInvoice({ ...invoice, order });
}

// POST /api/invoices/generate-from-order/:orderId
router.post('/generate-from-order/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const invoice = await createInvoiceFromOrder(orderId, prisma);
    res.json(invoice);
  } catch (error) {
    console.error('Error generating invoice from order:', error);
    res.status(500).json({ error: 'Failed to generate invoice' });
  }
});

// POST /api/invoices
router.post('/', async (req, res) => {
  try {
    const data = req.body;
    
    // 1. Enforce Order ID and Lines
    if (!data.orderId) {
      return res.status(400).json({ error: 'Order ID is mandatory for new invoices.' });
    }
    if (!data.lines || !Array.isArray(data.lines) || data.lines.length === 0) {
      return res.status(400).json({ error: 'Invoice must contain at least one line item.' });
    }

    // 2. Fetch Order and User for Snapshot
    const order = await prisma.order.findUnique({
      where: { id: data.orderId },
      include: { user: true },
    });

    if (!order) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    const user = order.user;
    let buyerSnapshot: any = {};

    if (user) {
      // Determine Customer Type (B2B vs B2C)
      const isB2B = user.type === 'COMPANY' || user.type === 'BUSINESS' || !!user.regNo;

      if (isB2B) {
        // B2B Snapshot
        buyerSnapshot = {
          buyerCustomerType: 'b2b',
          buyerName: user.companyName,
          buyerRegNo: user.regNo,
          buyerVatNo: user.vatNo,
          buyerAddress: user.legalAddress || '',
          buyerEmail: user.email,
          buyerPhone: user.phone,
          buyerBank: user.bankName || '',
          buyerSwift: user.swift || '',
          buyerAccount: user.bankAccount || '',
        };
      } else {
        // B2C Snapshot
        const fullName = [user.firstName, user.lastName].filter(Boolean).join(' ');
        
        // Construct address if physicalAddress is missing
        let address = user.physicalAddress;
        if (!address) {
          const parts = [
            user.street, 
            user.building ? `${user.building}` : null,
            user.apartment ? `-${user.apartment}` : null,
            user.city, 
            user.zipCode, 
            user.country
          ].filter(Boolean);
          address = parts.join(', ');
        }

        buyerSnapshot = {
          buyerCustomerType: 'b2c',
          buyerFirstName: user.firstName,
          buyerLastName: user.lastName,
          buyerName: fullName,
          buyerAddress: address || order.deliveryAddress || '',
          buyerEmail: user.email,
          buyerPhone: user.phone,
          buyerRegNo: null,
          buyerVatNo: null,
          buyerBank: user.bankName || '',
          buyerSwift: user.swift || '',
          buyerAccount: user.bankAccount || '',
        };
      }
    } else if (order.customerInfo) {
      try {
        const info = JSON.parse(order.customerInfo);
        buyerSnapshot = {
          buyerCustomerType: info.customerType || (info.company ? 'b2b' : 'b2c'),
          buyerFirstName: info.firstName || '',
          buyerLastName: info.lastName || '',
          buyerName: info.companyName || info.company || info.name || '',
          buyerRegNo: info.regNo || '',
          buyerVatNo: info.vatNo || '',
          buyerAddress: (info.customerType === 'b2b' || info.company) ? (info.legalAddress || '') : (info.address || order.deliveryAddress || ''),
          buyerEmail: info.email || '',
          buyerPhone: info.phone || '',
          buyerBank: info.bankName || '',
          buyerSwift: info.swift || '',
          buyerAccount: info.iban || info.bankAccount || '',
        };
      } catch (e) {
        console.error('Failed to parse customerInfo', e);
        return res.status(400).json({ error: 'Failed to parse customer info from order.' });
      }
    } else {
      return res.status(404).json({ error: 'User associated with order not found and no customer info available.' });
    }

    // Generate number if not provided
    if (!data.documentNumber) {
      data.documentNumber = await getNextNumber(data.documentType, prisma);
    }

    const invoice = await createInvoiceWithRetry(prisma, {
      documentNumber: data.documentNumber,
      documentType: data.documentType,
      status: data.status || 'draft',
      issueDate: data.issueDate,
      payDeadline: data.payDeadline,
      shipDate: data.shipDate,
      issuePlace: data.issuePlace,
      receivePlace: data.receivePlace,
      vatRate: data.vatRate,
      
      sellerName: data.seller?.name || COMPANY_DETAILS.name,
      sellerRegNo: data.seller?.regNo || COMPANY_DETAILS.regNo,
      sellerVatNo: data.seller?.vatNo || COMPANY_DETAILS.vatNo,
      sellerAddress: data.seller?.address || COMPANY_DETAILS.address,
      sellerBank: data.seller?.bankName || COMPANY_DETAILS.bankName,
      sellerSwift: data.seller?.swift || COMPANY_DETAILS.swift,
      sellerAccount: data.seller?.iban || COMPANY_DETAILS.iban,
      sellerEmail: data.seller?.email || COMPANY_DETAILS.email,
      sellerPhone: data.seller?.phone || COMPANY_DETAILS.phone,
      sellerSignatory: data.seller?.signatoryName,

      // Apply Snapshot from DB - authoritative source for protected fields
      buyerCustomerType: buyerSnapshot.buyerCustomerType || 'b2b',
      buyerName: buyerSnapshot.buyerName,
      buyerFirstName: buyerSnapshot.buyerFirstName,
      buyerLastName: buyerSnapshot.buyerLastName,
      buyerRegNo: buyerSnapshot.buyerRegNo,
      buyerVatNo: buyerSnapshot.buyerVatNo,
      buyerAddress: buyerSnapshot.buyerAddress,
      buyerEmail: buyerSnapshot.buyerEmail,
      buyerPhone: buyerSnapshot.buyerPhone,
      
      // Bank details also from user profile (authoritative)
      buyerBank: buyerSnapshot.buyerBank || '',
      buyerSwift: buyerSnapshot.buyerSwift || '',
      buyerAccount: buyerSnapshot.buyerAccount || '',
      
      // Allow overriding only unprotected fields
      buyerSignatory: data.buyer?.signatoryName,

      lines: {
        create: data.lines.map((l: any) => ({
          pos: l.pos,
          description: l.description,
          sku: l.sku,
          unit: l.unit,
          quantity: l.quantity,
          unitPrice: l.unitPrice,
          lineTotal: l.lineTotal,
        })),
      },
      totalWithoutVat: data.totalWithoutVat,
      vatAmount: data.vatAmount,
      totalWithVat: data.totalWithVat,
      paidAmount: data.paidAmount,
      remainingAmount: data.remainingAmount,
      notes: data.notes,
      prepaymentUuid: data.prepaymentUuid,
      order: { connect: { id: data.orderId } },
    }, { lines: true, order: true, prepayment: true, finalInvoice: true });

    res.json(mapInvoice({ ...invoice, order }));
  } catch (error) {
    console.error('Error creating invoice:', error);
    res.status(500).json({ error: 'Failed to create invoice' });
  }
});

// POST /api/invoices/:uuid/generate-invoice
router.post('/:uuid/generate-invoice', async (req, res) => {
  try {
    const { uuid } = req.params;

    // 1. Find PR by uuid
    const prepayment = await prisma.invoice.findUnique({
      where: { uuid },
      include: { lines: true, order: true },
    });

    if (!prepayment || prepayment.deletedAt) {
      return res.status(404).json({ error: 'Prepayment invoice not found' });
    }

    // 2. Check documentType === 'prepayment'
    if (prepayment.documentType !== 'prepayment') {
      return res.status(400).json({ error: 'Source document must be a prepayment' });
    }

    // 3. Check order.status === 'PAID'
    if (!prepayment.order || prepayment.order.status !== 'PAID') {
      return res.status(400).json({ error: 'Order must be PAID to generate a final invoice' });
    }

    // 4. Check if the RKF has already been created
    const existingFinalInvoice = await prisma.invoice.findFirst({
      where: { prepaymentUuid: uuid },
      include: { lines: true, order: true, prepayment: true, finalInvoice: true },
    });

    if (existingFinalInvoice) {
      return res.json(mapInvoice(existingFinalInvoice));
    }

    // 5. Generate a new number using getNextNumber('invoice')
    const documentNumber = await getNextNumber('invoice', prisma);

    // 6. Copy all seller, buyer snapshot, and lines fields from the PR
    const lines = prepayment.lines.map((l: any) => ({
      pos: l.pos,
      description: l.description,
      sku: l.sku,
      unit: l.unit,
      quantity: l.quantity,
      unitPrice: l.unitPrice,
      lineTotal: l.lineTotal,
    }));

    // 7. Create using createInvoiceWithRetry
    const finalInvoice = await createInvoiceWithRetry(prisma, {
      documentNumber,
      documentType: 'invoice',
      status: 'paid', // RKF is paid since order is PAID
      issueDate: new Date().toISOString().split('T')[0],
      payDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      vatRate: prepayment.vatRate,
      
      sellerName: prepayment.sellerName,
      sellerRegNo: prepayment.sellerRegNo,
      sellerVatNo: prepayment.sellerVatNo,
      sellerAddress: prepayment.sellerAddress,
      sellerBank: prepayment.sellerBank,
      sellerSwift: prepayment.sellerSwift,
      sellerAccount: prepayment.sellerAccount,
      sellerEmail: prepayment.sellerEmail,
      sellerPhone: prepayment.sellerPhone,
      sellerSignatory: prepayment.sellerSignatory,

      buyerCustomerType: prepayment.buyerCustomerType,
      buyerName: prepayment.buyerName,
      buyerFirstName: prepayment.buyerFirstName,
      buyerLastName: prepayment.buyerLastName,
      buyerRegNo: prepayment.buyerRegNo,
      buyerVatNo: prepayment.buyerVatNo,
      buyerAddress: prepayment.buyerAddress,
      buyerEmail: prepayment.buyerEmail,
      buyerPhone: prepayment.buyerPhone,
      buyerBank: prepayment.buyerBank,
      buyerSwift: prepayment.buyerSwift,
      buyerAccount: prepayment.buyerAccount,
      buyerSignatory: prepayment.buyerSignatory,

      totalWithoutVat: prepayment.totalWithoutVat,
      vatAmount: prepayment.vatAmount,
      totalWithVat: prepayment.totalWithVat,
      
      // 8. paidAmount = totalWithVat, remainingAmount = 0
      paidAmount: prepayment.totalWithVat,
      remainingAmount: 0,
      
      // 9. prepaymentUuid = uuid of the original PR
      prepaymentUuid: uuid,
      order: { connect: { id: prepayment.orderId } },
      
      lines: {
        create: lines
      }
    }, { lines: true, order: true, prepayment: true, finalInvoice: true });

    res.json(mapInvoice(finalInvoice));
  } catch (error) {
    console.error('Error generating final invoice:', error);
    res.status(500).json({ error: 'Failed to generate final invoice' });
  }
});

// Helper: Validate Invoice Update
export function validateInvoiceUpdate(existingInvoice: any, incomingData: any) {
  const normalize = (val: any) => {
    if (val === "" || val === undefined) return null;
    if (val instanceof Date) return val.toISOString();
    return val;
  };

  // 1. Check if invoice is draft
  if (existingInvoice.status !== 'draft') {
    // If not draft, only allow specific fields to be updated
    const allowedFields = ['status', 'paidAmount', 'notes', 'isSent'];
    
    // Check if any protected fields are being modified
    const protectedFields = [
      'orderId', 'documentNumber', 'documentType', 'issueDate', 
      'totalWithoutVat', 'vatAmount', 'totalWithVat',
      'buyerCustomerType', 'buyerName', 'buyerFirstName', 'buyerLastName',
      'buyerRegNo', 'buyerVatNo', 'buyerAddress', 'buyerEmail', 'buyerPhone',
      'buyerBank', 'buyerSwift', 'buyerAccount', 'buyerSignatory',
      'sellerName', 'sellerRegNo', 'sellerVatNo', 'sellerAddress',
      'sellerBank', 'sellerSwift', 'sellerAccount', 'sellerEmail', 'sellerPhone', 'sellerSignatory'
    ];

    for (const field of protectedFields) {
      if (incomingData[field] !== undefined) {
        const incomingVal = normalize(incomingData[field]);
        const existingVal = normalize(existingInvoice[field]);
        if (incomingVal !== existingVal) {
          throw new Error(`Invoice is not editable after creation. Cannot modify protected field: ${field}`);
        }
      }
    }

    // Check lines modification
    if (incomingData.lines) {
      // Basic check: if lines are provided, they must exactly match existing lines
      // A more robust check would compare each line deeply, but for now, we reject any lines payload on non-draft
      throw new Error('Invoice is not editable after creation. Cannot modify lines.');
    }

    // If we reach here, only allowed fields are being modified
    const sanitizedPayload: any = {};
    for (const field of allowedFields) {
      if (incomingData[field] !== undefined) {
        sanitizedPayload[field] = incomingData[field];
      }
    }
    return sanitizedPayload;
  }

  // 2. If it IS a draft, we still protect some core fields but allow more flexibility
  const strictlyProtectedFields = [
    'orderId', 'documentNumber'
  ];
  for (const field of strictlyProtectedFields) {
      if (incomingData[field] !== undefined) {
        const incomingVal = normalize(incomingData[field]);
        const existingVal = normalize(existingInvoice[field]);
        if (incomingVal !== existingVal) {
          throw new Error(`Cannot modify strictly protected field: ${field} even in draft status.`);
        }
      }
  }

  // Allow updating buyer snapshot, lines, dates, etc. for draft
  const sanitizedPayload = { ...incomingData };
  // Remove strictly protected fields from payload to ensure they aren't accidentally updated
  for (const field of strictlyProtectedFields) {
      delete sanitizedPayload[field];
  }
  
  return sanitizedPayload;
}

// PUT /api/invoices/:uuid
router.put('/:uuid', async (req, res) => {
  try {
    const { uuid } = req.params;
    const data = req.body;

    // 1. Get existing invoice
    const existingInvoice = await prisma.invoice.findUnique({
      where: { uuid },
      include: { lines: true }
    });

    // 2. If not found -> 404
    if (!existingInvoice || existingInvoice.deletedAt) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    // 3 & 4 & 5. Validate update
    let sanitizedData;
    try {
      sanitizedData = validateInvoiceUpdate(existingInvoice, data);
    } catch (validationError: any) {
      return res.status(403).json({ error: validationError.message || 'Invoice is not editable after creation' });
    }

    // Handle lines update separately if it's a draft and lines are provided
    if (existingInvoice.status === 'draft' && data.lines) {
        if (!Array.isArray(data.lines) || data.lines.length === 0) {
            return res.status(400).json({ error: 'Invoice must contain at least one line item.' });
        }

        // Delete existing lines
        await prisma.invoiceLine.deleteMany({
            where: { invoiceId: (existingInvoice as any).id }
        });

        // Create new lines
        sanitizedData.lines = {
            create: data.lines.map((l: any) => ({
                pos: l.pos,
                description: l.description,
                sku: l.sku,
                unit: l.unit,
                quantity: l.quantity,
                unitPrice: l.unitPrice,
                lineTotal: l.lineTotal,
            }))
        };
    } else {
        delete sanitizedData.lines; // Ensure lines aren't updated if not draft or not provided
    }

    // Perform update
    const updatedInvoice = await prisma.invoice.update({
      where: { uuid },
      data: sanitizedData,
      include: { lines: true, order: true, prepayment: true, finalInvoice: true }
    });

    res.json(mapInvoice(updatedInvoice));
  } catch (error) {
    console.error('Error updating invoice:', error);
    res.status(500).json({ error: 'Failed to update invoice' });
  }
});

// DELETE /api/invoices/:uuid
router.delete('/:uuid', async (req, res) => {
  try {
    const { uuid } = req.params;
    const existingInvoice = await prisma.invoice.findUnique({ where: { uuid } });
    
    if (!existingInvoice || existingInvoice.deletedAt) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    await prisma.invoice.update({
      where: { uuid },
      data: { status: 'cancelled', deletedAt: new Date() }
    });
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting invoice:', error);
    res.status(500).json({ error: 'Failed to delete invoice' });
  }
});

// GET /api/invoices/:uuid/pdf
router.get('/:uuid/pdf', async (req, res) => {
  try {
    const { uuid } = req.params;
    const rawInvoice = await prisma.invoice.findUnique({
      where: { uuid },
      include: { lines: true, order: true, prepayment: true, finalInvoice: true },
    });

    if (!rawInvoice || rawInvoice.deletedAt) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const invoice = mapInvoice(rawInvoice) as InvoiceForPdf;

    const pdfBuffer = await generateInvoicePdfData(invoice);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${invoice.documentNumber}.pdf`);
    res.send(pdfBuffer);

  } catch (error) {
    console.error('Error generating PDF:', error);
    res.status(500).json({ error: 'Failed to generate PDF' });
  }
});

// POST /api/invoices/:uuid/send-email
router.post('/:uuid/send-email', async (req, res) => {
  try {
    const { uuid } = req.params;
    const { email, force } = req.body; // Optional override and force flag

    const rawInvoice = await prisma.invoice.findUnique({
      where: { uuid },
      include: { lines: true, order: true, prepayment: true, finalInvoice: true },
    });

    if (!rawInvoice || rawInvoice.deletedAt) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    if (rawInvoice.isSent && !force) {
      return res.status(409).json({ 
        error: 'Invoice already sent. Use { force: true } in the request body to resend.' 
      });
    }

    const invoice = mapInvoice(rawInvoice) as InvoiceForPdf;

    const recipient = email || invoice.buyer.email;
    if (!recipient) {
      return res.status(400).json({ error: 'No recipient email found' });
    }

    const pdfBuffer = await generateInvoicePdfData(invoice);
    
    await transporter.sendMail({
      from: '"ROKOF" <' + (process.env.SMTP_FROM || 'info@rokof.lv') + '>',
      to: recipient,
      subject: `Rēķins Nr. ${invoice.documentNumber}`,
      text: `Labdien! Nosūtām Jums rēķinu Nr. ${invoice.documentNumber}.`,
      attachments: [{ 
        filename: `${invoice.documentNumber}.pdf`, 
        content: pdfBuffer,
        contentType: 'application/pdf'
      }]
    });

    const updateData: any = {
      isSent: true,
      sentToEmail: recipient,
      status: 'sent',
      sendCount: { increment: 1 }
    };

    if (!rawInvoice.sentAt) {
      updateData.sentAt = new Date();
    }

    await prisma.invoice.update({
      where: { uuid },
      data: updateData,
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send email' });
  }
});

export default router;
