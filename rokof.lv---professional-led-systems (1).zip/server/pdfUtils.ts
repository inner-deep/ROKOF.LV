import fs from "fs";
import path from "path";
import PDFDocument from "pdfkit";
import QRCode from "qrcode";

// Конфигурация размеров и отступов A4
const PDF_CONFIG = {
  PAGE_WIDTH: 595.28,
  PAGE_HEIGHT: 841.89,
  MARGIN: 40,
  FOOTER_Y: 730,
  ROW_BREAK_THRESHOLD: 730,
  SUMMARY_BREAK_THRESHOLD: 600,
  SIGNATURE_BREAK_THRESHOLD: 680
};

export const numberToWordsLV = (amount: number): string => {
  const units = ["", "viens", "divi", "trīs", "četri", "pieci", "seši", "septiņi", "astoņi", "deviņi"];
  const teens = ["desmit", "vienpadsmit", "divpadsmit", "trīspadsmit", "četrpadsmit", "piecpadsmit", "sešpadsmit", "septiņpadsmit", "astoņpadsmit", "deviņpadsmit"];
  const tens = ["", "desmit", "divdesmit", "trīsdesmit", "četrdesmit", "piecdesmit", "sešdesmit", "septiņdesmit", "astoņdesmit", "deviņdesmit"];
  const hundreds = ["", "simts", "divi simti", "trīs simti", "četri simti", "pieci simti", "seši simti", "septiņi simti", "astoņi simti", "deviņi simti"];

  const integerPart = Math.floor(amount);
  const decimalPart = Math.round((amount - integerPart) * 100);

  const convertThreeDigits = (n: number): string => {
    let res = "";
    const h = Math.floor(n / 100);
    const t = Math.floor((n % 100) / 10);
    const u = n % 10;
    if (h > 0) res += hundreds[h] + " ";
    if (t === 1) {
      res += teens[u] + " ";
    } else {
      if (t > 1) res += tens[t] + " ";
      if (u > 0) res += units[u] + " ";
    }
    return res.trim();
  };

  let result = "";
  if (integerPart === 0) {
    result = "nulle";
  } else {
    const millions = Math.floor(integerPart / 1000000);
    const thousands = Math.floor((integerPart % 1000000) / 1000);
    const remainder = integerPart % 1000;
    if (millions > 0) {
      if (millions === 1) result += "viens miljons ";
      else result += convertThreeDigits(millions) + " miljoni ";
    }
    if (thousands > 0) {
      if (thousands === 1) result += "viens tūkstotis ";
      else result += convertThreeDigits(thousands) + " tūkstoši ";
    }
    result += convertThreeDigits(remainder);
  }

  const eiroStr = "eiro";
  const centiStr = (decimalPart % 10 === 1 && decimalPart % 100 !== 11) ? "cents" : "centi";
  return `${result.trim()} ${eiroStr}, ${decimalPart} ${centiStr}`;
};

export async function getRobotoFonts() {
  const regularPath = path.join(process.cwd(), 'assets', 'fonts', 'Roboto-Regular.ttf');
  const boldPath = path.join(process.cwd(), 'assets', 'fonts', 'Roboto-Bold.ttf');
  
  if (!fs.existsSync(regularPath)) {
    throw new Error(`Kritiska kļūda: Nav atrasts fonts ${regularPath}`);
  }
  
  return {
    regular: regularPath,
    bold: fs.existsSync(boldPath) ? boldPath : regularPath
  };
}

export interface InvoiceForPdf {
  documentNumber: string;
  documentType: 'invoice' | 'prepayment';
  issueDate: string;
  orderNumber?: string;
  prepaymentNumber?: string;
  vatRate: number;
  status: string;
  totalWithVat: number;
  totalWithoutVat: number;
  vatAmount: number;
  seller: {
    name: string;
    regNo: string;
    address: string;
    bankName: string;
    swift: string;
    iban: string;
    vatNo: string;
  };
  buyer: {
    name: string;
    regNo?: string;
    address: string;
    vatNo?: string;
    email?: string;
    phone?: string;
  };
  lines: {
    description: string;
    sku?: string;
    unit?: string;
    quantity: number;
    unitPrice: number;
    lineTotal: number;
  }[];
}

export async function generateInvoicePdfData(invoice: InvoiceForPdf): Promise<Buffer> {
  // 1. ВАЛИДАЦИЯ ВХОДНЫХ ДАННЫХ
  if (!invoice.lines || invoice.lines.length === 0) {
    throw new Error('Rēķinam jāsatur vismaz viena prece (Invoice must contain at least one line item).');
  }

  const sellerData = {
    name: invoice.seller?.name || "SIA ROKOF",
    regNo: invoice.seller?.regNo || "40203287104",
    address: invoice.seller?.address || "Pūces iela 11/1-7, Rīga, LV-1082, Latvija",
    bankName: invoice.seller?.bankName || "AS ‘Citadele banka’",
    swift: invoice.seller?.swift || "PARXLV22",
    iban: invoice.seller?.iban || "LV47PARX0023781080001",
    vatNo: invoice.seller?.vatNo || "LV40203287104"
  };

  // Дополнительная валидация продавца
  if (!sellerData.name || !sellerData.iban) {
    throw new Error('Pārdevēja datiem (name, iban) jābūt norādītiem (Seller data must include name and IBAN).');
  }

  const vatRate = invoice.vatRate || 21;
  const vatMultiplier = 1 + (vatRate / 100);

  const doc = new PDFDocument({ margin: PDF_CONFIG.MARGIN, size: 'A4' });
  const buffers: Buffer[] = [];
  doc.on('data', buffers.push.bind(buffers));

  try {
    const fonts = await getRobotoFonts();
    doc.registerFont('Roboto', fonts.regular);
    doc.registerFont('Roboto-Bold', fonts.bold);
  } catch (e) {
    throw new Error("Neizdevās ielādēt PDF fontus (Failed to load PDF fonts). Lūdzu pārbaudiet assets/fonts mapi.");
  }

  // Устанавливаем базовый шрифт сразу после регистрации для корректного подсчета высоты строк в будущем
  doc.font('Roboto').fontSize(9);

  // --- ДИНАМИЧЕСКАЯ ШАПКА ---
  let headerBoxHeight = 60;
  if (invoice.orderNumber) headerBoxHeight += 12;
  if (invoice.documentType === 'invoice' && invoice.prepaymentNumber) headerBoxHeight += 12;

  doc.rect(210, 40, 180, headerBoxHeight).stroke();
  const title = invoice.documentType === 'invoice' ? 'PREČU PAVADZĪME-RĒĶINS' : 'PRIEKŠAPMAKSAS RĒĶINS';
  doc.font('Roboto-Bold').fontSize(10).text(title, 210, 55, { width: 180, align: 'center' });
  doc.fontSize(14).text(`Nr. ${invoice.documentNumber}`, 210, 72, { width: 180, align: 'center' });
  doc.font('Roboto').fontSize(10).text(`Datums: ${invoice.issueDate}`, 210, 88, { width: 180, align: 'center' });

  let currentHeaderY = 104;
  if (invoice.orderNumber) {
    doc.font('Roboto').fontSize(8)
      .text(`Pasūtījums: ${invoice.orderNumber}`, 210, currentHeaderY, { width: 180, align: 'center' });
    currentHeaderY += 12;
  }
  if (invoice.documentType === 'invoice' && invoice.prepaymentNumber) {
    doc.fontSize(8)
      .text(`Pamats: ${invoice.prepaymentNumber}`, 210, currentHeaderY, { width: 180, align: 'center' });
  }

  // --- РЕКВИЗИТЫ ---
  const leftCol = 40;
  const rightCol = 320;
  const reqY = 40 + headerBoxHeight + 20;

  doc.font('Roboto-Bold').fontSize(10).text('Nosūtītājs:', leftCol, reqY);
  const sellerText = [
    sellerData.name,
    `Reģistrācijas Nr.: ${sellerData.regNo}`,
    sellerData.address,
    sellerData.bankName,
    `SWIFT: ${sellerData.swift}`,
    `IBAN: ${sellerData.iban}`,
    `PVN reģ. Nr.: ${sellerData.vatNo}`
  ].join('\n');
  doc.font('Roboto').fontSize(9).text(sellerText, leftCol, reqY + 15, { width: 260 });

  doc.font('Roboto-Bold').fontSize(10).text('Saņēmējs:', rightCol, reqY);
  const buyerLines = [invoice.buyer.name];
  
  // ЖЕСТКАЯ ЗАЩИТА GDPR
  if (invoice.buyer.regNo && invoice.buyer.regNo.trim().length > 0) buyerLines.push(`Reģistrācijas Nr.: ${invoice.buyer.regNo.trim()}`);
  if (invoice.buyer.address && invoice.buyer.address.trim().length > 0) buyerLines.push(invoice.buyer.address.trim());
  if (invoice.buyer.vatNo && invoice.buyer.vatNo.trim().length > 0) buyerLines.push(`PVN reģ. Nr.: ${invoice.buyer.vatNo.trim()}`);
  if (invoice.buyer.email && invoice.buyer.email.trim().length > 0) buyerLines.push(`E-pasts: ${invoice.buyer.email.trim()}`);
  if (invoice.buyer.phone && invoice.buyer.phone.trim().length > 0) buyerLines.push(`Tālrunis: ${invoice.buyer.phone.trim()}`);
  
  const buyerText = buyerLines.join('\n');
  doc.font('Roboto').fontSize(9).text(buyerText, rightCol, reqY + 15, { width: 220 });

  const sellerHeight = doc.heightOfString(sellerText, { width: 260 });
  const buyerHeight = doc.heightOfString(buyerText, { width: 220 });
  let y = reqY + 15 + Math.max(sellerHeight, buyerHeight) + 30;

  // --- ТАБЛИЦА ---
  const drawHeader = (startY: number) => {
    doc.font('Roboto-Bold').fontSize(9);
    doc.text('#', 40, startY, { width: 20 });
    doc.text('Nosaukums', 65, startY, { width: 175 });
    doc.text('Mērv.', 245, startY, { width: 40, align: 'center' });
    doc.text('Daudz.', 285, startY, { width: 40, align: 'center' });
    doc.text('Cena (bez PVN)', 325, startY, { width: 75, align: 'right' });
    doc.text(`PVN ${vatRate}%`, 405, startY, { width: 60, align: 'right' });
    doc.text('Kopā, EUR', 470, startY, { width: 80, align: 'right' });
    const lineY = startY + 15;
    doc.moveTo(40, lineY).lineTo(550, lineY).stroke();
    return lineY + 10;
  };

  y = drawHeader(y);

  let calculatedSubtotalNet = 0;
  
  doc.font('Roboto').fontSize(8);
  invoice.lines.forEach((item, index) => {
    const unitPriceGross = Number(item.unitPrice || 0);
    const qty = Number(item.quantity || 1);
    
    // МАТЕМАТИЧЕСКАЯ ТОЧНОСТЬ С НДС
    const unitPriceNet = unitPriceGross / vatMultiplier;
    const lineNetTotal = unitPriceNet * qty;
    const lineGrossTotal = unitPriceGross * qty;
    const lineVat = lineGrossTotal - lineNetTotal;
    
    calculatedSubtotalNet += lineNetTotal;

    const unit = item.unit || 'gab.';
    const descriptionText = `${item.description} ${item.sku ? `(${item.sku})` : ''}`.trim();
    
    const descriptionHeight = doc.heightOfString(descriptionText, { width: 175 });
    const rowHeight = Math.max(15, descriptionHeight);

    // ИСПОЛЬЗУЕМ КОНСТАНТЫ ДЛЯ ПЕРЕНОСА СТРОК
    if (y + rowHeight > PDF_CONFIG.ROW_BREAK_THRESHOLD) {
      doc.addPage();
      y = PDF_CONFIG.MARGIN;
      y = drawHeader(y);
      doc.font('Roboto').fontSize(8);
    }

    doc.text((index + 1).toString(), 40, y, { width: 20 });
    doc.text(descriptionText, 65, y, { width: 175 });
    doc.text(unit, 245, y, { width: 40, align: 'center' });
    doc.text(qty.toString(), 285, y, { width: 40, align: 'center' });
    doc.text(unitPriceNet.toFixed(2), 325, y, { width: 75, align: 'right' });
    doc.text(lineVat.toFixed(2), 405, y, { width: 60, align: 'right' });
    doc.text(lineGrossTotal.toFixed(2), 470, y, { width: 80, align: 'right' });
    
    y += rowHeight + 10;
  });

  doc.moveTo(40, y).lineTo(550, y).stroke();
  y += 15;

  if (y > PDF_CONFIG.SUMMARY_BREAK_THRESHOLD) {
    doc.addPage();
    y = PDF_CONFIG.MARGIN;
  }

  // --- ИТОГИ ---
  const finalTotalAmount = Number(invoice.totalWithVat || 0);
  const finalVatAmount = finalTotalAmount - calculatedSubtotalNet;

  doc.font('Roboto').fontSize(10);
  doc.text('Kopā bez PVN:', 350, y);
  doc.text(calculatedSubtotalNet.toFixed(2), 470, y, { align: 'right', width: 80 });
  y += 15;
  doc.text(`PVN ${vatRate}%:`, 350, y);
  doc.text(finalVatAmount.toFixed(2), 470, y, { align: 'right', width: 80 });
  y += 15;
  doc.font('Roboto-Bold').fontSize(11);
  doc.text('Kopā apmaksai:', 350, y);
  doc.text(`EUR ${finalTotalAmount.toFixed(2)}`, 450, y, { align: 'right', width: 100 });
  y += 25;

  doc.font('Roboto').fontSize(9);
  doc.text(`Summa vārdiem: ${numberToWordsLV(finalTotalAmount)}`, 40, y);
  y += 20;

  // ПЕЧАТЬ СТРОГО ДЛЯ ОПЛАЧЕННЫХ
  if (invoice.status === 'paid' || invoice.status === 'PAID') {
    doc.save();
    doc.rotate(-30, { origin: [300, 500] });
    doc.font('Roboto-Bold').fontSize(30).fillColor('#cc0000').opacity(0.4);
    doc.text('APMAKSĀTS / ОПЛАЧЕНО', 150, 450, { align: 'center', width: 300 });
    doc.restore();
    doc.fillColor('black').opacity(1);
    doc.font('Roboto-Bold').fontSize(10).text('Apmaksāts. Prece izsniegta.', 40, y + 10);
    y += 25;
  }

  if (y > PDF_CONFIG.SIGNATURE_BREAK_THRESHOLD) {
    doc.addPage();
  }

  // --- ПОДВАЛ ---
  const footerY = PDF_CONFIG.FOOTER_Y; 
  doc.font('Roboto').fontSize(7);
  doc.text('Kavēta maksājuma gadījumā tiek aprēķināta nokavējuma nauda 0.5% apmērā no kavētās summas par katru kavējuma dienu.', 40, footerY);
  doc.text('Prece paliek pārdevēja īpašums līdz rēķina 100% apmaksai.', 40, footerY + 10);
  
  doc.text('Nosūtītājs: ________________________', 40, footerY + 30);
  doc.text('Saņēmējs: ________________________', 320, footerY + 30);
  doc.fontSize(6).text('(Vārds, Uzvārds, Paraksts)', 40, footerY + 38);
  doc.text('(Vārds, Uzvārds, Paraksts)', 320, footerY + 38);

  doc.font('Roboto-Bold').fontSize(8).text('Dokuments sagatavots elektroniski un ir derīgs bez paraksta', 40, footerY + 55);

  // QR-КОД ТОЛЬКО ДЛЯ ПРЕДОПЛАТЫ
  if (invoice.documentType === 'prepayment') {
    const qrString = `BCD\n002\n1\nSCT\n\n${sellerData.name}\n${sellerData.iban}\nEUR${finalTotalAmount.toFixed(2)}\n\n\n${invoice.documentNumber}`;
    try {
        const qrCodeDataUrl = await QRCode.toDataURL(qrString);
        doc.image(qrCodeDataUrl, 450, footerY - 100, { width: 80 });
        doc.fontSize(7).font('Roboto').text('Zibmaksājums (QR)', 450, footerY - 15, { width: 80, align: 'center' });
    } catch (e) {
        console.warn("Neizdevās ģenerēt QR kodu, turpinām bez tā (Failed to generate QR code):", e);
        // Fallback текст, если QR код не сгенерировался
        doc.fontSize(7).font('Roboto').text('QR kods nav pieejams', 450, footerY - 100, { width: 80, align: 'center' });
    }
  }

  doc.end();

  // ЗАЩИТА ОТ УТЕЧЕК ПАМЯТИ
  await new Promise<void>((resolve, reject) => {
    doc.on('end', resolve);
    doc.on('error', reject);
  });
  
  return Buffer.concat(buffers);
}