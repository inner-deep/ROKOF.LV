export const COMPANY_DETAILS = {
  name: "ROKOF SIA",
  regNo: "40203287104",
  vatNo: "LV40203287104",
  address: "Pūces iela 11/1-7, Rīga, LV-1082, Latvija",
  bankName: "AS ‘Citadele banka’",
  swift: "PARXLV22",
  iban: "LV47PARX0023781080001",
  email: "pavels@pzka.lv",
  phone: "+371 28312345" // Example phone
};
