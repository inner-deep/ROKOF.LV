const loginAttempts = new Map<string, { count: number, lastAttempt: number }>();

export const rateLimiter = (identifier: string) => {
  const attempt = loginAttempts.get(identifier);
  const now = Date.now();

  if (attempt && attempt.count >= 5 && now - attempt.lastAttempt < 15 * 60 * 1000) {
    throw new Error("Pārāk daudz mēģinājumu. Lūdzu, mēģiniet pēc 15 minūtēm.");
  }
  
  // Логика обновления счетчика
  if (attempt) {
    if (now - attempt.lastAttempt >= 15 * 60 * 1000) {
      // Сброс счетчика, если прошло 15 минут
      loginAttempts.set(identifier, { count: 1, lastAttempt: now });
    } else {
      // Увеличение счетчика
      loginAttempts.set(identifier, { count: attempt.count + 1, lastAttempt: now });
    }
  } else {
    // Первая попытка
    loginAttempts.set(identifier, { count: 1, lastAttempt: now });
  }
};

export const resetRateLimiter = (identifier: string) => {
  loginAttempts.delete(identifier);
};
