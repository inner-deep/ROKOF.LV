import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';

// 1. ЗАМЕНА ЛОГОТИПА: Вставьте сюда свой Base64 (я подготовил заглушку)
const ROKOF_LOGO_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABk..."; // Ваш реальный Base64

const formatAddress = (data: any) => {
  const parts = [
    data.street,
    data.building ? `korp. ${data.building}` : '',
    data.apartment ? `dz. ${data.apartment}` : '',
    data.city,
    data.district,
    data.zip || data.zipCode,
    data.country
  ];
  const formatted = parts.filter(part => part && part.trim() !== "").join(", ");
  return formatted || data.address || "";
};

const numberToWordsLV = (amount: number): string => {
  const units = ["", "viens", "divi", "trīs", "četri", "pieci", "seši", "septiņi", "astoņi", "deviņi"];
  const teens = ["desmit", "vienpadsmit", "divpadsmit", "trīspadsmit", "četrpadsmit", "piecpadsmit", "sešpadsmit", "septiņpadsmit", "astoņpadsmit", "deviņpadsmit"];
  const tens = ["", "desmit", "divdesmit", "trīsdesmit", "četrdesmit", "piecdesmit", "sešdesmit", "septiņdesmit", "astoņdesmit", "deviņdesmit"];
  const hundreds = ["", "simts", "divi simti", "trīs simti", "četri simti", "pieci simti", "seši simti", "septiņi simti", "astoņi simti", "deviņi simti"];

  const integerPart = Math.floor(amount);
  const decimalPart = Math.round((amount - integerPart) * 100);

  const convertThreeDigits = (n: number): string => {
    let res = "";
    const h = Math.floor(n / 100);
    const t = Math.floor((n % 100) / 10);
    const u = n % 10;

    if (h > 0) res += hundreds[h] + " ";
    if (t === 1) {
      res += teens[u] + " ";
    } else {
      if (t > 1) res += tens[t] + " ";
      if (u > 0) res += units[u] + " ";
    }
    return res.trim();
  };

  let result = "";
  if (integerPart === 0) {
    result = "nulle";
  } else {
    const millions = Math.floor(integerPart / 1000000);
    const thousands = Math.floor((integerPart % 1000000) / 1000);
    const remainder = integerPart % 1000;

    if (millions > 0) {
      if (millions === 1) result += "viens miljons ";
      else result += convertThreeDigits(millions) + " miljoni ";
    }
    if (thousands > 0) {
      if (thousands === 1) result += "viens tūkstotis ";
      else result += convertThreeDigits(thousands) + " tūkstoši ";
    }
    result += convertThreeDigits(remainder);
  }

  const eiroStr = "eiro";
  const centiStr = (decimalPart % 10 === 1 && decimalPart % 100 !== 11) ? "cents" : "centi";

  return `${result.trim()} ${eiroStr}, ${decimalPart} ${centiStr}`;
};

export const generateROKOFInvoice = async (
  orderData: any, 
  customerData: any, 
  lang: 'LV' | 'RU' | 'EN', 
  action: 'download' | 'blob' = 'download',
  documentType?: 'advance' | 'delivery'
) => {
  const doc = new jsPDF();
  const isRKF = documentType === 'delivery' ? true : (documentType === 'advance' ? false : !!orderData.rkfInvoiceNumber);
  const invoiceNumber = isRKF ? orderData.rkfInvoiceNumber : (orderData.invoiceNumber || orderData.number || orderData.id);

  // 1. LOAD FONT
  try {
    const response = await fetch('https://cdn.jsdelivr.net/gh/googlefonts/roboto@main/src/hinted/Roboto-Regular.ttf');
    const arrayBuffer = await response.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    let binary = '';
    for (let i = 0; i < uint8Array.length; i++) binary += String.fromCharCode(uint8Array[i]);
    const base64Font = btoa(binary);

    doc.addFileToVFS('Roboto-Regular.ttf', base64Font);
    doc.addFont('Roboto-Regular.ttf', 'Roboto', 'normal');
    doc.addFont('Roboto-Regular.ttf', 'Roboto', 'bold');
  } catch (e) {
    console.error("Font failed to load, using fallback", e);
  }
  
  // Translations
  const t = {
    LV: { 
      title: isRKF ? "PREČU PAVADZĪME-RĒĶINS" : "PRIEKŠAPMAKSAS RĒĶINS", 
      seller: "Nosūtītājs", 
      buyer: "Saņēmējs",
      delivery: "Piegāde",
      unit: "Mērv.",
      qty: "Daudz.",
      price: "Cena",
      total: "Kopā, EUR",
      vat: "PVN, %",
      totalWithoutVat: "Kopā bez PVN",
      vatAmount: "PVN 21.00%",
      grandTotal: "Kopā apmaksai",
      amountInWords: "Summa vārdiem",
      preparedElectronically: "Dokuments sagatavots elektroniski un ir derīgs bez paraksta",
      lateFeeClause: "Kavēta maksājuma gadījumā tiek aprēķināta nokavējuma nauda 0.5% apmērā no kavētās summas par katru kavējuma dienu.",
      ownershipClause: "Prece paliek pārdevēja īpašums līdz rēķina 100% apmaksai.",
      signaturePlaceholder: "(Vārds, Uzvārds, Paraksts)"
    },
    RU: { 
      title: isRKF ? "НАКЛАДНАЯ-СЧЕТ" : "СЧЕТ НА ПРЕДОПЛАТУ", 
      seller: "Отправитель", 
      buyer: "Получатель",
      delivery: "Доставка",
      unit: "Ед.",
      qty: "Кол.",
      price: "Цена",
      total: "Итого, EUR",
      vat: "НДС, %",
      totalWithoutVat: "Итого без НДС",
      vatAmount: "НДС 21.00%",
      grandTotal: "Итого к оплате",
      amountInWords: "Сумма прописью",
      preparedElectronically: "Документ подготовлен электронно и действителен без подписи",
      lateFeeClause: "В случае задержки платежа начисляется пеня в размере 0.5% от просроченной суммы за каждый день просрочки.",
      ownershipClause: "Товар остается собственностью продавца до 100% оплаты счета.",
      signaturePlaceholder: "(Имя, Фамилия, Подпись)"
    },
    EN: { 
      title: isRKF ? "INVOICE / WAYBILL" : "PROFORMA INVOICE", 
      seller: "Seller", 
      buyer: "Buyer",
      delivery: "Delivery",
      unit: "Unit",
      qty: "Qty",
      price: "Price",
      total: "Total, EUR",
      vat: "VAT, %",
      totalWithoutVat: "Total without VAT",
      vatAmount: "VAT 21.00%",
      grandTotal: "Grand Total",
      amountInWords: "Amount in words",
      preparedElectronically: "The document is prepared electronically and is valid without a signature",
      lateFeeClause: "In case of late payment, a late fee of 0.5% of the overdue amount is calculated for each day of delay.",
      ownershipClause: "The goods remain the property of the seller until 100% payment of the invoice.",
      signaturePlaceholder: "(Name, Surname, Signature)"
    }
  }[lang];

  // --- LOGO ---
  if (ROKOF_LOGO_BASE64 && ROKOF_LOGO_BASE64.length > 100) {
    try {
      doc.addImage(ROKOF_LOGO_BASE64, 'PNG', 10, 10, 45, 12);
    } catch (e) {
      console.error("Logo render error", e);
    }
  }

  // --- MIDDLE TOP BOX (Title & Number) ---
  doc.setLineWidth(0.5);
  doc.rect(70, 10, 70, 25);
  doc.setFont("Roboto", "bold");
  doc.setFontSize(11);
  doc.text(t.title, 105, 18, { align: 'center' });
  doc.setFontSize(12);
  doc.text(`Nr. ${invoiceNumber}`, 105, 26, { align: 'center' });
  doc.setFontSize(9);
  doc.setFont("Roboto", "normal");
  doc.text(`Datums: ${new Date().toLocaleDateString('lv-LV')}`, 105, 32, { align: 'center' });

  // --- TWO COLUMN HEADER ---
  doc.setFontSize(9);
  const leftCol = 10;
  const rightCol = 110;
  const startY = 45;

  // Left Side (Nosūtītājs)
  doc.setFont("Roboto", "bold");
  doc.text(t.seller + ":", leftCol, startY);
  doc.setFont("Roboto", "normal");
  doc.text([
    "ROKOF SIA",
    "Reģistrācijas Nr.: 40203287104",
    "Puces iela 11/1-7, Rīga, LV-1082, Latvija",
    "AS ‘Citadele banka’",
    "SWIFT: PARXLV22",
    "IBAN: LV47PARX0023781080001",
    "VAT registration No.: LV40203287104"
  ], leftCol, startY + 6);

  // Right Side (Saņēmējs)
  doc.setFont("Roboto", "bold");
  doc.text(t.buyer + ":", rightCol, startY);
  doc.setFont("Roboto", "normal");

  let buyerInfo: string[] = [];
  
  // Use customerInfo snapshot if available, otherwise fallback to current customerData
  const ci = orderData.customerInfo;
  const addressToUse = ci 
    ? formatAddress(ci) + (orderData.stationId ? ` (Pakomāts: ${orderData.stationId})` : '')
    : (orderData.stationId ? `Pakomāts: ${orderData.stationId}` : (orderData.deliveryAddress || orderData.shippingAddress)) || customerData.physicalAddress || formatAddress(customerData || {});

  if (customerData.type === 'BUSINESS' || ci?.company) {
    buyerInfo = [
      ci?.company || customerData.companyName || '',
      `Registration No.: ${ci?.regNo || customerData.regNo || ''}`,
      `${addressToUse}`,
      `VAT registration No.: ${ci?.vatNo || customerData.vatNo || ''}`
    ];
  } else {
    buyerInfo = [
      `Name: ${ci?.name || `${customerData.firstName || customerData.name || ''} ${customerData.lastName || ''}`.trim()}`,
      `Email: ${ci?.email || customerData.email || ''}`,
      `Phone: ${ci?.phone || customerData.phone || ''}`,
      `Address: ${addressToUse}`
    ];
  }
  doc.text(buyerInfo, rightCol, startY + 6);

  // --- TABLE ---
  const tableBody = orderData.items.map((item: any, index: number) => {
    const isDeliv = item.code === 'DELIVERY' || (item.title && item.title.toLowerCase().includes('delivery'));
    const price = Number(item.price || item.priceAtPurchase || 0);
    const quantity = Number(item.quantity || 1);
    const lineTotal = Number((price * quantity).toFixed(2));
    
    return [
      index + 1,
      isDeliv ? t.delivery : `${item.title} (${item.sku || item.code || ''})`,
      item.unit || 'gab.',
      quantity,
      price.toFixed(2),
      "21",
      lineTotal.toFixed(2)
    ];
  });

  const deliveryCost = Number(orderData.deliveryCost || 0);
  if (deliveryCost > 0) {
    tableBody.push([
      tableBody.length + 1,
      t.delivery,
      "gab.",
      "1",
      deliveryCost.toFixed(2),
      "21",
      deliveryCost.toFixed(2)
    ]);
  }

  autoTable(doc, {
    startY: 85,
    head: [['#', 'Prece', t.unit, t.qty, t.price, t.vat, t.total]],
    body: tableBody,
    theme: 'grid',
    headStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], halign: 'center', fontStyle: 'bold', lineWidth: 0.1 },
    styles: { font: "Roboto", fontSize: 8, cellPadding: 2 },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { halign: 'left' },
      2: { halign: 'center', cellWidth: 15 },
      3: { halign: 'center', cellWidth: 15 },
      4: { halign: 'right', cellWidth: 20 },
      5: { halign: 'center', cellWidth: 15 },
      6: { halign: 'right', cellWidth: 25 }
    }
  });

  // --- TOTALS ---
  const finalY = (doc as any).lastAutoTable.finalY + 10;
  
  // Precise Math
  // deliveryCost is already defined above
  const itemsNetSum = orderData.items.reduce((sum: number, item: any) => {
    const price = Number(item.price || item.priceAtPurchase || 0);
    const quantity = Number(item.quantity || 1);
    return sum + (price * quantity);
  }, 0);
  
  const taxableAmount = Number((itemsNetSum + deliveryCost).toFixed(2));
  const pvn = Number((taxableAmount * 0.21).toFixed(2));
  const totalGross = Number((taxableAmount + pvn).toFixed(2));
  
  const totalWeight = orderData.items.reduce((sum: number, item: any) => {
    return sum + (Number(item.weightPerMeter || 0) * Number(item.quantity || 0));
  }, 0);

  doc.setFontSize(9);
  doc.setFont("Roboto", "normal");
  
  if (totalWeight > 0) {
    doc.text(`Kopējais svars:`, 140, finalY - 7);
    doc.text(`${totalWeight.toFixed(2)} kg`, 200, finalY - 7, { align: 'right' });
  }

  doc.text(`${t.totalWithoutVat}:`, 140, finalY);
  doc.text(`${taxableAmount.toFixed(2)}`, 200, finalY, { align: 'right' });
  
  doc.text(`${t.vatAmount}:`, 140, finalY + 7);
  doc.text(`${pvn.toFixed(2)}`, 200, finalY + 7, { align: 'right' });
  
  doc.setFont("Roboto", "bold");
  doc.text(`${t.grandTotal}:`, 140, finalY + 14);
  doc.text(`EUR ${totalGross.toFixed(2)}`, 200, finalY + 14, { align: 'right' });

  doc.setFont("Roboto", "normal");
  doc.setFontSize(8);
  doc.text(`${t.amountInWords}: ${numberToWordsLV(totalGross)}`, 10, finalY + 25);

  // --- FOOTER & SIGNATURES ---
  const pageHeight = doc.internal.pageSize.height;
  
  // Signature Placeholders
  doc.setFontSize(8);
  doc.text(`${t.seller}: ________________________`, 10, pageHeight - 50);
  doc.setFontSize(7);
  doc.text(t.signaturePlaceholder, 10, pageHeight - 46);
  
  doc.setFontSize(8);
  doc.text(`${t.buyer}: ________________________`, 110, pageHeight - 50);
  doc.setFontSize(7);
  doc.text(t.signaturePlaceholder, 110, pageHeight - 46);

  // Legal Clauses
  doc.setFontSize(7);
  doc.text(t.lateFeeClause, 10, pageHeight - 35);
  doc.text(t.ownershipClause, 10, pageHeight - 31);
  
  doc.setFont("Roboto", "bold");
  doc.setFontSize(8);
  doc.text(t.preparedElectronically, 10, pageHeight - 20);

  // QR Code for Pre-Invoices
  if (!isRKF) {
    try {
      const qrData = `BCD\n002\n1\nSCT\n\nROKOF SIA\nLV47PARX0023781080001\nEUR${totalGross.toFixed(2)}\n\n\n${orderData.number || orderData.id}`;
      const qrDataURL = await QRCode.toDataURL(qrData);
      doc.addImage(qrDataURL, 'PNG', 170, finalY + 20, 30, 30);
      doc.setFontSize(7);
      doc.setFont("Roboto", "normal");
      doc.text("Zibmaksājums (QR)", 170, finalY + 52);
    } catch (qrErr) {
      console.error("QR generation failed", qrErr);
    }
  }

  // Save/Output
  if (action === 'download') {
    const safeInvoiceNumber = invoiceNumber.replace(/\//g, '-');
    const filename = isRKF 
      ? `ROKOF.LV_PAVADZIME_${safeInvoiceNumber}.pdf` 
      : `ROKOF.LV_PRIEKSAPMAKSAS_REKINS_${safeInvoiceNumber}.pdf`;
    doc.save(filename);
  }
  
  return doc.output('blob');
};
