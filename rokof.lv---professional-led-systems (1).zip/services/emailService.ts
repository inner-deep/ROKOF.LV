
export const sendWelcomeEmail = async (userEmail: string, userType: string) => {
  const mailOptions = {
    from: '"ROKOF SIA" <pavels@pzka.lv>',
    to: userEmail,
    subject: 'Laipni lūdzam ROKOF.LV – Jūsu reģistrācija ir apstiprināta!',
    html: `
      <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #000; max-width: 600px; margin: 0 auto;">
        <h2 style="border-bottom: 2px solid #000; padding-bottom: 10px; text-transform: uppercase;">Laipni lūdzam ROKOF.LV!</h2>
        
        <p>Sveicināti!</p>
        <p>Paldies, ka reģistrējāties interneta veikalā <strong>ROKOF.LV</strong>. Jūsu klients profils ir veiksmīgi izveidots.</p>
        
        <div style="background-color: #f9f9f9; padding: 15px; border: 1px solid #eee; margin: 20px 0;">
          <p style="margin: 0;"><strong>Jūsu piekļuves dati:</strong></p>
          <ul style="list-style: none; padding: 0;">
            <li><strong>Lietotājvārds:</strong> ${userEmail}</li>
            <li><strong>Klienta tips:</strong> ${userType}</li>
          </ul>
        </div>

        <h3 style="font-size: 16px; text-transform: uppercase;">Ko Jūs varat darīt tagad?</h3>
        <ul>
          ${userType === 'B2B' ? '<li><strong>B2B klientiem:</strong> Jums ir pieejama vēsturiskā pasūtījumu informācija un iespēja saņemt rēķinus ar QR kodu tūlītējai apmaksai.</li>' : ''}
          <li><strong>Apskatīt sortimentu:</strong> Pārejiet uz mūsu katalogu, lai izvēlētos kvalitatīvu LED apgaismojumu saviem projektiem.</li>
          <li><strong>Profila iestatījumi:</strong> Papildiniet vai mainiet savu piegādes adresi (Omniva/DPD), lai iepirkšanās būtu vēl ātrāka.</li>
        </ul>

        <p style="margin-top: 30px;">
          <a href="https://rokof.lv/login" style="background: #000; color: #fff; padding: 12px 25px; text-decoration: none; font-weight: bold; display: inline-block;">IENĀKT PROFILĀ</a>
        </p>

        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
          <p><strong>Svarīgi:</strong><br />
          Saskaņā ar mūsu <a href="https://rokof.lv/privacy-policy" style="color: #666;">Privātuma politiku</a>, Jūsu dati ir drošībā un tiek apstrādāti atbilstoši ES regulām. Ja Jums rodas jautājumi, mēs vienmēr esam sasniedzami, atbildot uz šo e-pastu vai rakstot uz <a href="mailto:pavels@pzka.lv" style="color: #666;">pavels@pzka.lv</a>.</p>
          
          <p>Lai veiksmīgi darbi!</p>
          <p>Ar cieņu,<br />
          <strong>ROKOF SIA komanda</strong><br />
          <a href="https://www.rokof.lv" style="color: #000; font-weight: bold; text-decoration: none;">www.rokof.lv</a></p>
        </div>
      </div>
    `
  };

  // Logika e-pasta nosūtīšanai (piemēram, izmantojot nodemailer)
  console.log(`✉️ Welcome email prepared for ${userEmail}`);
  console.log(`Subject: ${mailOptions.subject}`);
  // In a real app, you would use a mail provider here
  return new Promise((resolve) => setTimeout(resolve, 500));
};
