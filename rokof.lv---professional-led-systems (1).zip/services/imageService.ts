
import { GoogleGenAI } from "@google/genai";

/**
 * Generates a technical 3D schematic or architectural visualization 
 * of a product based on its SKU and name using Gemini AI.
 */
export const generateProductVisualization = async (sku: string, name: string): Promise<string | null> => {
  // Always initialize inside the function to use the most recent API key from environment
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Create a professional, ultra-clean technical 3D schematic rendering of a professional lighting product.
    Product Details: ${name}
    SKU to feature: ${sku}
    Style: Architectural visualization, futuristic, deep charcoal background, neon accent lighting.
    The image should look like a high-end catalogue render for an engineering company.
    Ensure the SKU "${sku}" is visible as part of a technical label or etched into the product.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "4:3"
        }
      }
    });

    // Handle potential candidate/part structure safely
    const candidate = response.candidates?.[0];
    if (!candidate?.content?.parts) return null;

    for (const part of candidate.content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    
    return null;
  } catch (error) {
    console.error("AI Visualization Error:", error);
    return null;
  }
};
