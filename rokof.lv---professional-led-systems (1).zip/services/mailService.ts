
import { Product, CartItem, User, Language } from '../types';
import { TRANSLATIONS } from '../constants';

const TARGET_EMAIL = 'pavels@pzka.lv';

/**
 * Service for sending notifications.
 * In the current implementation, it logs data to the console.
 */

export const sendOrderNotification = async (
  items: CartItem[], 
  user: User | null, 
  total: number, 
  language: Language,
  deliveryMethod?: string,
  deliveryAddress?: string
) => {
  if (!items || items.length === 0) {
    console.error("Error: Attempted to process an empty order.");
    throw new Error("Cart is empty");
  }

  const deliveryNotice = TRANSLATIONS[language].mailDeliveryNotice;

  const payload = {
    to: TARGET_EMAIL,
    subject: `🛒 JAUNS PASŪTĪJUMS: ${user?.firstName || 'Viesis'} (${total.toFixed(2)}€)`,
    customer: user ? {
      name: user.firstName,
      surname: user.lastName,
      email: user.email,
      phone: user.phone,
      type: user.type,
      company: user.companyName,
      vat: user.vatNo
    } : 'GUEST',
    delivery: {
      method: deliveryMethod || 'Nav norādīts',
      address: deliveryAddress || 'Nav norādīta',
      timeframe: deliveryNotice
    },
    items: items.map(i => ({ 
      sku: i.sku, 
      title: i.title[language], 
      qty: i.quantity, 
      price: i.price,
      total: (i.price * i.quantity).toFixed(2)
    })),
    grandTotal: total.toFixed(2),
    language: language
  };

  console.log("-----------------------------------------");
  console.log("📤 Order Notification Sent to Admin:", payload.to);
  console.log(`SUBJECT: ${payload.subject}`);
  console.log(`KLIENTS: ${typeof payload.customer === 'string' ? 'Viesis' : payload.customer.name}`);
  console.log(`PIEGĀDES METODE: ${payload.delivery.method}`);
  console.log(`PIEGĀDES ADRESE: ${payload.delivery.address}`);
  console.log(`PIEGĀDES LAIKS: ${payload.delivery.timeframe}`);
  console.log("-----------------------------------------");
  console.log("PRECES:");
  payload.items.forEach(item => {
    console.log(`- ${item.sku} | ${item.title} | ${item.qty}m | €${item.total}`);
  });
  console.log("-----------------------------------------");
  
  return new Promise((resolve) => setTimeout(resolve, 1000));
};

export const sendRegistrationNotification = async (userData: User, language: Language) => {
  if (!userData.email) {
    console.error("Error: Missing user email for registration.");
    throw new Error("Missing email");
  }

  const payload = {
    to: TARGET_EMAIL,
    subject: `New Registration: ${userData.type} - ${userData.firstName}`,
    user: userData,
    language: language
  };

  console.log("📤 Sending registration notification to Admin at " + TARGET_EMAIL, payload);
  return new Promise((resolve) => setTimeout(resolve, 800));
};

/**
 * Sends a welcome email directly to the customer with their credentials.
 */
export const sendCustomerWelcomeEmail = async (email: string, password: string, name: string, language: Language) => {
  const content = {
    LV: {
      subject: 'Laipni lūdzam rokof.lv!',
      body: `Sveiki, ${name}! Jūs esat veiksmīgi reģistrējies rokof.lv vietnē.\n\nJūsu piekļuves dati:\nLietotājvārds: ${email}\nParole: ${password}`
    },
    RU: {
      subject: 'Добро пожаловать на rokof.lv!',
      body: `Здравствуйте, ${name}! Вы успешно зарегистрировались на сайте rokof.lv.\n\nВаши данные для входа:\nЛогин: ${email}\nПароль: ${password}`
    },
    EN: {
      subject: 'Welcome to rokof.lv!',
      body: `Hello, ${name}! You have successfully registered on the rokof.lv website.\n\nYour login details:\nLogin: ${email}\nPassword: ${password}`
    }
  };

  const selected = content[language] || content.EN;

  console.log(`✉️ SIMULATED EMAIL TO CUSTOMER [${email}]:`);
  console.log(`Subject: ${selected.subject}`);
  console.log(`Content: ${selected.body}`);

  return new Promise((resolve) => setTimeout(resolve, 500));
};

export const sendInquiryNotification = async (product: Product, formData: any, language: Language) => {
  const payload = {
    to: TARGET_EMAIL,
    subject: `Product Inquiry: ${product.sku} - ${formData.name}`,
    product: { sku: product.sku, title: product.title?.['LV'] || product.sku },
    form: formData,
    language: language
  };

  console.log("📤 Sending inquiry to " + TARGET_EMAIL, payload);
  return new Promise((resolve) => setTimeout(resolve, 800));
};
