
import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from "../constants";

export const getLightingAdvice = async (userPrompt: string, history: {role: 'user' | 'model', content: string}[] = []) => {
  // Initialize the AI client within the request scope to ensure the most up-to-date API key is used
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const productContext = JSON.stringify(PRODUCTS.map(p => ({
    title: p.title?.['LV'] || p.sku,
    category: p.category,
    specifications: p.specifications,
    price: p.price
  })));

  const systemInstruction = `
    You are "Roko", a professional lighting engineer for ROKOF.LV Latvia.
    Your goal is to help customers design LED lighting systems.
    Context:
    - We sell Professional LED strips, power supplies, and profiles.
    - Our stock includes: ${productContext}.
    - Be technical but helpful. Mention 12V/24V compatibility.
    - Suggest specific products from our catalog.
    - If asked about power supplies, remind them of the 20% safety margin.
    - Keep responses concise and professional. Use markdown.
  `;

  try {
    // Upgraded to gemini-3-pro-preview as the assistant performs technical/STEM reasoning tasks
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        ...history.map(h => ({ role: h.role, parts: [{ text: h.content }] })),
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    // Accessing the .text property directly as per Google GenAI SDK guidelines
    return response.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The Roko assistant is currently recharging. Please try again in a moment.";
  }
};