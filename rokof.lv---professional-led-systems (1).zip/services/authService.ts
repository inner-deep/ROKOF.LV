import { User } from '../types';

// Простая валидация email
const validateEmail = (email: string) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

export const loginUser = async (email: string, password: string): Promise<User> => {
  const response = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Login failed' }));
    throw new Error(errorData.error || 'Login failed');
  }

  const data = await response.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    if (data.user) {
      data.user.token = data.token;
    } else {
      data.token = data.token;
    }
  }
  return data.user || data;
};

export const registerUser = async (
  email: string, 
  password: string, 
  marketing: boolean, 
  type: 'INDIVIDUAL' | 'BUSINESS' = 'INDIVIDUAL', 
  ageConfirmed: boolean = false, 
  ipAddress: string = '127.0.0.1',
  profileData: Partial<User> = {},
  language: string = 'lv'
): Promise<User> => {
  // Проверка возраста (дублируем на клиенте для быстрого отклика, но сервер тоже проверит если надо)
  if (type === 'INDIVIDUAL' && !ageConfirmed) {
    throw new Error("Reģistrācija nav atļauta personām jaunākām par 13 gadiem.");
  }

  if (!validateEmail(email)) throw new Error("Nepareizs e-pasta formāts");

  const response = await fetch('/api/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email,
      password,
      type,
      firstName: profileData.firstName,
      lastName: profileData.lastName,
      phone: profileData.phone,
      companyName: profileData.companyName,
      regNo: profileData.regNo,
      vatNo: profileData.vatNo,
      legalAddress: profileData.legalAddress,
      language,
      marketingConsent: marketing
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Registration failed' }));
    throw new Error(errorData.error || 'Registration failed');
  }

  const data = await response.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    if (data.user) {
      data.user.token = data.token;
    } else {
      data.token = data.token;
    }
  }
  return data.user || data;
};
