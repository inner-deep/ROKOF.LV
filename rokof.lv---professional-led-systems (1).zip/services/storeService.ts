
import { Product, Category, Order, User } from '../types';
import { PRODUCTS } from '../constants';

const PRODUCTS_KEY = 'rokof_products_v3';
const CATEGORIES_KEY = 'rokof_categories_v2';
const ORDERS_KEY = 'rokof_orders_v1';
const USER_KEY = 'rokof_current_user_v1';
const WISHLIST_PREFIX = 'rokof_wishlist_';
const GUEST_CART_KEY = 'rokof_guest_cart_v1';

export const storeService = {
  getProducts: async (query: string = ''): Promise<Product[] | { products: Product[], facets: any }> => {
    try {
      const url = `/api/products${query ? '?' + query : ''}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error('Failed to fetch products');
      return await response.json();
    } catch (error) {
      console.error("Error fetching products:", error);
      return PRODUCTS;
    }
  },

  saveProducts: async (products: Product[]) => {
    // In a real app, this would be an admin-only API call
    // For now, we'll just log it as the import API handles this
    console.log("Saving products to DB is handled via /api/import-xlsm");
  },

  updateProductStock: async (productId: string, delta: number) => {
    // Handled on server during order creation
  },

  getCategories: (): string[] => {
    return Object.values(Category);
  },

  saveCategories: (categories: string[]) => {
    // Not implemented in DB yet
  },

  getUser: async (userId: string): Promise<User | null> => {
    try {
      const token = storeService.getToken();
      if (!token) return null;
      const response = await fetch(`/api/users/${userId}`, {
        headers: { 'Authorization': 'Bearer ' + token }
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
        return null;
      }

      if (!response.ok) return null;
      return await response.json();
    } catch (error) {
      console.error("Error fetching user:", error);
      return null;
    }
  },

  getOrders: async (userId?: string): Promise<Order[]> => {
    try {
      if (!userId) return [];
      const token = storeService.getToken();
      if (!token) return [];
      const response = await fetch(`/api/users/${userId}/orders`, {
        headers: { 'Authorization': 'Bearer ' + token }
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
        return [];
      }

      if (!response.ok) throw new Error('Failed to fetch orders');
      const orders = await response.json();
      return orders.map((o: any) => ({
        ...o,
        total: o.totalAmount || o.total, // Ensure total is mapped correctly
        // Keep original ID for API calls, but ensure invoiceNumber is available
        invoiceNumber: o.invoiceNumber || o.id, // Fallback if needed
        date: o.createdAt ? new Date(o.createdAt).toLocaleDateString('lv-LV') : 'N/A'
      }));
    } catch (error) {
      console.error("Error fetching orders:", error);
      return [];
    }
  },

  saveOrder: async (order: Order) => {
    // Handled via /api/orders POST
  },

  updateOrderStatus: async (orderId: string, status: Order['status']) => {
    try {
      const token = storeService.getToken();
      if (!token) return;
      
      const headers: Record<string, string> = { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      };

      const response = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({ status })
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
        return;
      }

      if (!response.ok) throw new Error('Failed to update order status');
      window.dispatchEvent(new Event('rokof_orders_updated'));
    } catch (error) {
      console.error("Error updating order status:", error);
    }
  },

  updateUser: (user: User) => {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    window.dispatchEvent(new Event('rokof_user_updated'));
  },

  clearAuth: () => {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem('token');
    window.dispatchEvent(new Event('rokof_user_updated'));
  },

  getStoredUser: (): User | null => {
    try {
      const stored = localStorage.getItem(USER_KEY);
      const token = storeService.getToken();
      if (!stored || !token) return null;
      return JSON.parse(stored);
    } catch (e) {
      console.error("Error parsing stored user:", e);
      return null;
    }
  },

  getToken: (): string | null => {
    let token = localStorage.getItem('token');
    if (token && token.startsWith('"') && token.endsWith('"')) {
      token = token.slice(1, -1);
    }
    return token;
  },

  getWishlist: async (userId: string): Promise<string[]> => {
    try {
      const token = storeService.getToken();
      if (!token) return [];
      const response = await fetch(`/api/users/${userId}/wishlist`, {
        headers: { 'Authorization': 'Bearer ' + token }
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
        return [];
      }

      if (!response.ok) throw new Error('Failed to fetch wishlist');
      return await response.json();
    } catch (error) {
      console.error("Error fetching wishlist:", error);
      return [];
    }
  },

  saveWishlist: async (userId: string, productIds: string[]) => {
    // This is tricky because the API takes one product at a time or we need a bulk update
    // For now, let's just implement a toggle in the component and use the API there.
    // But to keep the interface similar, we'll just log that it should be done via individual calls.
  },

  addToWishlist: async (userId: string, productId: string) => {
    try {
      const token = storeService.getToken();
      if (!token) return;
      const response = await fetch(`/api/users/${userId}/wishlist`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ productId })
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
        return;
      }

      window.dispatchEvent(new Event('rokof_wishlist_updated'));
    } catch (error) {
      console.error("Error adding to wishlist:", error);
    }
  },

  removeFromWishlist: async (userId: string, productId: string) => {
    try {
      const token = storeService.getToken();
      if (!token) return;
      const response = await fetch(`/api/users/${userId}/wishlist/${productId}`, {
        method: 'DELETE',
        headers: { 'Authorization': 'Bearer ' + token }
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
        return;
      }

      window.dispatchEvent(new Event('rokof_wishlist_updated'));
    } catch (error) {
      console.error("Error removing from wishlist:", error);
    }
  },

  // Cart Management
  getCart: async (userId?: string): Promise<any[]> => {
    if (!userId) {
      const stored = localStorage.getItem(GUEST_CART_KEY);
      return stored ? JSON.parse(stored) : [];
    }

    try {
      const token = storeService.getToken();
      if (!token) return [];
      const response = await fetch(`/api/users/${userId}/cart`, {
        headers: { 'Authorization': 'Bearer ' + token }
      });

      if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        return [];
      }

      if (!response.ok) throw new Error('Failed to fetch cart');
      return await response.json();
    } catch (error) {
      console.error("Error fetching cart:", error);
      return [];
    }
  },

  addToCart: async (userId: string | undefined, productId: string, quantity: number = 1) => {
    console.log("storeService.addToCart called:", { userId, productId, quantity });
    if (!userId) {
      const cart = await storeService.getCart();
      const existing = cart.find(item => item.productId === productId);
      if (existing) {
        existing.quantity += quantity;
      } else {
        cart.push({ productId, quantity });
      }
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(cart));
      window.dispatchEvent(new Event('rokof_cart_updated'));
      return;
    }

    try {
      const token = storeService.getToken();
      console.log("storeService.addToCart: token value:", token);
      const response = await fetch(`/api/users/${userId}/cart`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ productId, quantity })
      });
      
      if (response.ok) {
        window.dispatchEvent(new Event('rokof_cart_updated'));
      } else {
        if (response.status === 401 || response.status === 403) {
          storeService.clearAuth();
          window.location.href = '/';
        }
        console.error("Error adding to cart:", response.status, response.statusText);
      }
    } catch (error) {
      console.error("Error adding to cart:", error);
    }
  },

  removeFromCart: async (userId: string | undefined, productId: string) => {
    if (!userId) {
      const cart = await storeService.getCart();
      const filtered = cart.filter(item => item.productId !== productId);
      localStorage.setItem(GUEST_CART_KEY, JSON.stringify(filtered));
      window.dispatchEvent(new Event('rokof_cart_updated'));
      return;
    }

    try {
      const token = storeService.getToken();
      const response = await fetch(`/api/users/${userId}/cart/${productId}`, {
        method: 'DELETE',
        headers: { 'Authorization': 'Bearer ' + token }
      });
      if (response.ok) {
        window.dispatchEvent(new Event('rokof_cart_updated'));
      } else if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
      }
    } catch (error) {
      console.error("Error removing from cart:", error);
    }
  },

  syncCart: async () => {
    const token = storeService.getToken();
    if (!token) return;

    const guestCart = await storeService.getCart();
    if (guestCart.length === 0) return;

    try {
      const response = await fetch('/api/cart/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ items: guestCart })
      });

      if (response.ok) {
        localStorage.removeItem(GUEST_CART_KEY);
        window.dispatchEvent(new Event('rokof_cart_updated'));
      } else if (response.status === 401 || response.status === 403) {
        storeService.clearAuth();
        window.location.href = '/';
      }
    } catch (error) {
      console.error("Error syncing cart:", error);
    }
  }
};
