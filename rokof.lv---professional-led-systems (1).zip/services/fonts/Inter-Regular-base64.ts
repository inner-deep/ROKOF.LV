
// This file should contain the base64 string of the Inter-Regular.ttf font.
// You can convert a .ttf file to base64 using online tools or a script.
// For now, this is a placeholder. Replace the string below with the actual base64 data.

export const fontBase64 = "AAEAAAARAQAABAAQR0RFRv8H..."; // Placeholder base64 string
