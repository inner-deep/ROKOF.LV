import { User, Order } from '../types';
import { storeService } from './storeService';

// Экспорт данных (Data Portability - Art. 20)
export const exportUserData = async (user: User) => {
  const token = storeService.getStoredUser()?.token;
  if (!token) throw new Error('Not authenticated');

  try {
    const response = await fetch('/api/users/me/data', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch user data for export');
    }

    const dataPackage = await response.json();

    const blob = new Blob([JSON.stringify(dataPackage, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ROKOF_DSAR_${user.email}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error("DSAR Export failed:", error);
    throw error;
  }
};

// Запрос на удаление (Right to be Forgotten - Art. 17)
export const deleteAccountRequest = async (userId: string) => {
  const token = storeService.getStoredUser()?.token;
  if (!token) throw new Error('Not authenticated');

  // 1. Вызываем API для анонимизации данных (сервер сам проверит активные заказы)
  const response = await fetch('/api/users/me', {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to delete account');
  }

  // Уведомляем о дедлайне 30 дней (Art. 12)
  const deadline = new Date();
  deadline.setDate(deadline.getDate() + 30);
  console.log(`Lietotājs ${userId} pieprasīja datu dzēšanu. Izpildes termiņš: ${deadline.toISOString()}`);

  return await response.json();
};
