
import { PrismaClient } from '@prisma/client';
import { PRODUCTS } from '../constants';

const prisma = new PrismaClient();

async function main() {
  console.log('Start seeding...');
  
  for (const p of PRODUCTS) {
    await prisma.product.upsert({
      where: { sku: p.sku },
      update: {
        titleLV: p.title.LV,
        titleRU: p.title.RU,
        titleEN: p.title.EN,
        descriptionLV: p.description.LV,
        descriptionRU: p.description.RU,
        descriptionEN: p.description.EN,
        category: p.category,
        price: p.price,
        b2bPrice: p.b2bPrice,
        unit: p.unit,
        stockQuantity: Math.round(p.stockQuantity),
        images: JSON.stringify(p.images),
        specifications: JSON.stringify(p.specifications),
      },
      create: {
        sku: p.sku,
        titleLV: p.title.LV,
        titleRU: p.title.RU,
        titleEN: p.title.EN,
        descriptionLV: p.description.LV,
        descriptionRU: p.description.RU,
        descriptionEN: p.description.EN,
        category: p.category,
        price: p.price,
        b2bPrice: p.b2bPrice,
        unit: p.unit,
        stockQuantity: Math.round(p.stockQuantity),
        images: JSON.stringify(p.images),
        specifications: JSON.stringify(p.specifications),
      },
    });
  }
  
  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
